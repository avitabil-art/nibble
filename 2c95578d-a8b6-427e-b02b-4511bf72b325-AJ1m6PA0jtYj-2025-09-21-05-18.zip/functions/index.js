/**
 * Firebase Functions for Nibble shared grocery lists
 * Simple REST API for real-time collaboration
 */

const functions = require('firebase-functions');
const admin = require('firebase-admin');
const cors = require('cors')({ origin: true });

admin.initializeApp();
const db = admin.firestore();

// Logging helper
const log = (message, data = '') => {
  console.log(`[Nibble API] ${message}`, data);
};

// Helper to wrap CORS
const corsWrapper = (handler) => (req, res) => {
  cors(req, res, () => handler(req, res));
};



// Create a single endpoint that handles all routes
exports.api = functions.https.onRequest(corsWrapper(async (req, res) => {
  try {
    log(`${req.method} ${req.path}`, { body: req.body, query: req.query });
    
    const path = req.path;

    // Health check
    if (path === '/health' && req.method === 'GET') {
      return res.status(200).json({ ok: true, ts: Date.now() });
    }
    
    // Route: POST /lists - Create shared list
    if (path === '/lists' && req.method === 'POST') {
      return await handleCreateSharedList(req, res);
    }
    
    // Route: POST /lists/:shareId/join - Join shared list
    const joinMatch = path.match(/^\/lists\/([^\/]+)\/join$/);
    if (joinMatch && req.method === 'POST') {
      req.params = { shareId: joinMatch[1] };
      return await handleJoinSharedList(req, res);
    }
    
    // Route: GET /lists/:shareId - Get shared list
    const getMatch = path.match(/^\/lists\/([^\/]+)$/);
    if (getMatch && req.method === 'GET') {
      req.params = { shareId: getMatch[1] };
      return await handleGetSharedList(req, res);
    }
    
    // Route: POST /lists/:shareId/changes - Upload changes
    const changesMatch = path.match(/^\/lists\/([^\/]+)\/changes$/);
    if (changesMatch && req.method === 'POST') {
      req.params = { shareId: changesMatch[1] };
      return await handleUploadListChanges(req, res);
    }
    
    // Route: POST /lists/:shareId/leave - Leave list
    const leaveMatch = path.match(/^\/lists\/([^\/]+)\/leave$/);
    if (leaveMatch && req.method === 'POST') {
      req.params = { shareId: leaveMatch[1] };
      return await handleLeaveSharedList(req, res);
    }
    
    log('Endpoint not found', { path, method: req.method });
    res.status(404).json({ error: 'Endpoint not found' });
    
  } catch (error) {
    log('API Error', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}));

// Individual handler functions
async function handleCreateSharedList(req, res) {
  if (!req.body.list || !req.body.user) {
    return res.status(400).json({ error: 'Missing list or user data' });
  }

  const { list, user } = req.body;
  
  try {
    // Check if share code already exists
    const existingList = await db.collection('sharedLists')
      .where('shareId', '==', list.shareId)
      .limit(1)
      .get();

    if (!existingList.empty) {
      return res.status(409).json({ error: 'Share code already in use' });
    }

    // Create the shared list
    const listData = {
      ...list,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      lastModified: admin.firestore.FieldValue.serverTimestamp(),
    };

    const docRef = await db.collection('sharedLists').add(listData);
    log('Created shared list', { id: docRef.id, shareId: list.shareId });

    // Create initial access record
    await db.collection('listAccess').doc(`${docRef.id}_${user.id}`).set({
      listId: docRef.id,
      userId: user.id,
      userName: user.name,
      isOwner: true,
      joinedAt: admin.firestore.FieldValue.serverTimestamp(),
      lastActiveAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    res.status(201).json({ 
      success: true, 
      data: { listId: docRef.id } 
    });

  } catch (error) {
    log('Error creating shared list', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

async function handleJoinSharedList(req, res) {
  const { shareId } = req.params;
  const { user } = req.body;
  
  if (!shareId || !user) {
    return res.status(400).json({ error: 'Missing share code or user data' });
  }

  try {
    // Find the shared list
    const listQuery = await db.collection('sharedLists')
      .where('shareId', '==', shareId)
      .limit(1)
      .get();

    if (listQuery.empty) {
      return res.status(404).json({ error: 'List not found' });
    }

    const listDoc = listQuery.docs[0];
    const listData = listDoc.data();

    // Check if user is already a collaborator
    const existingAccess = await db.collection('listAccess')
      .where('listId', '==', listDoc.id)
      .where('userId', '==', user.id)
      .limit(1)
      .get();

    if (!existingAccess.empty) {
      return res.status(409).json({ error: 'User already has access to this list' });
    }

    // Add user to collaborators
    await db.collection('listAccess').doc(`${listDoc.id}_${user.id}`).set({
      listId: listDoc.id,
      userId: user.id,
      userName: user.name,
      isOwner: false,
      joinedAt: admin.firestore.FieldValue.serverTimestamp(),
      lastActiveAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    // Update list's sharedWith array
    await listDoc.ref.update({
      sharedWith: admin.firestore.FieldValue.arrayUnion(user.id),
      lastModified: admin.firestore.FieldValue.serverTimestamp(),
    });

    log('User joined list', { shareId, userId: user.id });

    res.json({ 
      success: true, 
      data: { 
        list: { ...listData, id: listDoc.id },
        message: 'Successfully joined the list' 
      } 
    });

  } catch (error) {
    log('Error joining shared list', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

async function handleGetSharedList(req, res) {
  const { shareId } = req.params;
  const userId = req.headers['x-user-id'];
  const since = req.query.since;
  
  if (!shareId || !userId) {
    return res.status(400).json({ error: 'Missing share ID or user ID' });
  }

  try {
    // Find the shared list
    const listQuery = await db.collection('sharedLists')
      .where('shareId', '==', shareId)
      .limit(1)
      .get();

    if (listQuery.empty) {
      return res.status(404).json({ error: 'List not found' });
    }

    const listDoc = listQuery.docs[0];
    const listData = listDoc.data();

    // Check if user has access
    const hasAccess = listData.sharedWith && listData.sharedWith.includes(userId);
    if (!hasAccess) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Update user's last active time
    await db.collection('listAccess').doc(`${listDoc.id}_${userId}`).update({
      lastActiveAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    // Get collaborators info
    const collaboratorsQuery = await db.collection('listAccess')
      .where('listId', '==', listDoc.id)
      .get();

    const collaborators = collaboratorsQuery.docs.map(doc => ({
      ...doc.data(),
      joinedAt: doc.data().joinedAt?.toDate(),
      lastActiveAt: doc.data().lastActiveAt?.toDate(),
    }));

    // Get changes since timestamp if provided
    let changes = [];
    if (since) {
      const changesQuery = await db.collection('listChanges')
        .where('listId', '==', listDoc.id)
        .where('timestamp', '>', new Date(since))
        .orderBy('timestamp', 'asc')
        .get();

      changes = changesQuery.docs.map(doc => ({
        ...doc.data(),
        timestamp: doc.data().timestamp?.toDate(),
      }));
    }

    res.json({
      success: true,
      data: {
        list: {
          ...listData,
          id: listDoc.id,
          createdAt: listData.createdAt?.toDate(),
          lastModified: listData.lastModified?.toDate(),
        },
        collaborators,
        changes,
        lastSyncAt: new Date(),
      }
    });

  } catch (error) {
    log('Error getting shared list', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

async function handleUploadListChanges(req, res) {
  const { shareId } = req.params;
  const { changes, userId } = req.body;
  
  if (!shareId || !changes || !userId) {
    return res.status(400).json({ error: 'Missing required data' });
  }

  try {
    // Find the shared list
    const listQuery = await db.collection('sharedLists')
      .where('shareId', '==', shareId)
      .limit(1)
      .get();

    if (listQuery.empty) {
      return res.status(404).json({ error: 'List not found' });
    }

    const listDoc = listQuery.docs[0];
    const listData = listDoc.data();

    // Check if user has access
    const hasAccess = listData.sharedWith && listData.sharedWith.includes(userId);
    if (!hasAccess) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Process each change
    const batch = db.batch();
    const timestamp = admin.firestore.FieldValue.serverTimestamp();

    for (const change of changes) {
      // Store change record
      const changeRef = db.collection('listChanges').doc();
      batch.set(changeRef, {
        ...change,
        listId: listDoc.id,
        timestamp,
      });

      // Apply change to the list (simplified - just update timestamp)
      batch.update(listDoc.ref, {
        lastModified: timestamp,
        version: admin.firestore.FieldValue.increment(1),
      });
    }

    await batch.commit();
    log('Applied changes', { shareId, changesCount: changes.length });

    res.json({ 
      success: true, 
      data: { changesApplied: changes.length } 
    });

  } catch (error) {
    log('Error uploading changes', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

async function handleLeaveSharedList(req, res) {
  const { shareId } = req.params;
  const userId = req.headers['x-user-id'];
  
  if (!shareId || !userId) {
    return res.status(400).json({ error: 'Missing share ID or user ID' });
  }

  try {
    // Find the shared list
    const listQuery = await db.collection('sharedLists')
      .where('shareId', '==', shareId)
      .limit(1)
      .get();

    if (listQuery.empty) {
      return res.status(404).json({ error: 'List not found' });
    }

    const listDoc = listQuery.docs[0];
    
    // Remove user from access and list
    await db.collection('listAccess').doc(`${listDoc.id}_${userId}`).delete();
    
    await listDoc.ref.update({
      sharedWith: admin.firestore.FieldValue.arrayRemove(userId),
      lastModified: admin.firestore.FieldValue.serverTimestamp(),
    });

    log('User left list', { shareId, userId });

    res.json({ 
      success: true, 
      data: { message: 'Successfully left the list' } 
    });

  } catch (error) {
    log('Error leaving shared list', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}