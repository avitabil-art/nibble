import React, { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  TextInput,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useRecipeStore } from "../state/recipeStore";
import GroceryItem from "../components/GroceryItem";
import ListSelector from "../components/ListSelector";
import { typography } from "../utils/fonts";
import { parseQuickAdd, splitMulti, QuickAddParsed } from "../utils/quickAddParser";

const CONTAINER_CHOICES = [
  "can",
  "bottle",
  "pack",
  "box",
  "bag",
  "jar",
  "carton",
  "dozen",
  "piece",
];

const SIZE_CHOICES = ["oz", "lb", "g", "kg", "mL", "L", "gal", "qt", "pt"];

export default function GroceryListScreen() {
  const getActiveList = useRecipeStore((s) => s.getActiveList);
  const clearCheckedItems = useRecipeStore((s) => s.clearCheckedItems);
  const syncStatus = useRecipeStore((s) => s.syncStatus);
  const currentUser = useRecipeStore((s) => s.currentUser);
  const [newItemText, setNewItemText] = useState("");

  // Quick-add preview state for the last token
  const [preview, setPreview] = useState<QuickAddParsed | null>(null);
  const [qty, setQty] = useState<number>(1);
  const [selectedContainer, setSelectedContainer] = useState<string | undefined>(undefined);
  const [selectedSizeUnit, setSelectedSizeUnit] = useState<string | undefined>(undefined);
  const [sizeAmount, setSizeAmount] = useState<number | undefined>(undefined);

  const activeList = getActiveList();
  const groceryItems = activeList?.items || [];
  const checkedItems = groceryItems.filter((item) => item.checked);
  const uncheckedItems = groceryItems.filter((item) => !item.checked);

  const handleChangeText = (text: string) => {
    setNewItemText(text);
    const parts = splitMulti(text);
    const last = parts.length > 0 ? parts[parts.length - 1] : "";
    if (!last.trim()) {
      setPreview(null);
      return;
    }
    const p = parseQuickAdd(last);
    setPreview(p);
    setQty(p.qty ?? 1);
    setSelectedContainer(p.containerUnit);
    setSelectedSizeUnit(p.directUnit || p.sizeUnit);
    setSizeAmount(p.sizeAmount);
  };

  const buildNotes = (amt?: number, unit?: string) => {
    if (!amt || !unit) return "";
    return `Size: ${amt} ${unit}`;
  };

  const handleAddItem = () => {
    const text = newItemText.trim();
    if (!text) return;

    const items = splitMulti(text);
    const add = useRecipeStore.getState().addGroceryItem;

    items.forEach((token, idx) => {
      const parsed = parseQuickAdd(token);

      // Apply overrides for the last token (from inline preview)
      const isLast = idx === items.length - 1;
      const effectiveContainer = isLast ? selectedContainer || parsed.containerUnit : parsed.containerUnit;
      const effectiveSizeUnit = isLast ? selectedSizeUnit || parsed.directUnit || parsed.sizeUnit : parsed.directUnit || parsed.sizeUnit;
      const effectiveQty = isLast ? qty ?? parsed.qty : parsed.qty;
      const effectiveSizeAmount = isLast ? sizeAmount ?? parsed.sizeAmount : parsed.sizeAmount;

      let name = parsed.name?.trim() || token.trim();
      let amount: number | undefined = undefined;
      let unit: string | undefined = undefined;
      let notes: string | undefined = undefined;

      if (effectiveContainer) {
        // Container mode: amount is number of containers, unit is container; size goes to notes
        amount = typeof effectiveQty === "number" && effectiveQty > 0 ? effectiveQty : 1;
        unit = effectiveContainer;
        notes = buildNotes(effectiveSizeAmount, effectiveSizeUnit);
      } else if (effectiveSizeUnit) {
        // Direct measure mode
        amount = typeof effectiveSizeAmount === "number" && effectiveSizeAmount > 0
          ? effectiveSizeAmount
          : (typeof effectiveQty === "number" && effectiveQty > 0 ? effectiveQty : 1);
        unit = effectiveSizeUnit;
      } else {
        // Name-only fallback
        amount = 1;
        unit = "piece";
      }

      add({ 
        name, 
        amount, 
        unit, 
        notes, 
        checked: false,
        version: 1,
        modifiedAt: new Date()
      });
    });

    // Reset input and preview
    setNewItemText("");
    setPreview(null);
    setQty(1);
    setSelectedContainer(undefined);
    setSelectedSizeUnit(undefined);
    setSizeAmount(undefined);
  };

  // Build inline summary text for preview
  const summaryText = (() => {
    if (!preview) return "";
    const name = preview.name?.trim();
    const container = selectedContainer;
    const unit = selectedSizeUnit || preview.directUnit || preview.sizeUnit;
    const amt = sizeAmount ?? preview.sizeAmount;
    if (container) {
      const q = qty > 0 ? qty : 1;
      const sizeLabel = amt && unit ? ` (${amt} ${unit})` : "";
      return `${q} ${container} ${name || ""}${sizeLabel}`.trim();
    }
    if (unit) {
      const a = (amt && amt > 0) ? amt : (qty > 0 ? qty : 1);
      return `${a} ${unit} ${name || ""}`.trim();
    }
    return `${name || ""}`;
  })();

  return (
    <SafeAreaView className="flex-1 bg-offwhite">
      <View className="flex-1">
        {/* List Selector */}
        <ListSelector />
        
        {/* Add Item Input - Nibble Style */}
        <View className="px-5 py-4 bg-offwhite">
          <View className="flex-row items-center bg-white rounded-2xl px-5 py-4 border border-neutral-200">
            <TextInput
              className="flex-1 text-charcoal"
              style={typography.body}
              placeholder="Add to your nibble list..."
              placeholderTextColor="#737373"
              value={newItemText}
              onChangeText={handleChangeText}
              onSubmitEditing={handleAddItem}
              returnKeyType="done"
            />
            <Pressable
              onPress={handleAddItem}
              className="ml-3 p-1"
              disabled={!newItemText.trim()}
            >
              <Ionicons
                name="add-circle"
                size={28}
                color={newItemText.trim() ? "#48C78E" : "#A3A3A3"}
              />
            </Pressable>
          </View>

          {/* Inline smart preview */}
          {preview && (
            <View className="mt-3 bg-white rounded-2xl border border-neutral-200 px-4 py-3">
              {!!summaryText && (
                <Text className="text-neutral-600 mb-2" style={typography.body}>
                  {summaryText}
                </Text>
              )}

              {/* Qty stepper */}
              <View className="flex-row items-center mb-2">
                <Text className="text-neutral-700 mr-3" style={typography.bodyMedium}>Qty</Text>
                <Pressable
                  onPress={() => setQty((q) => Math.max(1, (q || 1) - 1))}
                  className="h-10 w-10 rounded-full bg-red-50 items-center justify-center border border-red-200 active:bg-red-100"
                >
                  <Ionicons name="remove-circle" size={20} color="#EF4444" />
                </Pressable>
                <Text className="mx-4 text-charcoal font-semibold text-lg" style={typography.bodyMedium}>{qty || 1}</Text>
                <Pressable
                  onPress={() => setQty((q) => (q || 1) + 1)}
                  className="h-10 w-10 rounded-full bg-green-50 items-center justify-center border border-green-200 active:bg-green-100"
                >
                  <Ionicons name="add-circle" size={20} color="#22C55E" />
                </Pressable>
              </View>

              {/* Container chips */}
              <View className="mb-2">
                <Text className="text-neutral-700 mb-2" style={typography.bodyMedium}>Container</Text>
                <View className="flex-row flex-wrap">
                  {CONTAINER_CHOICES.map((c) => {
                    const active = selectedContainer === c;
                    return (
                      <Pressable
                        key={c}
                        onPress={() => setSelectedContainer(active ? undefined : c)}
                        className={active ? "px-3 py-1.5 mr-2 mb-2 rounded-full bg-fresh/15 border border-fresh" : "px-3 py-1.5 mr-2 mb-2 rounded-full bg-neutral-100 border border-neutral-200"}
                      >
                        <Text className={active ? "text-fresh" : "text-neutral-700"} style={typography.body}>{c}</Text>
                      </Pressable>
                    );
                  })}
                </View>
              </View>

              {/* Size unit chips */}
              <View>
                <Text className="text-neutral-700 mb-2" style={typography.bodyMedium}>Size Unit</Text>
                <View className="flex-row flex-wrap">
                  {SIZE_CHOICES.map((u) => {
                    const active = (selectedSizeUnit || "").toLowerCase() === u.toLowerCase();
                    return (
                      <Pressable
                        key={u}
                        onPress={() => setSelectedSizeUnit(active ? undefined : u)}
                        className={active ? "px-3 py-1.5 mr-2 mb-2 rounded-full bg-citrus/15 border border-citrus" : "px-3 py-1.5 mr-2 mb-2 rounded-full bg-neutral-100 border border-neutral-200"}
                      >
                        <Text className={active ? "text-citrus" : "text-neutral-700"} style={typography.body}>{u}</Text>
                      </Pressable>
                    );
                  })}
                </View>
              </View>
            </View>
          )}
        </View>

        {/* Clear Checked Items Button - Nibble Style */}
        <View className="px-5 pb-3 bg-offwhite">
          <View className="flex-row items-center justify-between">
            {checkedItems.length > 0 && (
              <Pressable
                onPress={clearCheckedItems}
                className="flex-row items-center justify-center py-3 bg-berry/10 rounded-2xl border border-berry/20 flex-1"
              >
                <Ionicons name="checkmark-done-outline" size={18} color="#FF4D6D" />
                <Text className="text-berry ml-2" style={typography.accent}>
                  CLEAR {checkedItems.length} NIBBLED
                </Text>
              </Pressable>
            )}

            {/* Sync status indicator for shared lists */}
            {activeList?.isShared && (
              <View className={`flex-row items-center px-3 py-2 rounded-xl ${checkedItems.length > 0 ? 'ml-3' : ''}`}>
                {syncStatus.isSyncing ? (
                  <>
                    <Ionicons name="sync" size={16} color="#FF8A4C" />
                    <Text className="text-citrus ml-2 text-sm font-medium" style={typography.caption}>
                      Syncing...
                    </Text>
                  </>
                ) : !syncStatus.isOnline ? (
                  <>
                    <Ionicons name="cloud-offline" size={16} color="#EF4444" />
                    <Text className="text-red-500 ml-2 text-sm font-medium" style={typography.caption}>
                      Offline
                    </Text>
                  </>
                ) : syncStatus.pendingChanges > 0 ? (
                  <>
                    <Ionicons name="time" size={16} color="#FF8A4C" />
                    <Text className="text-citrus ml-2 text-sm font-medium" style={typography.caption}>
                      {syncStatus.pendingChanges} pending
                    </Text>
                  </>
                ) : (
                  <>
                    <Ionicons name="people" size={16} color="#48C78E" />
                    <Text className="text-fresh ml-2 text-sm font-medium" style={typography.caption}>
                      Synced
                    </Text>
                  </>
                )}
              </View>
            )}
          </View>
        </View>

        {/* Grocery List - Nibble Style */}
        <ScrollView className="flex-1 bg-offwhite">
          {groceryItems.length === 0 ? (
            <View className="flex-1 justify-center items-center py-20">
              <View className="bg-fresh/10 p-6 rounded-full mb-4">
                <Ionicons name="basket-outline" size={48} color="#48C78E" />
              </View>
              <Text 
                className="text-charcoal text-center mb-3"
                style={typography.heading}
              >
                {activeList?.name || "Your list"} is empty—time to nibble!
              </Text>
              <Text className="text-neutral-500 text-center px-8" style={typography.body}>
                Add items manually or import from your recipes. From recipe to cart!
              </Text>
            </View>
          ) : (
            <View className="px-5 py-2">
              {/* Unchecked Items - Ready to Nibble */}
              {uncheckedItems.length > 0 && (
                <View className="mb-8">
                  <View className="flex-row items-center mb-4">
                    <Ionicons name="basket-outline" size={18} color="#48C78E" />
                    <Text 
                      className="text-fresh ml-2 tracking-wider"
                      style={typography.accent}
                    >
                      READY TO NIBBLE
                    </Text>
                    <View className="flex-1 h-px bg-fresh/20 ml-3" />
                  </View>
                  {uncheckedItems.map((item) => (
                    <GroceryItem key={item.id} item={item} />
                  ))}
                </View>
              )}

              {/* Checked Items - Nibbled */}
              {checkedItems.length > 0 && (
                <View>
                  <View className="flex-row items-center mb-4">
                    <Ionicons name="checkmark-done" size={18} color="#FF4D6D" />
                    <Text 
                      className="text-berry ml-2 tracking-wider"
                      style={typography.accent}
                    >
                      NIBBLED ({checkedItems.length})
                    </Text>
                    <View className="flex-1 h-px bg-berry/20 ml-3" />
                  </View>
                  {checkedItems.map((item) => (
                    <GroceryItem key={item.id} item={item} />
                  ))}
                </View>
              )}
            </View>
          )}
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}
