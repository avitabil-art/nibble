import React, { useState, useEffect, useMemo, useRef, Suspense } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  TextInput,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useRecipeStore } from "../state/recipeStore";
import RecipeCard from "../components/RecipeCard";
const AddRecipeModal = React.lazy(() => import("../components/AddRecipeModal"));
import { initializeSampleData } from "../utils/sampleData";
import CategoryChip from "../components/CategoryChip";
import { typography } from "../utils/fonts";
import AiSetupHint from "../components/AiSetupHint";
import AiSettingsModal from "../components/AiSettingsModal";
import { anyAiConfigured } from "../utils/env";

export default function RecipesScreen() {
  const recipes = useRecipeStore((s) => s.recipes);
  const banner = useRecipeStore((s) => s.uiBanner);
  const clearBanner = useRecipeStore((s) => s.clearBanner);
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const getAllCategories = useRecipeStore((s) => s.getAllCategories);
  const allCategories = useMemo(() => getAllCategories(), [getAllCategories, recipes])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [showAiSettings, setShowAiSettings] = useState(false);
  const [aiConfigured, setAiConfigured] = useState(true);

  useEffect(() => {
    anyAiConfigured().then(setAiConfigured).catch(() => setAiConfigured(false));
  }, []);

  const seededRef = useRef(false);
  useEffect(() => {
    if (seededRef.current) return;
    if (recipes.length > 0) return;
    const t = setTimeout(() => {
      try { initializeSampleData(); seededRef.current = true; } catch {}
    }, 350);
    return () => clearTimeout(t);
  }, [recipes.length]);

  const filteredRecipes = recipes.filter((recipe) => {
    const matchesText = recipe.title.toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesText) return false;
    if (selectedCategories.length === 0) return true;
    const tags = (recipe.tags ?? []).map((t) => t.toLowerCase());
    return selectedCategories.some((c) => tags.includes(c.toLowerCase()));
  });

  return (
    <SafeAreaView className="flex-1 bg-offwhite">
      <View className="flex-1">
        {/* Search Bar - Nibble Style */}
        <View className="px-5 py-4 bg-offwhite">
          <View className="flex-row items-center bg-white rounded-2xl px-4 py-4 border border-neutral-200">
            <Ionicons name="search" size={22} color="#48C78E" />
            <TextInput
              className="flex-1 ml-3 text-charcoal"
              style={typography.body}
              placeholder="Search your nibbles..."
              placeholderTextColor="#737373"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
        </View>

        {/* Category Filters - Fresh Style */}
        <View className="px-5 py-3 bg-offwhite">
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View className="flex-row py-1">
              <CategoryChip
                label="All"
                selected={selectedCategories.length === 0}
                onPress={() => setSelectedCategories([])}
              />
              {allCategories.map((cat) => (
                <CategoryChip
                  key={cat}
                  label={cat}
                  selected={selectedCategories.some((c) => c.toLowerCase() === cat.toLowerCase())}
                  onPress={() => {
                    setSelectedCategories((prev) => {
                      const exists = prev.some((p) => p.toLowerCase() === cat.toLowerCase());
                      if (exists) return prev.filter((p) => p.toLowerCase() !== cat.toLowerCase());
                      return [...prev, cat];
                    });
                  }}
                />
              ))}
            </View>
          </ScrollView>
        </View>

        {/* Banner - Nibble Style */}
        {banner ? (
          <View className="px-5 pb-2 bg-offwhite">
            <Pressable 
              onPress={clearBanner} 
              className="bg-fresh/10 border border-fresh/20 rounded-2xl px-4 py-3"
            >
              <Text className="text-fresh" style={typography.body}>{banner}</Text>
            </Pressable>
          </View>
        ) : null}

        {!aiConfigured && (
          <AiSetupHint onPress={() => setShowAiSettings(true)} />
        )}

        {/* Recipes List - Nibble Style */}
        <ScrollView className="flex-1 px-5 py-2">
          {filteredRecipes.length === 0 ? (
            <View className="flex-1 justify-center items-center py-20">
              <View className="bg-fresh/10 p-6 rounded-full mb-4">
                <Ionicons name="restaurant-outline" size={48} color="#48C78E" />
              </View>
              <Text 
                className="text-charcoal text-center mb-3"
                style={typography.heading}
              >
                {searchQuery ? "No recipes found" : "No recipes yet—time to nibble!"}
              </Text>
              <Text className="text-neutral-500 text-center px-8" style={typography.body}>
                {searchQuery
                  ? "Try adjusting your search or start fresh"
                  : "Add your first recipe and start your culinary journey"}
              </Text>
            </View>
          ) : (
            <View className="space-y-5">
              {filteredRecipes.map((recipe) => (
                <RecipeCard key={recipe.id} recipe={recipe} />
              ))}
            </View>
          )}
        </ScrollView>

        {/* Add Recipe Button - Clear Intent */}
        <View className="absolute bottom-8 right-6">
          <Pressable
            onPress={() => setShowAddModal(true)}
            className="bg-citrus w-16 h-16 rounded-2xl items-center justify-center shadow-lg active:scale-95"
            style={{
              shadowColor: "#FF8A4C",
              shadowOffset: { width: 0, height: 6 },
              shadowOpacity: 0.25,
              shadowRadius: 12,
              elevation: 8,
            }}
          >
            <Ionicons name="restaurant" size={28} color="white" />
          </Pressable>
        </View>
      </View>

      <Suspense fallback={null}>
        <AddRecipeModal
          visible={showAddModal}
          onClose={() => setShowAddModal(false)}
        />
      </Suspense>

      <AiSettingsModal visible={showAiSettings} onClose={() => {
        setShowAiSettings(false);
        anyAiConfigured().then(setAiConfigured).catch(() => setAiConfigured(false));
      }} />
    </SafeAreaView>
  );
}