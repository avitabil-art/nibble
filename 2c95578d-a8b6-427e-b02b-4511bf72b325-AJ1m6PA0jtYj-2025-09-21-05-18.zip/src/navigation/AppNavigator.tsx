import React, { useMemo } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import RecipesScreen from "../screens/RecipesScreen";
import GroceryListScreen from "../screens/GroceryListScreen";
import { useRecipeStore } from "../state/recipeStore";
import { typography } from "../utils/fonts";
import { ErrorBoundary } from "../components/ErrorBoundary";
import { logger } from "../utils/logger";

const Tab = createBottomTabNavigator();

export default function AppNavigator() {
  const activeListId = useRecipeStore((s) => s.activeListId);
  const lists = useRecipeStore((s) => s.groceryLists);
  const activeListName = useMemo(() => lists.find(l => l.id === activeListId)?.name || "My Lists", [lists, activeListId]);
  
  return (
    <ErrorBoundary>
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={({ route }) => ({
            tabBarIcon: ({ focused, color, size }) => {
              let iconName: keyof typeof Ionicons.glyphMap;

              if (route.name === "Recipes") {
                iconName = focused ? "restaurant" : "restaurant-outline";
              } else if (route.name === "Lists") {
                iconName = focused ? "clipboard" : "clipboard-outline";
              } else {
                iconName = "help-outline";
              }

              return <Ionicons name={iconName} size={size} color={color} />;
            },
            tabBarActiveTintColor: "#48C78E", // fresh green
            tabBarInactiveTintColor: "#737373", // neutral-500
            tabBarStyle: {
              backgroundColor: "#FAFAFA", // offwhite
              borderTopColor: "#E5E5E5", // neutral-200
              paddingTop: 10,
              paddingBottom: 10,
              height: 90,
              borderTopWidth: 1,
            },
            tabBarLabelStyle: {
              fontSize: 11,
              fontWeight: "600",
              marginTop: 2,
            },
            headerStyle: {
              backgroundColor: "#FAFAFA", // offwhite
              shadowColor: "transparent",
              elevation: 0,
              borderBottomWidth: 0,
            },
            headerTitleStyle: {
              ...typography.heading,
              color: "#2E2E2E", // charcoal
            },
          })}
        >
          <Tab.Screen 
            name="Recipes" 
            options={{
              title: "Nibble",
            }}
          >
            {() => (
              <ErrorBoundary>
                <RecipesScreen />
              </ErrorBoundary>
            )}
          </Tab.Screen>
          <Tab.Screen 
            name="Lists" 
            options={{
              title: activeListName,
              tabBarLabel: "Lists",
            }}
          >
            {() => (
              <ErrorBoundary>
                <GroceryListScreen />
              </ErrorBoundary>
            )}
          </Tab.Screen>
        </Tab.Navigator>
      </NavigationContainer>
    </ErrorBoundary>
  );
}