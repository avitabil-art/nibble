import { ParsedRecipeData, Ingredient } from "../types/recipe";
import { getOpenAITextResponse } from "../api/chat-service";

// Common units and their variations
const UNIT_MAPPINGS: Record<string, string> = {
  "cup": "cup",
  "cups": "cup",
  "c": "cup",
  "tablespoon": "tbsp",
  "tablespoons": "tbsp",
  "tbsp": "tbsp",
  "tbs": "tbsp",
  "teaspoon": "tsp",
  "teaspoons": "tsp",
  "tsp": "tsp",
  "pound": "lb",
  "pounds": "lb",
  "lb": "lb",
  "lbs": "lb",
  "ounce": "oz",
  "ounces": "oz",
  "oz": "oz",
  "gram": "g",
  "grams": "g",
  "g": "g",
  "kilogram": "kg",
  "kilograms": "kg",
  "kg": "kg",
  "liter": "L",
  "liters": "L",
  "l": "L",
  "milliliter": "mL",
  "milliliters": "mL",
  "ml": "mL",
  "piece": "piece",
  "pieces": "piece",
  "whole": "whole",
  "clove": "clove",
  "cloves": "clove",
  "slice": "slice",
  "slices": "slice",
};

// Fraction mappings
const FRACTION_MAPPINGS: Record<string, number> = {
  "½": 0.5,
  "⅓": 0.333,
  "⅔": 0.667,
  "¼": 0.25,
  "¾": 0.75,
  "⅛": 0.125,
  "⅜": 0.375,
  "⅝": 0.625,
  "⅞": 0.875,
  "1/2": 0.5,
  "1/3": 0.333,
  "2/3": 0.667,
  "1/4": 0.25,
  "3/4": 0.75,
  "1/8": 0.125,
  "3/8": 0.375,
  "5/8": 0.625,
  "7/8": 0.875,
};

function parseAmount(amountStr: string): number {
  // Handle fractions
  for (const [fraction, decimal] of Object.entries(FRACTION_MAPPINGS)) {
    if (amountStr.includes(fraction)) {
      const remaining = amountStr.replace(fraction, "").trim();
      const wholeNumber = remaining ? parseFloat(remaining) : 0;
      return wholeNumber + decimal;
    }
  }

  // Handle mixed numbers like "1 1/2"
  const mixedMatch = amountStr.match(/(\d+)\s+(\d+)\/(\d+)/);
  if (mixedMatch) {
    const whole = parseInt(mixedMatch[1]);
    const numerator = parseInt(mixedMatch[2]);
    const denominator = parseInt(mixedMatch[3]);
    return whole + numerator / denominator;
  }

  // Handle simple fractions like "3/4"
  const fractionMatch = amountStr.match(/(\d+)\/(\d+)/);
  if (fractionMatch) {
    const numerator = parseInt(fractionMatch[1]);
    const denominator = parseInt(fractionMatch[2]);
    return numerator / denominator;
  }

  // Handle regular numbers
  const number = parseFloat(amountStr);
  return isNaN(number) ? 1 : number;
}

function parseIngredient(ingredientText: string): Ingredient {
  const originalText = ingredientText.trim();
  
  // Remove common prefixes
  let cleanText = originalText
    .replace(/^[-•*]\s*/, "") // Remove bullet points
    .replace(/^\d+\.\s*/, "") // Remove numbered lists
    .trim();

  // Extract amount and unit using regex
  const amountUnitRegex = /^(\d+(?:\.\d+)?(?:\s*\d+\/\d+)?|½|⅓|⅔|¼|¾|⅛|⅜|⅝|⅞|\d+\/\d+|\d+\s+\d+\/\d+)\s*([a-zA-Z]+)?\s+(.+)/;
  const match = cleanText.match(amountUnitRegex);

  if (match) {
    const [, amountStr, unitStr, nameStr] = match;
    const amount = parseAmount(amountStr);
    const unit = unitStr ? UNIT_MAPPINGS[unitStr.toLowerCase()] || unitStr.toLowerCase() : "";
    const name = nameStr.trim();

    return {
      id: Math.random().toString(36).substring(2, 11),
      name,
      amount,
      unit,
      originalText,
    };
  }

  // If no amount/unit found, treat as whole ingredient
  return {
    id: Math.random().toString(36).substring(2, 11),
    name: cleanText,
    amount: 1,
    unit: "piece",
    originalText,
  };
}

function extractAllJsonLd(html: string): any[] {
  const scripts = [...html.matchAll(/<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)];
  const blocks: any[] = [];
  for (const s of scripts) {
    try {
      const raw = s[1].trim();
      if (!raw) continue;
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) blocks.push(...parsed);
      else blocks.push(parsed);
    } catch {}
  }
  return blocks;
}

function coerceServings(yieldVal: any): number | undefined {
  if (!yieldVal) return undefined;
  if (typeof yieldVal === "number") return yieldVal;
  const text = String(yieldVal);
  const m = text.match(/(\d+)/);
  return m ? parseInt(m[1]) : undefined;
}

function flattenInstructions(instr: any): string[] {
  if (!instr) return [];
  if (Array.isArray(instr)) {
    const out: string[] = [];
    for (const step of instr) {
      if (typeof step === "string") out.push(step);
      else if (step && typeof step === "object") {
        if (step.text) out.push(String(step.text));
        if (step.itemListElement) out.push(...flattenInstructions(step.itemListElement));
      }
    }
    return out.filter(Boolean);
  }
  if (typeof instr === "string") return [instr];
  if ((instr as any).itemListElement) return flattenInstructions((instr as any).itemListElement);
  return [];
}

function extractFromJsonLd(blocks: any[]): ParsedRecipeData | null {
  const candidates: any[] = [];
  for (const b of blocks) {
    if (!b) continue;
    if (Array.isArray(b)) candidates.push(...b);
    else if (b["@graph"]) candidates.push(...b["@graph"]);
    else candidates.push(b);
  }
  const recipe = candidates.find((x) => {
    const t = x && x["@type"];
    if (!t) return false;
    if (Array.isArray(t)) return t.includes("Recipe");
    return t === "Recipe";
  });
  if (!recipe) return null;
  const title = recipe.name || "Untitled Recipe";
  const ingredients = Array.isArray(recipe.recipeIngredient) ? recipe.recipeIngredient : [];
  const instructions = flattenInstructions(recipe.recipeInstructions);
  const servings = coerceServings(recipe.recipeYield) ?? undefined;
  return { title, ingredients, instructions, servings };
}

function extractFromHtmlHeuristics(html: string): ParsedRecipeData {
  const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
  const title = titleMatch ? titleMatch[1].replace(/\s*-\s*.*$/, "").trim() : "Untitled Recipe";
  const sectionRegex = /<h[1-6][^>]*>(ingredients|ingredient|instructions|directions)<\/h[1-6]>/gi;
  const sections = [...html.matchAll(sectionRegex)].map((m) => ({ heading: (m[1] || "").toLowerCase(), index: m.index || 0 }));
  const after = (idx: number, pattern: RegExp) => {
    const slice = html.slice(idx);
    const matches = [...slice.matchAll(pattern)];
    return matches.map((m) => m[1].replace(/<[^>]*>/g, "").trim()).filter(Boolean);
  };
  let ingredients: string[] = [];
  let instructions: string[] = [];
  const ingIdx = sections.find((s) => s.heading.startsWith("ingredient"))?.index;
  if (ingIdx !== undefined) {
    ingredients = after(ingIdx, /<li[^>]*>([\s\S]*?)<\/li>/gi);
    if (ingredients.length === 0) ingredients = after(ingIdx, /<p[^>]*>([\s\S]*?)<\/p>/gi);
  }
  const instIdx = sections.find((s) => s.heading.startsWith("instruction") || s.heading === "directions")?.index;
  if (instIdx !== undefined) {
    instructions = after(instIdx, /<li[^>]*>([\s\S]*?)<\/li>/gi);
    if (instructions.length === 0) instructions = after(instIdx, /<p[^>]*>([\s\S]*?)<\/p>/gi);
  }
  return { title, ingredients: ingredients.length ? ingredients : [""], instructions: instructions.length ? instructions : [""], servings: 4 };
}

async function llmFallbackExtract(html: string): Promise<ParsedRecipeData | null> {
  const chopped = html.slice(0, 40000);
  const prompt = `You are a recipe extractor. From the provided HTML, return strict JSON with keys: title (string), ingredients (string[]), instructions (string[]), servings (number or omit). No commentary. If missing, return empty arrays and omit servings.\nHTML:\n\n${chopped}`;
  const res = await getOpenAITextResponse([{ role: "user", content: prompt }]);
  try {
    const data = JSON.parse(res.content);
    if (data && Array.isArray(data.ingredients) && Array.isArray(data.instructions)) {
      return { title: data.title || "Untitled Recipe", ingredients: data.ingredients, instructions: data.instructions, servings: typeof data.servings === "number" ? data.servings : undefined };
    }
  } catch {}
  return null;
}

export async function parseRecipeFromUrl(url: string): Promise<ParsedRecipeData> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout
  
  try {
    const response = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0 VibecodeRecipeBot/1.0" },
      signal: controller.signal,
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const html = await response.text();
    clearTimeout(timeoutId);

    const blocks = extractAllJsonLd(html);
    const jsonld = extractFromJsonLd(blocks);
    if (jsonld && (jsonld.ingredients.length || jsonld.instructions.length)) {
      return jsonld;
    }

    const heur = extractFromHtmlHeuristics(html);
    if (heur.ingredients.some((s) => s) || heur.instructions.some((s) => s)) {
      return heur;
    }

    const llm = await llmFallbackExtract(html);
    if (llm) return llm;

    throw new Error("Could not extract recipe");
  } catch (error) {
    clearTimeout(timeoutId);
    if (error instanceof Error && error.name === 'AbortError') {
      throw new Error("Request timed out. The website may be slow or unresponsive.");
    }
    throw error;
  }
}

export function parseIngredientsFromText(ingredientsText: string[]): Ingredient[] {
  return ingredientsText.map(parseIngredient);
}

export function parseManualRecipe(title: string, ingredientsText: string, instructionsText: string, servings: number = 4): ParsedRecipeData {
  const ingredients = ingredientsText
    .split("\n")
    .map(line => line.trim())
    .filter(line => line.length > 0);

  const instructions = instructionsText
    .split("\n")
    .map(line => line.trim())
    .filter(line => line.length > 0);

  return {
    title: title.trim() || "Untitled Recipe",
    ingredients,
    instructions,
    servings,
  };
}