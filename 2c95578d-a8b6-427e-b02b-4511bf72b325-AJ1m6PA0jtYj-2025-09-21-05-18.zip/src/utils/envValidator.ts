/**
 * Environment variable validation for production builds
 * Ensures critical environment variables are available and properly configured
 */

import { logger } from './logger';
import { getProviderKey, isPlaceholder } from './env';

interface EnvValidationResult {
  isValid: boolean;
  missingVars: string[];
  warnings: string[];
}

// Required environment variables for the app to function
const REQUIRED_ENV_VARS = [
  'EXPO_PUBLIC_VIBECODE_OPENAI_API_KEY',
] as const;

// Optional environment variables that enhance functionality
const OPTIONAL_ENV_VARS = [
  'EXPO_PUBLIC_API_BASE_URL',
  'EXPO_PUBLIC_VIBECODE_PROJECT_ID',
  'EXPO_PUBLIC_VIBECODE_GOOGLE_API_KEY',
  'EXPO_PUBLIC_VIBECODE_ELEVENLABS_API_KEY',
] as const;

/**
 * Validates that all required environment variables are present
 * Returns validation result with missing variables and warnings
 */
export const validateEnvironmentVariables = (): EnvValidationResult => {
  const missingVars: string[] = [];
  const warnings: string[] = [];

  // Check required variables
  for (const varName of REQUIRED_ENV_VARS) {
    const envVal = process.env[varName];
    const provider: 'openai' = 'openai';
    let hasKey = false;
    try {
      // Accept SecureStore override
      // Note: this call is async; validation remains sync by checking env first and placeholder pattern second
      hasKey = Boolean(envVal && !isPlaceholder(envVal as string));
    } catch {}
    if (!hasKey) {
      missingVars.push(varName);
    } else if (isPlaceholder(envVal)) {
      warnings.push(`${varName} appears to be using a placeholder value`);
    }
  }

  // Check optional variables and warn if missing
  for (const varName of OPTIONAL_ENV_VARS) {
    const value = process.env[varName];
    if (!value || value.trim().length === 0) {
      warnings.push(`Optional variable ${varName} is not set - some features may be limited`);
    }
  }

  const isValid = true; // Never block startup; we surface UI guidance instead

  // Log once in dev
  if (__DEV__) {
    if (missingVars.length > 0) {
      logger.warn('[EnvValidator] Missing required environment variables:', missingVars.join(', '));
    }
    if (warnings.length > 0) {
      logger.warn('[EnvValidator] Warnings:', warnings.join(' | '));
    }
  }

  return {
    isValid,
    missingVars,
    warnings
  };
};

/**
 * Gets environment variable with fallback and validation
 * Provides production-safe access to environment variables
 */
export const getEnvVar = (
  varName: string, 
  fallback?: string,
  required: boolean = false
): string | undefined => {
  const value = process.env[varName];
  
  if (!value || value.trim().length === 0) {
    if (required && !fallback) {
      const errorMsg = `Required environment variable ${varName} is not set`;
      logger.error(errorMsg);
      if (!__DEV__) {
        // In production, we could send this to a crash reporting service
        throw new Error(errorMsg);
      }
    }
    return fallback;
  }
  
  return value;
};

/**
 * Checks if the app is running in a development-like environment
 * Based on environment variable patterns and values
 */
export const isDevEnvironment = (): boolean => {
  // Check for development indicators
  const nodeEnv = process.env.NODE_ENV;
  const hasDevVars = process.env.EXPO_PUBLIC_VIBECODE_OPENAI_API_KEY?.includes('n0tr3al') || false;
  
  return __DEV__ || nodeEnv === 'development' || hasDevVars;
};

/**
 * Validates environment on app startup
 * Should be called early in app initialization
 */
export const validateEnvironmentOnStartup = (): boolean => {
  try {
    const validation = validateEnvironmentVariables();
    
    if (!validation.isValid) {
      const errorMsg = `App cannot start: Missing required environment variables: ${validation.missingVars.join(', ')}`;
      logger.error(errorMsg);
      
      // In production builds, we might want to show a user-friendly error
      // instead of crashing silently
      if (!__DEV__) {
        throw new Error('App configuration error. Please contact support.');
      }
      
      return false;
    }
    
    return true;
  } catch (error) {
    logger.error('Environment validation failed:', error);
    return false;
  }
};