/**
 * Sequential initialization utility to prevent memory spikes during app startup
 * Executes async operations one at a time to reduce concurrent memory pressure
 */

import { logger } from './logger';
import { memoryManager } from './memoryManager';

interface InitializationTask {
  name: string;
  fn: () => Promise<void>;
  critical: boolean; // If false, failure won't stop the sequence
  timeout?: number; // Optional timeout in ms
}

class SequentialInitializer {
  private isInitializing = false;
  private currentTask: string | null = null;

  /**
   * Execute tasks sequentially with memory monitoring
   */
  async initialize(tasks: InitializationTask[]): Promise<{ success: boolean; failedTasks: string[] }> {
    if (this.isInitializing) {
      logger.warn('[SequentialInit] Initialization already in progress');
      return { success: false, failedTasks: [] };
    }

    this.isInitializing = true;
    const failedTasks: string[] = [];
    const startTime = Date.now();

    logger.log('[SequentialInit] Starting sequential initialization with', tasks.length, 'tasks');

    // Register memory cleanup for this initialization process
    memoryManager.registerCleanupTask(() => {
      logger.log('[SequentialInit] Memory pressure cleanup - interrupting initialization');
      this.currentTask = null;
    });

    try {
      for (let i = 0; i < tasks.length; i++) {
        const task = tasks[i];
        this.currentTask = task.name;

        try {
          logger.log(`[SequentialInit] Executing task ${i + 1}/${tasks.length}: ${task.name}`);
          
          const taskStartTime = Date.now();
          
          // Execute with optional timeout
          if (task.timeout) {
            await Promise.race([
              task.fn(),
              new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Task timeout')), task.timeout)
              )
            ]);
          } else {
            await task.fn();
          }

          const taskTime = Date.now() - taskStartTime;
          logger.log(`[SequentialInit] Task ${task.name} completed in ${taskTime}ms`);

          // Small delay between tasks to allow GC
          if (i < tasks.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 10));
          }

        } catch (error) {
          const errorMessage = `Task ${task.name} failed: ${error}`;
          logger.error('[SequentialInit]', errorMessage);
          
          failedTasks.push(task.name);
          
          if (task.critical) {
            logger.error(`[SequentialInit] Critical task ${task.name} failed, stopping initialization`);
            break;
          } else {
            logger.warn(`[SequentialInit] Non-critical task ${task.name} failed, continuing`);
          }
        }
      }

      const totalTime = Date.now() - startTime;
      const success = failedTasks.length === 0 || !failedTasks.some(name => 
        tasks.find(t => t.name === name)?.critical
      );

      logger.log(`[SequentialInit] Initialization ${success ? 'completed' : 'failed'} in ${totalTime}ms`);
      if (failedTasks.length > 0) {
        logger.warn('[SequentialInit] Failed tasks:', failedTasks);
      }

      return { success, failedTasks };

    } finally {
      this.isInitializing = false;
      this.currentTask = null;
    }
  }

  /**
   * Check if initialization is currently in progress
   */
  isInProgress(): boolean {
    return this.isInitializing;
  }

  /**
   * Get the current task being executed (for debugging)
   */
  getCurrentTask(): string | null {
    return this.currentTask;
  }

  /**
   * Create a memory-aware task wrapper
   */
  createTask(
    name: string, 
    fn: () => Promise<void>, 
    options: { critical?: boolean; timeout?: number } = {}
  ): InitializationTask {
    return {
      name,
      fn: async () => {
        // Record memory before task
        const memoryBefore = this.getApproximateMemoryUsage();
        
        await fn();
        
        // Record memory after task
        const memoryAfter = this.getApproximateMemoryUsage();
        const memoryDelta = memoryAfter - memoryBefore;
        
        if (memoryDelta > 1000) { // Significant memory increase
          logger.warn(`[SequentialInit] Task ${name} increased memory usage by ~${memoryDelta} objects`);
        }
      },
      critical: options.critical ?? true,
      timeout: options.timeout
    };
  }

  /**
   * Get approximate memory usage (object count estimation)
   */
  private getApproximateMemoryUsage(): number {
    // This is a rough heuristic - in production we'd use more sophisticated monitoring
    return Math.floor(performance.now() / 10); // Rough proxy for object creation over time
  }
}

// Export singleton
export const sequentialInitializer = new SequentialInitializer();

/**
 * Helper to create common initialization tasks
 */
export const createInitializationTasks = {
  /**
   * User initialization task
   */
  userInit: (initFn: () => Promise<void>) => 
    sequentialInitializer.createTask('user-initialization', initFn, { critical: false, timeout: 5000 }),

  /**
   * Store hydration task
   */
  storeHydration: (hydrateFn: () => Promise<void>) =>
    sequentialInitializer.createTask('store-hydration', hydrateFn, { critical: true, timeout: 10000 }),

  /**
   * Sync service initialization task
   */
  syncInit: (syncFn: () => Promise<void>) =>
    sequentialInitializer.createTask('sync-initialization', syncFn, { critical: false, timeout: 3000 }),

  /**
   * Environment validation task
   */
  envValidation: (validateFn: () => Promise<void>) =>
    sequentialInitializer.createTask('environment-validation', validateFn, { critical: true, timeout: 1000 }),
};