import { useRecipeStore } from "../state/recipeStore";

export const initializeSampleData = () => {
  const store = useRecipeStore.getState();
  
  // Only add sample data if no recipes exist
  if (store.recipes.length === 0) {
    // Sample Recipe 1: Classic Chocolate Chip Cookies
    store.addRecipe({
      title: "Classic Chocolate Chip Cookies",
      servings: 24,
      originalServings: 24,
      tags: ["Dessert", "Baking"],
      ingredients: [
        {
          id: "1",
          name: "all-purpose flour",
          amount: 2.25,
          unit: "cup",
          originalText: "2 1/4 cups all-purpose flour"
        },
        {
          id: "2", 
          name: "baking soda",
          amount: 1,
          unit: "tsp",
          originalText: "1 tsp baking soda"
        },
        {
          id: "3",
          name: "salt",
          amount: 1,
          unit: "tsp", 
          originalText: "1 tsp salt"
        },
        {
          id: "4",
          name: "butter, softened",
          amount: 1,
          unit: "cup",
          originalText: "1 cup butter, softened"
        },
        {
          id: "5",
          name: "granulated sugar",
          amount: 0.75,
          unit: "cup",
          originalText: "3/4 cup granulated sugar"
        },
        {
          id: "6",
          name: "brown sugar, packed",
          amount: 0.75,
          unit: "cup",
          originalText: "3/4 cup brown sugar, packed"
        },
        {
          id: "7",
          name: "large eggs",
          amount: 2,
          unit: "piece",
          originalText: "2 large eggs"
        },
        {
          id: "8",
          name: "vanilla extract",
          amount: 2,
          unit: "tsp",
          originalText: "2 tsp vanilla extract"
        },
        {
          id: "9",
          name: "chocolate chips",
          amount: 2,
          unit: "cup",
          originalText: "2 cups chocolate chips"
        }
      ],
      instructions: [
        "Preheat oven to 375°F (190°C).",
        "In a medium bowl, whisk together flour, baking soda, and salt.",
        "In a large bowl, cream together softened butter and both sugars until light and fluffy.",
        "Beat in eggs one at a time, then add vanilla extract.",
        "Gradually mix in the flour mixture until just combined.",
        "Fold in chocolate chips.",
        "Drop rounded tablespoons of dough onto ungreased baking sheets.",
        "Bake for 9-11 minutes or until golden brown around edges.",
        "Cool on baking sheet for 2 minutes before transferring to wire rack."
      ]
    });

    // Sample Recipe 2: Quick Pasta Marinara
    store.addRecipe({
      title: "Quick Pasta Marinara",
      servings: 4,
      originalServings: 4,
      tags: ["Dinner", "Quick"],
      ingredients: [
        {
          id: "10",
          name: "pasta (penne or spaghetti)",
          amount: 1,
          unit: "lb",
          originalText: "1 lb pasta"
        },
        {
          id: "11",
          name: "olive oil",
          amount: 2,
          unit: "tbsp",
          originalText: "2 tbsp olive oil"
        },
        {
          id: "12",
          name: "garlic, minced",
          amount: 3,
          unit: "clove",
          originalText: "3 cloves garlic, minced"
        },
        {
          id: "13",
          name: "crushed tomatoes",
          amount: 28,
          unit: "oz",
          originalText: "28 oz can crushed tomatoes"
        },
        {
          id: "14",
          name: "dried basil",
          amount: 1,
          unit: "tsp",
          originalText: "1 tsp dried basil"
        },
        {
          id: "15",
          name: "salt",
          amount: 0.5,
          unit: "tsp",
          originalText: "1/2 tsp salt"
        },
        {
          id: "16",
          name: "black pepper",
          amount: 0.25,
          unit: "tsp",
          originalText: "1/4 tsp black pepper"
        },
        {
          id: "17",
          name: "parmesan cheese, grated",
          amount: 0.5,
          unit: "cup",
          originalText: "1/2 cup grated parmesan cheese"
        }
      ],
      instructions: [
        "Bring a large pot of salted water to boil. Cook pasta according to package directions.",
        "While pasta cooks, heat olive oil in a large skillet over medium heat.",
        "Add minced garlic and cook for 1 minute until fragrant.",
        "Add crushed tomatoes, basil, salt, and pepper. Simmer for 10 minutes.",
        "Drain pasta and add to the sauce. Toss to combine.",
        "Serve immediately topped with grated parmesan cheese."
      ]
    });

    // Sample Recipe 3: URL-based Recipe (for testing refresh functionality)
    store.addRecipe({
      title: "Classic Banana Bread",
      url: "https://www.allrecipes.com/recipe/20144/banana-banana-bread/",
      servings: 8,
      originalServings: 8,
      tags: ["Dessert", "Baking"],
      ingredients: [
        {
          id: "24",
          name: "all-purpose flour",
          amount: 2,
          unit: "cup",
          originalText: "2 cups all-purpose flour"
        },
        {
          id: "25",
          name: "baking soda",
          amount: 1,
          unit: "tsp",
          originalText: "1 tsp baking soda"
        },
        {
          id: "26",
          name: "salt",
          amount: 0.25,
          unit: "tsp",
          originalText: "1/4 tsp salt"
        },
        {
          id: "27",
          name: "butter",
          amount: 0.5,
          unit: "cup",
          originalText: "1/2 cup butter"
        },
        {
          id: "28",
          name: "brown sugar",
          amount: 0.75,
          unit: "cup",
          originalText: "3/4 cup brown sugar"
        },
        {
          id: "29",
          name: "eggs, beaten",
          amount: 2,
          unit: "piece",
          originalText: "2 eggs, beaten"
        },
        {
          id: "30",
          name: "mashed overripe bananas",
          amount: 2.33,
          unit: "cup",
          originalText: "2 1/3 cups mashed overripe bananas"
        }
      ],
      instructions: [
        "Preheat oven to 350°F (175°C). Lightly grease a 9x5 inch loaf pan.",
        "In a large bowl, combine flour, baking soda and salt.",
        "In a separate bowl, cream together butter and brown sugar.",
        "Stir in eggs and mashed bananas until well blended.",
        "Stir banana mixture into flour mixture; stir just to moisten.",
        "Pour batter into prepared loaf pan.",
        "Bake in preheated oven for 60 to 65 minutes, until a toothpick inserted into center comes out clean.",
        "Let bread cool in pan for 10 minutes, then turn out onto a wire rack."
      ]
    });

    // Sample Recipe 4: Green Smoothie
    store.addRecipe({
      title: "Energizing Green Smoothie",
      servings: 2,
      originalServings: 2,
      tags: ["Breakfast", "Drink", "Vegan"],
      ingredients: [
        {
          id: "31",
          name: "fresh spinach",
          amount: 2,
          unit: "cup",
          originalText: "2 cups fresh spinach"
        },
        {
          id: "32",
          name: "banana, frozen",
          amount: 1,
          unit: "piece",
          originalText: "1 frozen banana"
        },
        {
          id: "33",
          name: "mango chunks, frozen",
          amount: 1,
          unit: "cup",
          originalText: "1 cup frozen mango chunks"
        },
        {
          id: "34",
          name: "coconut water",
          amount: 1,
          unit: "cup",
          originalText: "1 cup coconut water"
        },
        {
          id: "35",
          name: "lime juice",
          amount: 1,
          unit: "tbsp",
          originalText: "1 tbsp fresh lime juice"
        },
        {
          id: "36",
          name: "chia seeds",
          amount: 1,
          unit: "tbsp",
          originalText: "1 tbsp chia seeds"
        }
      ],
      instructions: [
        "Add spinach and coconut water to blender first.",
        "Add frozen banana and mango chunks.",
        "Add lime juice and chia seeds.",
        "Blend on high speed for 60-90 seconds until completely smooth.",
        "Pour into glasses and serve immediately.",
        "Optional: garnish with extra chia seeds or coconut flakes."
      ]
    });
  }
};