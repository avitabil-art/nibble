// Font utility functions for Nibble brand typography
// Falls back to system fonts while maintaining brand hierarchy

export const fontConfig = {
  heading: {
    fontFamily: 'System', // Will use SF Pro Display on iOS, Roboto on Android
    fontWeight: '700' as const, // Bold
  },
  accent: {
    fontFamily: 'System',
    fontWeight: '600' as const, // SemiBold
    textTransform: 'uppercase' as const,
  },
  body: {
    fontFamily: 'System',
    fontWeight: '400' as const, // Regular
  },
  bodyMedium: {
    fontFamily: 'System', 
    fontWeight: '500' as const, // Medium
  },
  bodyBold: {
    fontFamily: 'System',
    fontWeight: '600' as const, // SemiBold
  },
};

// Style objects for easy use in components
export const typography = {
  heading: {
    ...fontConfig.heading,
    fontSize: 24,
    lineHeight: 32,
  },
  headingLarge: {
    ...fontConfig.heading,
    fontSize: 28,
    lineHeight: 36,
  },
  subheading: {
    ...fontConfig.bodyMedium,
    fontSize: 18,
    lineHeight: 24,
  },
  accent: {
    ...fontConfig.accent,
    fontSize: 12,
    lineHeight: 16,
    letterSpacing: 0.5,
  },
  body: {
    ...fontConfig.body,
    fontSize: 14,
    lineHeight: 20,
  },
  bodyLarge: {
    ...fontConfig.body,
    fontSize: 16,
    lineHeight: 22,
  },
  caption: {
    ...fontConfig.body,
    fontSize: 12,
    lineHeight: 16,
  },
  bodyMedium: {
    ...fontConfig.bodyMedium,
    fontSize: 14,
    lineHeight: 20,
  },
};