// Dynamic import at call sites to avoid early native module init
let SecureStoreModule: typeof import("expo-secure-store") | null = null;
async function getSecureStore() {
  if (!SecureStoreModule) {
    try {
      SecureStoreModule = await import("expo-secure-store");
    } catch {
      // In case native module not ready yet; callers should handle failures gracefully
      SecureStoreModule = null as any;
    }
  }
  return SecureStoreModule;
}

export type Provider = "openai" | "anthropic" | "grok";

const SECURE_KEYS: Record<Provider, string> = {
  openai: "@ai_key_openai",
  anthropic: "@ai_key_anthropic",
  grok: "@ai_key_grok",
};

const ENV_KEYS: Record<Provider, string> = {
  openai: "EXPO_PUBLIC_VIBECODE_OPENAI_API_KEY",
  anthropic: "EXPO_PUBLIC_VIBECODE_ANTHROPIC_API_KEY",
  grok: "EXPO_PUBLIC_VIBECODE_GROK_API_KEY",
};

let cache: Partial<Record<Provider, string | undefined>> = {};

export const isPlaceholder = (v?: string | null) => {
  if (!v) return true;
  const s = v.trim();
  if (s.length === 0) return true;
  return s.includes("n0tr3al") || s === "dummy-key-for-development";
};

export async function getProviderKey(provider: Provider): Promise<string | undefined> {
  if (provider in cache) return cache[provider];

  try {
    const SS = await getSecureStore();
    const stored = SS && SS.getItemAsync ? await SS.getItemAsync(SECURE_KEYS[provider]) : null;
    if (stored && !isPlaceholder(stored)) {
      cache[provider] = stored;
      return stored;
    }
  } catch {}

  try {
    const envVal = process.env[ENV_KEYS[provider]];
    if (envVal && !isPlaceholder(envVal)) {
      cache[provider] = envVal;
      return envVal;
    }
  } catch {}

  cache[provider] = undefined;
  return undefined;
}

export async function setProviderKey(provider: Provider, value: string): Promise<void> {
  if (!value || isPlaceholder(value)) {
    const SS = await getSecureStore();
    if (SS && SS.deleteItemAsync) await SS.deleteItemAsync(SECURE_KEYS[provider]);
    cache[provider] = undefined;
    return;
  }
  const SS = await getSecureStore();
  if (SS && SS.setItemAsync) await SS.setItemAsync(SECURE_KEYS[provider], value);
  cache[provider] = value;
}

export async function clearProviderKey(provider: Provider): Promise<void> {
  const SS = await getSecureStore();
  if (SS && SS.deleteItemAsync) await SS.deleteItemAsync(SECURE_KEYS[provider]);
  cache[provider] = undefined;
}

export async function anyAiConfigured(): Promise<boolean> {
  const [oa, an, gr] = await Promise.all([
    getProviderKey("openai"),
    getProviderKey("anthropic"),
    getProviderKey("grok"),
  ]);
  return Boolean(oa || an || gr);
}
