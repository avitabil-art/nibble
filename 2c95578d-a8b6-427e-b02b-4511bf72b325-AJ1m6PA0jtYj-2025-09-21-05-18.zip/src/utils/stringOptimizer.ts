/**
 * String optimization utilities to reduce memory allocation pressure in Hermes
 * Implements string interning, caching, and memory-efficient operations
 */

import { logger } from './logger';

// String cache for frequently used strings to reduce allocations
const STRING_CACHE = new Map<string, string>();
const CACHE_MAX_SIZE = 1000; // Prevent cache from growing too large

// Intern cache for repeated strings
const INTERN_CACHE = new Map<string, string>();
const INTERN_MAX_SIZE = 500;

/**
 * String interning to reuse identical strings and reduce memory
 */
export const internString = (str: string): string => {
  if (typeof str !== 'string' || str.length === 0) {
    return str;
  }

  // Check if already interned
  const existing = INTERN_CACHE.get(str);
  if (existing) {
    return existing;
  }

  // Clean cache if it gets too large
  if (INTERN_CACHE.size >= INTERN_MAX_SIZE) {
    // Remove oldest entries (simple FIFO)
    const keysToDelete = Array.from(INTERN_CACHE.keys()).slice(0, Math.floor(INTERN_MAX_SIZE / 2));
    keysToDelete.forEach(key => INTERN_CACHE.delete(key));
  }

  INTERN_CACHE.set(str, str);
  return str;
};

/**
 * Cache frequently used category names and tags
 */
export const internCategory = (category: string): string => {
  if (!category || typeof category !== 'string') {
    return '';
  }
  
  const normalized = category.trim().toLowerCase();
  return internString(titleCase(normalized));
};

/**
 * Memory-efficient title case implementation
 */
export const titleCase = (str: string): string => {
  if (!str || typeof str !== 'string') return '';
  
  // Check cache first
  const cacheKey = `title_${str}`;
  const cached = STRING_CACHE.get(cacheKey);
  if (cached) {
    return cached;
  }

  // Efficient title case without excessive string allocations
  let result = '';
  let capitalize = true;
  
  for (let i = 0; i < str.length; i++) {
    const char = str[i];
    if (char === ' ' || char === '-' || char === '_') {
      result += ' ';
      capitalize = true;
    } else if (capitalize) {
      result += char.toUpperCase();
      capitalize = false;
    } else {
      result += char.toLowerCase();
    }
  }

  // Cache the result
  if (STRING_CACHE.size < CACHE_MAX_SIZE) {
    STRING_CACHE.set(cacheKey, result);
  }

  return result;
};

/**
 * Memory-efficient category normalization
 */
export const normalizeCategories = (categories: string[]): string[] => {
  if (!Array.isArray(categories) || categories.length === 0) {
    return [];
  }

  const seen = new Set<string>();
  const result: string[] = [];
  
  for (const category of categories) {
    if (!category || typeof category !== 'string') continue;
    
    const normalized = category.trim();
    if (normalized.length === 0) continue;
    
    const key = normalized.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      result.push(internCategory(normalized));
    }
  }
  
  return result;
};

/**
 * Efficient string concatenation for IDs and paths
 */
export const concatStrings = (...parts: string[]): string => {
  if (parts.length === 0) return '';
  if (parts.length === 1) return parts[0] || '';
  
  // Use array join for efficiency with multiple parts
  return parts.filter(part => part && part.length > 0).join('');
};

/**
 * Memory-safe JSON stringification with size limits
 */
export const safeJSONStringify = (obj: any, maxSize = 1024 * 1024): string => {
  try {
    const str = JSON.stringify(obj);
    
    if (str.length > maxSize) {
      logger.warn(`[StringOptimizer] Large JSON object detected: ${str.length} bytes, truncating`);
      
      // Try to stringify a simplified version
      if (typeof obj === 'object' && obj !== null) {
        // For arrays, take only first few items
        if (Array.isArray(obj)) {
          const simplified = obj.slice(0, Math.min(10, obj.length));
          return JSON.stringify(simplified);
        }
        
        // For objects, take only first few keys
        const keys = Object.keys(obj).slice(0, 10);
        const simplified = keys.reduce((acc, key) => {
          acc[key] = obj[key];
          return acc;
        }, {} as any);
        
        return JSON.stringify(simplified);
      }
    }
    
    return str;
  } catch (error) {
    logger.error('[StringOptimizer] JSON stringify failed:', error);
    return '{}';
  }
};

/**
 * Efficient string comparison that avoids unnecessary operations
 */
export const fastStringCompare = (a: string, b: string): boolean => {
  // Quick reference check first
  if (a === b) return true;
  
  // Length check
  if (!a || !b || a.length !== b.length) return false;
  
  return a === b;
};

/**
 * Clean up string caches to prevent memory leaks
 */
export const cleanupStringCaches = (): void => {
  const totalSize = STRING_CACHE.size + INTERN_CACHE.size;
  
  if (totalSize > 0) {
    logger.log(`[StringOptimizer] Cleaning up string caches (${totalSize} entries)`);
    
    STRING_CACHE.clear();
    INTERN_CACHE.clear();
  }
};

/**
 * Get cache statistics for monitoring
 */
export const getStringCacheStats = () => {
  return {
    stringCacheSize: STRING_CACHE.size,
    internCacheSize: INTERN_CACHE.size,
    totalCachedStrings: STRING_CACHE.size + INTERN_CACHE.size
  };
};

/**
 * Batch process categories to reduce allocation pressure
 */
export const batchNormalizeCategories = (categoryArrays: string[][]): string[][] => {
  if (!Array.isArray(categoryArrays) || categoryArrays.length === 0) {
    return [];
  }

  // Process in batches to avoid memory spikes
  const BATCH_SIZE = 50;
  const results: string[][] = [];
  
  for (let i = 0; i < categoryArrays.length; i += BATCH_SIZE) {
    const batch = categoryArrays.slice(i, i + BATCH_SIZE);
    const batchResults = batch.map(categories => normalizeCategories(categories));
    results.push(...batchResults);
    
    // Small delay between batches to allow GC
    if (i + BATCH_SIZE < categoryArrays.length) {
      // Note: In real implementation, we might use setTimeout with 0 delay
      // For now, we'll just continue synchronously
    }
  }
  
  return results;
};