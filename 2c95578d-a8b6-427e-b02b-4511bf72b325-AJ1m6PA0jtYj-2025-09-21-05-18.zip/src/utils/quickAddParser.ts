export type QuickAddParsed = {
  name: string;
  qty?: number; // number of containers or pieces
  sizeAmount?: number; // pack size amount (e.g., 32)
  sizeUnit?: string; // oz, lb, g, kg, mL, L, gal, qt, pt
  containerUnit?: string; // can, bottle, pack, box, bag, jar, carton, dozen, piece
  directUnit?: string; // when the unit applies directly to the item (e.g., 2 lb potatoes)
};

const CONTAINERS = [
  "can", "cans",
  "bottle", "bottles",
  "pack", "box", "bag", "jar", "carton",
  "dozen", "piece", "pieces"
];

const CONTAINER_NORMALIZE: Record<string, string> = {
  cans: "can",
  bottles: "bottle",
  pieces: "piece",
};

const SIZE_UNITS = ["oz", "lb", "g", "kg", "ml", "l", "gal", "qt", "pt", "ct"];
const SIZE_NORMALIZE: Record<string, string> = {
  ml: "mL",
  l: "L",
};

function toNumber(input: string | undefined): number | undefined {
  if (!input) return undefined;
  const n = parseFloat(input.replace(",", "."));
  return isNaN(n) ? undefined : n;
}

function normalizeUnit(u?: string): string | undefined {
  if (!u) return undefined;
  const lu = u.toLowerCase();
  if (SIZE_NORMALIZE[lu]) return SIZE_NORMALIZE[lu];
  return lu;
}

function normalizeContainer(c?: string): string | undefined {
  if (!c) return undefined;
  const lc = c.toLowerCase();
  if (CONTAINER_NORMALIZE[lc]) return CONTAINER_NORMALIZE[lc];
  return lc;
}

// Attempt to parse a single token/input like:
// - "2 32oz cans diced tomatoes"
// - "2x 1 lb chicken thighs"
// - "1 lb ground beef"
// - "eggs 1 dozen"
// - "milk"
export function parseQuickAdd(input: string): QuickAddParsed {
  let text = (input || "").trim();
  // Normalize unicode multipliers and hyphens
  text = text.replace(/[×x]\s*(\d+)/i, "$1");
  text = text.replace(/\s*-/g, " ");

  // Split into tokens
  const tokens = text.split(/\s+/).filter(Boolean);
  let qty: number | undefined;
  let sizeAmount: number | undefined;
  let sizeUnit: string | undefined;
  let containerUnit: string | undefined;
  let directUnit: string | undefined;

  // Pattern 1: leading quantity (e.g., 2 or 2x)
  if (tokens.length > 0) {
    const mQty = tokens[0].match(/^\d+(?:\.\d+)?$/);
    if (mQty) {
      qty = toNumber(tokens.shift());
    }
  }

  // Next could be size (e.g., 32oz or 1 lb)
  if (tokens.length > 0) {
    // Combined token like 32oz / 1lb / 500g / 1L
    let mSize = tokens[0].match(/^(\d+(?:\.\d+)?)([a-zA-Z]+)$/);
    if (mSize && SIZE_UNITS.includes(mSize[2].toLowerCase())) {
      sizeAmount = toNumber(mSize[1]);
      sizeUnit = normalizeUnit(mSize[2]);
      tokens.shift();
    } else if (tokens.length > 1) {
      // Separated token like 32 oz / 1 lb
      const mNum = tokens[0].match(/^(\d+(?:\.\d+)?)$/);
      const mUnit = tokens[1].match(/^([a-zA-Z]+)$/);
      if (mNum && mUnit && SIZE_UNITS.includes(mUnit[1].toLowerCase())) {
        sizeAmount = toNumber(mNum[1]);
        sizeUnit = normalizeUnit(mUnit[1]);
        tokens.shift();
        tokens.shift();
      }
    }
  }

  // Container word if present (can/cans, bottle, pack, box, bag, jar, carton, dozen, piece)
  if (tokens.length > 0) {
    const cont = tokens[0].toLowerCase();
    if (CONTAINERS.includes(cont)) {
      containerUnit = normalizeContainer(tokens.shift());
    }
  }

  // Special case: patterns like "eggs 1 dozen"
  if (!containerUnit && tokens.length > 1) {
    const backNum = tokens[tokens.length - 2];
    const backWord = tokens[tokens.length - 1].toLowerCase();
    if (/^\d+(?:\.\d+)?$/.test(backNum) && CONTAINERS.includes(backWord)) {
      qty = qty ?? toNumber(backNum);
      containerUnit = normalizeContainer(backWord);
      tokens.pop();
      tokens.pop();
    }
  }

  // If we have a size but no container, and size unit is a weight/volume, treat as direct measure
  // E.g., "1 lb ground beef" => amount=1, unit=lb
  if (!containerUnit && sizeAmount !== undefined && sizeUnit) {
    directUnit = sizeUnit;
    // Use qty as sizeAmount if qty is present without an explicit separate amount
    if (qty !== undefined && (sizeAmount === undefined || sizeAmount === 0)) {
      sizeAmount = qty;
      qty = undefined;
    }
  }

  const name = tokens.join(" ").trim();

  // If no structure detected, fallback to name only
  return {
    name,
    qty,
    sizeAmount,
    sizeUnit,
    containerUnit,
    directUnit,
  };
}

export function splitMulti(input: string): string[] {
  return input
    .split(/\s*,\s*/)
    .map((s) => s.trim())
    .filter(Boolean);
}
