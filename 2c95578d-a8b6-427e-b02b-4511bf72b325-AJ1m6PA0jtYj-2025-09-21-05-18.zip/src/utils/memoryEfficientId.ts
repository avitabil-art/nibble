/**
 * Memory-efficient ID generation to reduce string allocation pressure in Hermes
 * Replaces Math.random().toString(36) with more memory-friendly alternatives
 */

// ID counter for sequential IDs (more memory efficient than random)
let idCounter = 0;
const startTime = Date.now();

// Cache for frequently reused ID prefixes
const ID_PREFIXES = {
  recipe: 'r_',
  list: 'l_',
  item: 'i_',
  user: 'u_',
  sync: 's_',
} as const;

/**
 * Generate memory-efficient sequential ID
 * Uses counter + timestamp instead of Math.random() to reduce GC pressure
 */
export const generateId = (prefix?: keyof typeof ID_PREFIXES): string => {
  idCounter = (idCounter + 1) % 999999; // Reset counter to prevent overflow
  const prefixStr = prefix ? ID_PREFIXES[prefix] : '';
  
  // Use hex representation for smaller strings
  const timeComponent = (Date.now() - startTime).toString(16);
  const counterComponent = idCounter.toString(16).padStart(3, '0');
  
  return `${prefixStr}${timeComponent}${counterComponent}`;
};

/**
 * Generate short ID for temporary/local objects
 * Even more memory efficient for objects that don't need persistence
 */
export const generateShortId = (): string => {
  idCounter = (idCounter + 1) % 9999;
  return idCounter.toString(16);
};

/**
 * ID validation utility
 */
export const isValidId = (id: string): boolean => {
  return typeof id === 'string' && id.length > 0 && id.length < 50;
};

/**
 * Memory-safe ID comparison
 * Reduces string operations in hot paths
 */
export const compareIds = (a: string, b: string): boolean => {
  return a === b;
};