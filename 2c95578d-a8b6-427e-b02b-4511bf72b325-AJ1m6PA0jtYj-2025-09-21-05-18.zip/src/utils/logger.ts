/**
 * Production-safe logging utility
 * All console statements should go through this utility to ensure they're properly guarded
 */

interface Logger {
  log: (message: string, ...args: any[]) => void;
  warn: (message: string, ...args: any[]) => void;
  error: (message: string, ...args: any[]) => void;
  info: (message: string, ...args: any[]) => void;
  debug: (message: string, ...args: any[]) => void;
}

export const logger: Logger = {
  log: (message: string, ...args: any[]) => {
    if (__DEV__) {
      console.log(message, ...args);
    }
  },
  
  warn: (message: string, ...args: any[]) => {
    if (__DEV__) {
      console.warn(message, ...args);
    }
  },
  
  error: (message: string, ...args: any[]) => {
    if (__DEV__) {
      console.error(message, ...args);
    }
  },
  
  info: (message: string, ...args: any[]) => {
    if (__DEV__) {
      console.info(message, ...args);
    }
  },
  
  debug: (message: string, ...args: any[]) => {
    if (__DEV__) {
      console.debug(message, ...args);
    }
  }
};

// For critical errors that need to be tracked in production
export const logCriticalError = (error: Error | string, context?: string) => {
  if (__DEV__) {
    console.error(`[CRITICAL ERROR] ${context || 'Unknown context'}:`, error);
  }
  // In production, you could send this to a crash reporting service
  // like Sentry, Bugsnag, etc.
};