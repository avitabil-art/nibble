import { Ingredient } from "../types/recipe";

// Canonical bases
// volume base: tsp; weight base: g; piece base: piece (no conversion)
const VOLUME_UNITS = {
  tsp: 1,
  teaspoon: 1,
  teaspoons: 1,
  tablespoon: 3, // 1 tbsp = 3 tsp
  tablespoons: 3,
  tbsp: 3,
  tbs: 3,
  cup: 48, // 1 cup = 48 tsp
  cups: 48,
  pint: 96, // 1 pint = 2 cups = 96 tsp
  pints: 96,
  quart: 192, // 1 quart = 4 cups = 192 tsp
  quarts: 192,
  gallon: 768, // 1 gallon = 16 cups = 768 tsp
  gallons: 768,
  ml: 1 / 5, // 5 mL per tsp (US standard)
  mL: 1 / 5,
  milliliter: 1 / 5,
  milliliters: 1 / 5,
  l: 200, // 1 L = 1000 mL = 200 tsp
  L: 200,
  liter: 200,
  liters: 200,
  floz: 6, // 1 fl oz = 6 tsp (US)
  "fl oz": 6,
  "fluid ounce": 6,
  "fluid ounces": 6,
  drop: 1/60, // 1 drop ≈ 1/60 tsp
  drops: 1/60,
  dash: 1/8, // 1 dash ≈ 1/8 tsp
  dashes: 1/8,
  pinch: 1/16, // 1 pinch ≈ 1/16 tsp
  pinches: 1/16,
} as const;

const WEIGHT_UNITS = {
  g: 1,
  gram: 1,
  grams: 1,
  kg: 1000,
  kilogram: 1000,
  kilograms: 1000,
  mg: 0.001, // 1 mg = 0.001 g
  milligram: 0.001,
  milligrams: 0.001,
  oz: 28.349523125,
  ounce: 28.349523125,
  ounces: 28.349523125,
  lb: 453.59237,
  lbs: 453.59237,
  pound: 453.59237,
  pounds: 453.59237,
  stone: 6350.29318, // 1 stone = 14 lbs
  stones: 6350.29318,
} as const;

const PIECE_UNITS = new Set([
  "piece",
  "pieces",
  "whole",
  "clove",
  "cloves",
  "slice",
  "slices",
  "egg",
  "eggs",
  "head",
  "heads",
  "bunch",
  "bunches",
  "stalk",
  "stalks",
  "bulb",
  "bulbs",
  "leaf",
  "leaves",
  "sprig",
  "sprigs",
  "stem",
  "stems",
  "can",
  "cans",
  "jar",
  "jars",
  "bottle",
  "bottles",
  "package",
  "packages",
  "bag",
  "bags",
  "box",
  "boxes",
  "container",
  "containers",
  "stick",
  "sticks",
  "sheet",
  "sheets",
  "strip",
  "strips",
  "layer",
  "layers",
]);

export type CanonicalType = "volume" | "weight" | "piece";

function classifyUnit(u: string): CanonicalType | null {
  const unit = (u || "").toLowerCase();
  if (unit in VOLUME_UNITS) return "volume";
  if (unit in WEIGHT_UNITS) return "weight";
  if (PIECE_UNITS.has(unit) || unit === "") return "piece"; // empty unit treated as piece
  return null;
}

export function toCanonical(amount: number, unit: string): { type: CanonicalType; value: number; displayUnit: string } {
  const t = classifyUnit(unit || "piece");
  if (t === "volume") {
    const tsp = amount * (VOLUME_UNITS as any)[(unit || "tsp").toLowerCase()];
    return { type: "volume", value: tsp, displayUnit: "tsp" };
  }
  if (t === "weight") {
    const g = amount * (WEIGHT_UNITS as any)[(unit || "g").toLowerCase()];
    return { type: "weight", value: g, displayUnit: "g" };
  }
  // piece
  return { type: "piece", value: amount, displayUnit: unit || "piece" };
}

function roundToStep(x: number, step: number) {
  return Math.round(x / step) * step;
}

function fractionRound(x: number, denominators = [2, 3, 4, 8]) {
  const whole = Math.trunc(x);
  const frac = x - whole;
  let bestNum = 0;
  let bestDen = 1;
  let bestDiff = Infinity;
  for (const den of denominators) {
    const num = Math.round(frac * den);
    const diff = Math.abs(frac - num / den);
    if (diff < bestDiff) {
      bestDiff = diff;
      bestNum = num;
      bestDen = den;
    }
  }
  const normalized = whole + bestNum / bestDen;
  // Snap tiny values to 0
  return Math.abs(normalized) < 1e-6 ? 0 : normalized;
}

// Smart conversion options for different measurement ranges
const VOLUME_CONVERSIONS = [
  { threshold: 768, factor: 768, unit: "gallon", step: 0.25 }, // 1 gallon+
  { threshold: 192, factor: 192, unit: "quart", step: 0.25 }, // 1 quart+
  { threshold: 96, factor: 96, unit: "pint", step: 0.25 }, // 1 pint+
  { threshold: 48, factor: 48, unit: "cup", step: 0.125 }, // 1 cup+
  { threshold: 6, factor: 6, unit: "fl oz", step: 0.25 }, // 1 fl oz+
  { threshold: 3, factor: 3, unit: "tbsp", step: 0.25 }, // 1 tbsp+
  { threshold: 1, factor: 1, unit: "tsp", step: 0.125 }, // 1 tsp+
  { threshold: 0.25, factor: 1, unit: "tsp", step: 0.25 }, // 1/4 tsp+
  { threshold: 0.125, factor: 8, unit: "dash", step: 1 }, // 1/8 tsp = 1 dash
  { threshold: 0.0625, factor: 16, unit: "pinch", step: 1 }, // 1/16 tsp = 1 pinch
];

const WEIGHT_CONVERSIONS = [
  { threshold: 453.59237, factor: 453.59237, unit: "lb", step: 0.125 }, // 1 lb+
  { threshold: 113.398, factor: 28.349523125, unit: "oz", step: 0.25 }, // 4 oz+
  { threshold: 28.349523125, factor: 28.349523125, unit: "oz", step: 0.125 }, // 1 oz+
  { threshold: 100, factor: 1, unit: "g", step: 5 }, // 100g+ (5g steps)
  { threshold: 10, factor: 1, unit: "g", step: 1 }, // 10g+ (1g steps)
  { threshold: 1, factor: 1, unit: "g", step: 0.5 }, // 1g+ (0.5g steps)
];

function findBestVolumeUnit(tsp: number): { amount: number; unit: string } {
  // Special handling for very small amounts
  if (tsp < 0.0625) return { amount: 1, unit: "drop" };
  
  // Find the best conversion based on practical cooking measurements
  for (const conv of VOLUME_CONVERSIONS) {
    if (tsp >= conv.threshold) {
      let amount = tsp / conv.factor;
      amount = roundToStep(amount, conv.step);
      
      // Ensure we don't round down to 0
      if (amount > 0) {
        return { amount, unit: conv.unit };
      }
    }
  }
  
  // Fallback to drops for very small amounts
  return { amount: Math.max(1, Math.round(tsp * 60)), unit: "drop" };
}

function findBestWeightUnit(grams: number): { amount: number; unit: string } {
  // Special handling for very small amounts
  if (grams < 0.1) return { amount: 1, unit: "pinch" };
  
  // Find the best conversion based on practical cooking measurements
  for (const conv of WEIGHT_CONVERSIONS) {
    if (grams >= conv.threshold) {
      let amount = grams / conv.factor;
      amount = roundToStep(amount, conv.step);
      
      // Ensure we don't round down to 0
      if (amount > 0) {
        return { amount, unit: conv.unit };
      }
    }
  }
  
  // Fallback for very small amounts
  if (grams < 1) {
    const mg = Math.round(grams * 1000);
    return { amount: mg, unit: "mg" };
  }
  
  return { amount: Math.round(grams * 10) / 10, unit: "g" };
}

export function fromCanonical(value: number, type: CanonicalType, preferredPieceUnit?: string): { amount: number; unit: string } {
  if (type === "volume") {
    return findBestVolumeUnit(value);
  }
  
  if (type === "weight") {
    return findBestWeightUnit(value);
  }
  
  // piece - use fractions for practical cooking
  let amt = fractionRound(value, [2, 3, 4, 6, 8, 12]); // More fraction options
  if (amt > 0 && amt < 0.125) amt = 0.125; // Minimum 1/8 for cooking practicality
  if (amt === 0) amt = 0.125; // Don't allow 0 amounts
  
  return { amount: amt, unit: preferredPieceUnit || "piece" };
}

export function buildBaseIngredients(ingredients: Ingredient[]): Ingredient[] {
  return ingredients.map((ing) => {
    const canon = toCanonical(ing.amount, ing.unit);
    return {
      ...ing,
      amount: canon.value,
      unit: canon.type === "volume" ? "tsp" : canon.type === "weight" ? "g" : (ing.unit || "piece"),
    };
  });
}

export function scaleFromBase(baseIngredients: Ingredient[], factor: number, originalDisplayUnits: Ingredient[]): Ingredient[] {
  return baseIngredients.map((base, idx) => {
    const scaledValue = base.amount * factor; // amount is canonical in base
    const type: CanonicalType = base.unit === "tsp" ? "volume" : base.unit === "g" ? "weight" : "piece";
    const preferredPieceUnit = type === "piece" ? (originalDisplayUnits[idx]?.unit || base.unit) : undefined;
    const out = fromCanonical(scaledValue, type, preferredPieceUnit);
    return {
      ...base,
      amount: out.amount,
      unit: out.unit,
    };
  });
}