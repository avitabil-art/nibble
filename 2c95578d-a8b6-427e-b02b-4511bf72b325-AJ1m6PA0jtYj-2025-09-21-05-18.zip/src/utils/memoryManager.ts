/**
 * Memory management utilities for Hermes engine optimization
 * Handles object lifecycle, collection cleanup, and memory pressure detection
 */

import { logger } from './logger';

interface MemoryStats {
  timestamp: number;
  objectCount: number;
  collectionSizes: Record<string, number>;
}

class MemoryManager {
  private stats: MemoryStats[] = [];
  private cleanupTasks: (() => void)[] = [];
  private maxStatsHistory = 10; // Keep only recent stats
  private memoryPressureThreshold = 1000; // Object count threshold

  /**
   * Register a cleanup task to be called during memory pressure
   */
  registerCleanupTask(task: () => void): void {
    this.cleanupTasks.push(task);
  }

  /**
   * Record memory usage statistics
   */
  recordStats(objectCount: number, collectionSizes: Record<string, number>): void {
    const stats: MemoryStats = {
      timestamp: Date.now(),
      objectCount,
      collectionSizes
    };

    this.stats.push(stats);
    
    // Keep only recent stats to prevent memory leaks
    if (this.stats.length > this.maxStatsHistory) {
      this.stats = this.stats.slice(-this.maxStatsHistory);
    }

    // Check for memory pressure
    if (this.isMemoryPressureDetected(stats)) {
      this.handleMemoryPressure();
    }
  }

  /**
   * Check if we're experiencing memory pressure
   */
  private isMemoryPressureDetected(stats: MemoryStats): boolean {
    // Simple heuristic: too many objects or rapid growth
    if (stats.objectCount > this.memoryPressureThreshold) {
      return true;
    }

    // Check for rapid growth in recent history
    if (this.stats.length >= 3) {
      const recent = this.stats.slice(-3);
      const growthRate = recent[2].objectCount - recent[0].objectCount;
      return growthRate > 500; // Rapid growth threshold
    }

    return false;
  }

  /**
   * Handle memory pressure by running cleanup tasks
   */
  private handleMemoryPressure(): void {
    logger.warn('[MemoryManager] Memory pressure detected, running cleanup tasks');
    
    this.cleanupTasks.forEach((task, index) => {
      try {
        task();
      } catch (error) {
        logger.error(`[MemoryManager] Cleanup task ${index} failed:`, error);
      }
    });

    // Force a small delay to let GC run
    if (global.gc) {
      try {
        global.gc();
      } catch (error) {
        // GC not available, ignore
      }
    }
  }

  /**
   * Safe collection cleanup utility
   */
  cleanupCollection<T>(collection: T[], maxSize: number, keepMostRecent = true): T[] {
    if (collection.length <= maxSize) {
      return collection;
    }

    logger.warn(`[MemoryManager] Trimming collection from ${collection.length} to ${maxSize} items`);
    
    return keepMostRecent 
      ? collection.slice(-maxSize)
      : collection.slice(0, maxSize);
  }

  /**
   * Safe Map cleanup - convert to plain object for better memory usage
   */
  mapToObject<K extends string | number, V>(map: Map<K, V>): Record<K, V> {
    const obj = {} as Record<K, V>;
    
    map.forEach((value, key) => {
      obj[key] = value;
    });
    
    // Clear the original map to free memory immediately
    map.clear();
    
    return obj;
  }

  /**
   * Create object from Map without clearing original (safer)
   */
  mapToObjectSafe<K extends string | number, V>(map: Map<K, V>): Record<K, V> {
    const obj = {} as Record<K, V>;
    
    map.forEach((value, key) => {
      obj[key] = value;
    });
    
    return obj;
  }

  /**
   * Object to Map conversion (when needed)
   */
  objectToMap<K extends string | number, V>(obj: Record<K, V>): Map<K, V> {
    const map = new Map<K, V>();
    
    Object.entries(obj).forEach(([key, value]) => {
      map.set(key as K, value as V);
    });
    
    return map;
  }

  /**
   * Get current memory statistics
   */
  getStats(): MemoryStats | null {
    return this.stats.length > 0 ? this.stats[this.stats.length - 1] : null;
  }

  /**
   * Clear all statistics and cleanup tasks (for app reset)
   */
  reset(): void {
    this.stats.length = 0;
    this.cleanupTasks.length = 0;
  }
}

// Export singleton instance
export const memoryManager = new MemoryManager();

/**
 * Decorator for methods that should be memory-aware
 */
export function memoryAware<T extends any[], R>(
  target: any,
  propertyKey: string,
  descriptor: PropertyDescriptor
) {
  const originalMethod = descriptor.value;

  descriptor.value = function (...args: T): R {
    const startTime = performance.now();
    
    try {
      const result = originalMethod.apply(this, args);
      return result;
    } finally {
      const endTime = performance.now();
      if (endTime - startTime > 100) { // Log slow operations
        logger.warn(`[MemoryAware] Slow operation detected: ${propertyKey} took ${endTime - startTime}ms`);
      }
    }
  };

  return descriptor;
}