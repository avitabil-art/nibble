import { AppState, AppStateStatus } from 'react-native';
import { syncService } from '../api/sync-service';
import { logger } from './logger';

/**
 * Manages sync lifecycle based on app state
 * Starts/stops sync when app becomes active/inactive
 */
class SyncManager {
  private appStateSubscription: any = null;

  /**
   * Initialize sync manager - call once on app startup
   */
  initialize() {
    // Start sync immediately if app is active
    if (AppState.currentState === 'active') {
      this.startSync();
    }

    // Listen for app state changes
    this.appStateSubscription = AppState.addEventListener('change', this.handleAppStateChange);
  }

  /**
   * Cleanup sync manager - call on app shutdown
   */
  cleanup() {
    this.stopSync();
    
    if (this.appStateSubscription) {
      this.appStateSubscription.remove();
      this.appStateSubscription = null;
    }
  }

  /**
   * Handle app state changes
   */
  private handleAppStateChange = (nextAppState: AppStateStatus) => {
    if (nextAppState === 'active') {
      // App became active - start syncing
      this.startSync();
    } else if (nextAppState === 'background' || nextAppState === 'inactive') {
      // App went to background - stop syncing to save battery
      this.stopSync();
    }
  };

  /**
   * Start sync service
   */
  private startSync() {
    logger.log('[SyncManager] Starting sync...');
    syncService.startSync();
  }

  /**
   * Stop sync service
   */
  private stopSync() {
    logger.log('[SyncManager] Stopping sync...');
    syncService.stopSync();
  }

  /**
   * Force immediate sync
   */
  syncNow() {
    // This triggers the sync service to perform an immediate sync
    syncService.startSync();
  }
}

// Export singleton instance
export const syncManager = new SyncManager();