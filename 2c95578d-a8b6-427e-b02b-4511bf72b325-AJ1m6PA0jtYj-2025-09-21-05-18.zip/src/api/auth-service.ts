import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Crypto from 'expo-crypto';
import { User } from '../types/recipe';
import { logger } from '../utils/logger';

const USER_STORAGE_KEY = '@nibble_user';
const DEVICE_ID_KEY = '@nibble_device_id';

/**
 * Simple authentication service for family collaboration
 * Uses device-based identity without passwords or complex auth flows
 */
class AuthService {
  private currentUser: User | null = null;
  private deviceId: string | null = null;

  /**
   * Initialize the auth service - call on app startup
   */
  async initialize(): Promise<User | null> {
    try {
      // Get or create device ID
      this.deviceId = await this.getOrCreateDeviceId();
      
      // Try to load existing user
      const userData = await AsyncStorage.getItem(USER_STORAGE_KEY);
      if (userData) {
        this.currentUser = JSON.parse(userData);
        // Ensure dates are properly parsed
        if (this.currentUser) {
          this.currentUser.createdAt = new Date(this.currentUser.createdAt);
        }
        return this.currentUser;
      }
      
      return null;
    } catch (error) {
      logger.error('Error initializing auth service:', error);
      return null;
    }
  }

  /**
   * Create a new user with display name
   */
  async createUser(displayName: string): Promise<User> {
    try {
      const deviceId = await this.getOrCreateDeviceId();
      
      const user: User = {
        id: await this.generateUserId(),
        name: displayName.trim(),
        deviceId,
        createdAt: new Date(),
      };

      await AsyncStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
      this.currentUser = user;
      
      return user;
    } catch (error) {
      logger.error('Error creating user:', error);
      throw new Error('Failed to create user');
    }
  }

  /**
   * Update current user's display name
   */
  async updateUserName(displayName: string): Promise<User> {
    if (!this.currentUser) {
      throw new Error('No current user to update');
    }

    try {
      const updatedUser = {
        ...this.currentUser,
        name: displayName.trim(),
      };

      await AsyncStorage.setItem(USER_STORAGE_KEY, JSON.stringify(updatedUser));
      this.currentUser = updatedUser;
      
      return updatedUser;
    } catch (error) {
      logger.error('Error updating user name:', error);
      throw new Error('Failed to update user name');
    }
  }

  /**
   * Get current user
   */
  getCurrentUser(): User | null {
    return this.currentUser;
  }

  /**
   * Check if user is set up
   */
  isUserSetup(): boolean {
    return this.currentUser !== null;
  }

  /**
   * Generate a 6-digit alphanumeric share code
   */
  async generateShareCode(): Promise<string> {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Exclude confusing chars like I, O, 1, 0
    let code = '';
    
    for (let i = 0; i < 6; i++) {
      const randomBytes = await Crypto.getRandomBytesAsync(1);
      const randomIndex = randomBytes[0] % chars.length;
      code += chars[randomIndex];
    }
    
    return code;
  }

  /**
   * Generate a unique user ID
   */
  private async generateUserId(): Promise<string> {
    const randomBytes = await Crypto.getRandomBytesAsync(16);
    return Crypto.digestStringAsync(
      Crypto.CryptoDigestAlgorithm.SHA256,
      randomBytes.join('') + Date.now().toString()
    );
  }

  /**
   * Get or create device ID
   */
  private async getOrCreateDeviceId(): Promise<string> {
    if (this.deviceId) {
      return this.deviceId;
    }

    try {
      const existingDeviceId = await AsyncStorage.getItem(DEVICE_ID_KEY);
      if (existingDeviceId) {
        this.deviceId = existingDeviceId;
        return existingDeviceId;
      }

      // Generate new device ID
      const randomBytes = await Crypto.getRandomBytesAsync(16);
      const deviceId = await Crypto.digestStringAsync(
        Crypto.CryptoDigestAlgorithm.SHA256,
        randomBytes.join('') + Date.now().toString()
      );

      await AsyncStorage.setItem(DEVICE_ID_KEY, deviceId);
      this.deviceId = deviceId;
      
      return deviceId;
    } catch (error) {
      logger.error('Error managing device ID:', error);
      // Fallback to timestamp-based ID
      const fallbackId = 'device_' + Date.now().toString(36);
      this.deviceId = fallbackId;
      return fallbackId;
    }
  }

  /**
   * Clear all user data (for testing/reset purposes)
   */
  async clearUserData(): Promise<void> {
    try {
      await AsyncStorage.multiRemove([USER_STORAGE_KEY]);
      this.currentUser = null;
      // Keep device ID for consistency
    } catch (error) {
      logger.error('Error clearing user data:', error);
    }
  }
}

// Export singleton instance
export const authService = new AuthService();