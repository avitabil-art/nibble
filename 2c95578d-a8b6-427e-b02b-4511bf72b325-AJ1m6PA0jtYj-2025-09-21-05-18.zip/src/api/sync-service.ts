import { GroceryList, GroceryItem, ListChange, SyncStatus, CollaboratorInfo, User, ListInvitation } from '../types/recipe';
import { authService } from './auth-service';
import { invitationService } from './invitation-service';

// Configuration
const getApiBaseUrl = () => {
  try {
    const ENV_URL = process.env?.EXPO_PUBLIC_API_BASE_URL;
    const DEFAULT_PROD_URL = 'https://us-central1-nibble-grocery-app.cloudfunctions.net/api';
    return ENV_URL && ENV_URL.length > 0 ? ENV_URL : DEFAULT_PROD_URL;
  } catch (error) {
    return 'https://us-central1-nibble-grocery-app.cloudfunctions.net/api';
  }
};
const API_BASE_URL = getApiBaseUrl();
const SYNC_INTERVAL = 3000; // 3 seconds
const RETRY_DELAY = 5000; // 5 seconds for retries
const MAX_RETRIES = 3;

export interface SyncResponse {
  success: boolean;
  data?: any;
  error?: string;
  version?: number;
}

export interface ListSyncData {
  list: GroceryList;
  changes: ListChange[];
  collaborators: CollaboratorInfo[];
  lastSyncAt: Date;
}

/**
 * Service for synchronizing shared grocery lists in real-time
 * Uses HTTP polling to avoid WebSocket dependencies
 */
class SyncService {
  private resolvers: {
    getSharedLists?: () => Array<{ id: string; inviteToken: string }>;
    applyRemoteList?: (list: GroceryList, collaborators?: CollaboratorInfo[]) => void;
  } = {};

  setResolvers(resolvers: {
    getSharedLists?: () => Array<{ id: string; inviteToken: string }>;
    applyRemoteList?: (list: GroceryList, collaborators?: CollaboratorInfo[]) => void;
  }) {
    this.resolvers = resolvers || {};
  }
  private syncInterval: NodeJS.Timeout | null = null;
  private isOnline: boolean = true;
  private pendingChanges: Map<string, ListChange[]> = new Map();
  private lastSyncTimes: Map<string, Date> = new Map();
  private listeners: Set<(status: SyncStatus) => void> = new Set();
  private currentStatus: SyncStatus = {
    isOnline: true,
    isSyncing: false,
    pendingChanges: 0,
  };
  private backendChecked = false;
  private simulatedMode = false;

  /**
   * Start sync service - begins polling for updates
   */
  async startSync() {
    if (this.syncInterval) {
      return; // Already running
    }

    // Probe backend health once
    await this.checkBackendHealth();

    this.syncInterval = setInterval(() => {
      this.performSync();
    }, SYNC_INTERVAL);

    // Perform initial sync
    this.performSync();
  }

  /**
   * Stop sync service
   */
  stopSync() {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
  }

  /**
   * Add sync status listener
   */
  addStatusListener(listener: (status: SyncStatus) => void) {
    this.listeners.add(listener);
    // Send current status immediately
    listener(this.currentStatus);
  }

  /**
   * Remove sync status listener
   */
  removeStatusListener(listener: (status: SyncStatus) => void) {
    this.listeners.delete(listener);
  }

  /**
   * Create a shared list with invitation token
   */
  async createSharedList(list: GroceryList, inviteToken: string): Promise<SyncResponse> {
    const user = authService.getCurrentUser();
    if (!user) {
      return { success: false, error: 'User not authenticated' };
    }

    // Development fallback - return success when backend is unavailable
    if (__DEV__ && !this.currentStatus.isOnline) {
      if (__DEV__) {
        console.log('[Dev Fallback] Creating shared list locally');
      }
      return { 
        success: true, 
        data: { listId: 'dev-' + Date.now() }
      };
    }

    try {
      const response = await this.makeRequest('/lists', {
        method: 'POST',
        body: JSON.stringify({
          list: {
            ...list,
            ownerId: user.id,
            isShared: true,
            inviteToken,
            sharedWith: [user.id],
            lastModified: new Date(),
            version: 1,
          },
          user,
        }),
      });

      return response;
    } catch (error) {
      if (__DEV__) {
        console.error('Error creating shared list:', error);
      }
      
      // Development fallback
      if (__DEV__) {
        console.log('[Dev Fallback] Backend unavailable, simulating success');
        return { 
          success: true, 
          data: { listId: 'dev-' + Date.now() }
        };
      }
      
      return { success: false, error: 'Failed to create shared list' };
    }
  }

  /**
   * Join a shared list using invitation token
   */
  async joinSharedList(inviteToken: string): Promise<SyncResponse> {
    const user = authService.getCurrentUser();
    if (!user) {
      return { success: false, error: 'User not authenticated' };
    }

    // Use invitation service to handle the join process
    try {
      const result = await invitationService.acceptInvitation(inviteToken);
      if (result.success) {
        return { success: true, data: result.data };
      } else {
        return { success: false, error: result.error };
      }
    } catch (error) {
      if (__DEV__) {
        console.error('Error joining shared list:', error);
      }
      return { success: false, error: 'Failed to join shared list' };
    }
  }

  /**
   * Get shared list data using invitation token
   */
  async getSharedList(inviteToken: string): Promise<SyncResponse> {
    const user = authService.getCurrentUser();
    if (!user) {
      return { success: false, error: 'User not authenticated' };
    }

    try {
      const lastSync = this.lastSyncTimes.get(inviteToken);
      const url = lastSync 
        ? `/lists/${inviteToken}?since=${lastSync.toISOString()}`
        : `/lists/${inviteToken}`;

      const response = await this.makeRequest(url, {
        method: 'GET',
        headers: {
          'X-User-ID': user.id,
        },
      });

      if (response.success) {
        this.lastSyncTimes.set(inviteToken, new Date());
      }

      return response;
    } catch (error) {
      if (__DEV__) {
        console.error('Error getting shared list:', error);
      }
      return { success: false, error: 'Failed to get shared list' };
    }
  }

  /**
   * Upload pending changes for a shared list
   */
  async uploadChanges(listId: string, changes: ListChange[]): Promise<SyncResponse> {
    const user = authService.getCurrentUser();
    if (!user) {
      return { success: false, error: 'User not authenticated' };
    }

    try {
      // Find the invite token for this list
      const inviteToken = await this.getInviteTokenForList(listId);
      if (!inviteToken) {
        return { success: false, error: 'List is not shared' };
      }

      const response = await this.makeRequest(`/lists/${inviteToken}/changes`, {
        method: 'POST',
        body: JSON.stringify({
          changes,
          userId: user.id,
        }),
      });

      if (response.success) {
        // Remove uploaded changes from pending
        this.pendingChanges.delete(listId);
        this.updateStatus();
      }

      return response;
    } catch (error) {
      if (__DEV__) {
        console.error('Error uploading changes:', error);
      }
      return { success: false, error: 'Failed to upload changes' };
    }
  }

  /**
   * Queue a change for upload
   */
  queueChange(listId: string, change: ListChange) {
    const existing = this.pendingChanges.get(listId) || [];
    existing.push(change);
    this.pendingChanges.set(listId, existing);
    this.updateStatus();
  }

  /**
   * Get pending changes count
   */
  getPendingChangesCount(): number {
    let total = 0;
    for (const changes of this.pendingChanges.values()) {
      total += changes.length;
    }
    return total;
  }

  /**
   * Remove collaborator from shared list (owner only)
   */
  async removeCollaborator(inviteToken: string, userId: string): Promise<SyncResponse> {
    const user = authService.getCurrentUser();
    if (!user) {
      return { success: false, error: 'User not authenticated' };
    }

    try {
      const response = await this.makeRequest(`/lists/${inviteToken}/collaborators/${userId}`, {
        method: 'DELETE',
        headers: {
          'X-User-ID': user.id,
        },
      });

      return response;
    } catch (error) {
      if (__DEV__) {
        console.error('Error removing collaborator:', error);
      }
      return { success: false, error: 'Failed to remove collaborator' };
    }
  }

  /**
   * Leave a shared list
   */
  async leaveSharedList(inviteToken: string): Promise<SyncResponse> {
    const user = authService.getCurrentUser();
    if (!user) {
      return { success: false, error: 'User not authenticated' };
    }

    try {
      const response = await this.makeRequest(`/lists/${inviteToken}/leave`, {
        method: 'POST',
        headers: {
          'X-User-ID': user.id,
        },
      });

      return response;
    } catch (error) {
      if (__DEV__) {
        console.error('Error leaving shared list:', error);
      }
      return { success: false, error: 'Failed to leave shared list' };
    }
  }

  /**
   * Perform sync for all shared lists
   */
  private async performSync() {
    if (this.currentStatus.isSyncing) {
      return; // Already syncing
    }

    this.updateStatus({ isSyncing: true });

    try {
      // Upload pending changes first (only if not simulated)
      if (!this.simulatedMode) {
        for (const [listId, changes] of this.pendingChanges.entries()) {
          if (changes.length > 0) {
            await this.uploadChanges(listId, changes);
          }
        }
      }

      // Sync each shared list via resolver
      const lists = this.resolvers.getSharedLists ? this.resolvers.getSharedLists() : [];
      for (const l of lists) {
        // Upload pending per list (already attempted above), then fetch
        if (l.inviteToken) {
          const response = await this.getSharedList(l.inviteToken);
          if (response.success && response.data?.list && this.resolvers.applyRemoteList) {
            const remoteList = response.data.list as GroceryList;
            const collaborators = response.data.collaborators as CollaboratorInfo[] | undefined;
            this.resolvers.applyRemoteList(remoteList, collaborators);
          }
        }
      }

      this.updateStatus({ 
        isSyncing: false, 
        lastSyncAt: new Date(),
        error: undefined 
      });

    } catch (error) {
      this.updateStatus({ 
        isSyncing: false, 
        error: 'Sync failed - will retry' 
      });
    }
  }

  /**
   * Update sync status and notify listeners
   */
  private updateStatus(updates?: Partial<SyncStatus>) {
    this.currentStatus = {
      ...this.currentStatus,
      pendingChanges: this.getPendingChangesCount(),
      ...updates,
    };

    // Notify all listeners
    this.listeners.forEach(listener => listener(this.currentStatus));
  }

  private async checkBackendHealth() {
    if (this.backendChecked) return;
    try {
      const res = await fetch(`${API_BASE_URL}/health`, { method: 'GET' });
      if (res.ok) {
        this.backendChecked = true;
        this.simulatedMode = false;
        this.updateStatus({ isOnline: true });
        return;
      }
      // Non-OK → treat as offline
      this.updateStatus({ isOnline: false });
      if (__DEV__) this.simulatedMode = true;
    } catch {
      // Network failure
      this.updateStatus({ isOnline: false });
      if (__DEV__) this.simulatedMode = true;
    }
  }

  /**
   * Make HTTP request with error handling and retry logic
   */
  private async makeRequest(
    endpoint: string, 
    options: RequestInit = {}, 
    retries: number = 0
  ): Promise<SyncResponse> {
    // Short-circuit in simulated mode
    if (this.simulatedMode) {
      return { success: false, error: 'Simulated mode active' };
    }

    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      // Update online status if request succeeded
      if (!this.currentStatus.isOnline) {
        this.updateStatus({ isOnline: true });
      }

      // Backend is working
      this.backendChecked = true;

      return { success: true, data };

    } catch (error) {
      // Quietly mark offline and enter simulated mode in dev
      this.updateStatus({ isOnline: false });

      // Retry with exponential backoff
      if (retries < MAX_RETRIES) {
        const delay = RETRY_DELAY * Math.pow(2, retries);
        await new Promise(resolve => setTimeout(resolve, delay));
        return this.makeRequest(endpoint, options, retries + 1);
      }

      if (__DEV__) {
        this.simulatedMode = true;
      }

      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Request failed' 
      };
    }
  }

  /**
   * Helper to get invite token for a list ID (will be implemented with store integration)
   */
  private async getInviteTokenForList(listId: string): Promise<string | null> {
    const lists = this.resolvers.getSharedLists ? this.resolvers.getSharedLists() : [];
    const match = lists.find(l => l.id === listId);
    return match?.inviteToken || null;
  }
}

// Export singleton instance
export const syncService = new SyncService();