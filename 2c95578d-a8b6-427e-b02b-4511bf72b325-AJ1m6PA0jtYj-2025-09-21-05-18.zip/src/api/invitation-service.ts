import * as Crypto from 'expo-crypto';
import * as Linking from 'expo-linking';
import * as SMS from 'expo-sms';
import * as Sharing from 'expo-sharing';
import { Platform, Share } from 'react-native';
import { GroceryList, User, ListInvitation, InvitationLink, InvitationStatus } from '../types/recipe';
import { authService } from './auth-service';

// Configuration
const getApiBaseUrl = () => {
  try {
    const ENV_URL = process.env?.EXPO_PUBLIC_API_BASE_URL;
    const DEFAULT_PROD_URL = 'https://us-central1-nibble-grocery-app.cloudfunctions.net/api';
    return ENV_URL && ENV_URL.length > 0 ? ENV_URL : DEFAULT_PROD_URL;
  } catch (error) {
    return 'https://us-central1-nibble-grocery-app.cloudfunctions.net/api';
  }
};
const API_BASE_URL = getApiBaseUrl();
const INVITATION_EXPIRY_DAYS = 30;

export interface InvitationResponse {
  success: boolean;
  data?: any;
  error?: string;
}

export interface CreateInvitationResult {
  success: boolean;
  invitation?: ListInvitation;
  inviteLink?: InvitationLink;
  error?: string;
}

export interface ShareInvitationResult {
  success: boolean;
  method?: 'sms' | 'share' | 'copy';
  error?: string;
}

/**
 * Service for managing list invitations, token generation, and SMS sharing
 */
class InvitationService {
  private pendingInvitations: Map<string, ListInvitation> = new Map();
  private simulatedMode = false;

  /**
   * Generate a secure 32-character invitation token
   */
  private async generateInvitationToken(): Promise<string> {
    const randomBytes = await Crypto.digestStringAsync(
      Crypto.CryptoDigestAlgorithm.SHA256,
      `${Date.now()}-${Math.random()}-${Math.random()}`,
      { encoding: Crypto.CryptoEncoding.HEX }
    );
    return randomBytes.slice(0, 32).toUpperCase();
  }

  /**
   * Create invitation link URL
   */
  private createInvitationLink(token: string, fromUserName: string, listName: string): InvitationLink {
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + INVITATION_EXPIRY_DAYS);

    const url = Linking.createURL(`invite/${token}`, {
      queryParams: {
        from: fromUserName,
        list: listName,
        expires: expiresAt.getTime().toString()
      }
    });

    return {
      url,
      token,
      expiresAt
    };
  }

  /**
   * Create a new invitation for a list
   */
  async createInvitation(listId: string, list: GroceryList): Promise<CreateInvitationResult> {
    const user = authService.getCurrentUser();
    if (!user) {
      return { success: false, error: 'User not authenticated' };
    }

    // Check if user is list owner
    if (list.ownerId && list.ownerId !== user.id) {
      return { success: false, error: 'Only list owner can create invitations' };
    }

    try {
      const token = await this.generateInvitationToken();
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + INVITATION_EXPIRY_DAYS);

      const invitation: ListInvitation = {
        inviteToken: token,
        listId,
        fromUserId: user.id,
        fromUserName: user.name,
        status: InvitationStatus.PENDING,
        createdAt: new Date(),
        expiresAt
      };

      const inviteLink = this.createInvitationLink(token, user.name, list.name);

      // Development mode - store locally
      if (__DEV__ || this.simulatedMode) {
        this.pendingInvitations.set(token, invitation);
        return {
          success: true,
          invitation,
          inviteLink
        };
      }

      // Production - send to backend
      const response = await this.makeRequest('/invitations', {
        method: 'POST',
        body: JSON.stringify({
          invitation,
          listId,
          userId: user.id
        })
      });

      if (response.success) {
        return {
          success: true,
          invitation,
          inviteLink
        };
      }

      return { success: false, error: response.error || 'Failed to create invitation' };

    } catch (error) {
      if (__DEV__) {
        console.error('Error creating invitation:', error);
      }
      return { success: false, error: 'Failed to create invitation' };
    }
  }

  /**
   * Get invitation details by token
   */
  async getInvitation(token: string): Promise<InvitationResponse> {
    if (!token) {
      return { success: false, error: 'Invalid invitation token' };
    }

    try {
      // Development mode - check local storage
      if (__DEV__ || this.simulatedMode) {
        const invitation = this.pendingInvitations.get(token);
        if (!invitation) {
          return { success: false, error: 'Invitation not found' };
        }

        // Check expiration
        if (new Date() > invitation.expiresAt) {
          invitation.status = InvitationStatus.EXPIRED;
          return { success: false, error: 'Invitation has expired' };
        }

        return { success: true, data: invitation };
      }

      // Production - fetch from backend
      const response = await this.makeRequest(`/invitations/${token}`, {
        method: 'GET'
      });

      return response;

    } catch (error) {
      if (__DEV__) {
        console.error('Error getting invitation:', error);
      }
      return { success: false, error: 'Failed to get invitation details' };
    }
  }

  /**
   * Accept an invitation and join the list
   */
  async acceptInvitation(token: string): Promise<InvitationResponse> {
    const user = authService.getCurrentUser();
    if (!user) {
      return { success: false, error: 'User not authenticated' };
    }

    try {
      // Get invitation details first
      const invitationResult = await this.getInvitation(token);
      if (!invitationResult.success) {
        return invitationResult;
      }

      const invitation = invitationResult.data as ListInvitation;

      // Check if invitation is still valid
      if (invitation.status !== InvitationStatus.PENDING) {
        return { success: false, error: 'Invitation is no longer valid' };
      }

      // Development mode
      if (__DEV__ || this.simulatedMode) {
        invitation.status = InvitationStatus.ACCEPTED;
        this.pendingInvitations.set(token, invitation);

        // Return mock shared list data
        return {
          success: true,
          data: {
            list: {
              id: invitation.listId,
              name: 'Shared Grocery List',
              isShared: true,
              inviteToken: token,
              items: [],
              ownerId: invitation.fromUserId,
              sharedWith: [invitation.fromUserId, user.id],
              createdAt: invitation.createdAt,
              lastModified: new Date(),
              version: 1
            }
          }
        };
      }

      // Production - send to backend
      const response = await this.makeRequest(`/invitations/${token}/accept`, {
        method: 'POST',
        body: JSON.stringify({ user })
      });

      return response;

    } catch (error) {
      if (__DEV__) {
        console.error('Error accepting invitation:', error);
      }
      return { success: false, error: 'Failed to accept invitation' };
    }
  }

  /**
   * Decline an invitation
   */
  async declineInvitation(token: string): Promise<InvitationResponse> {
    try {
      // Development mode
      if (__DEV__ || this.simulatedMode) {
        const invitation = this.pendingInvitations.get(token);
        if (invitation) {
          invitation.status = InvitationStatus.DECLINED;
          this.pendingInvitations.set(token, invitation);
        }
        return { success: true };
      }

      // Production - send to backend
      const response = await this.makeRequest(`/invitations/${token}/decline`, {
        method: 'POST'
      });

      return response;

    } catch (error) {
      if (__DEV__) {
        console.error('Error declining invitation:', error);
      }
      return { success: false, error: 'Failed to decline invitation' };
    }
  }

  /**
   * Cancel an invitation (owner only)
   */
  async cancelInvitation(token: string): Promise<InvitationResponse> {
    const user = authService.getCurrentUser();
    if (!user) {
      return { success: false, error: 'User not authenticated' };
    }

    try {
      // Development mode
      if (__DEV__ || this.simulatedMode) {
        const invitation = this.pendingInvitations.get(token);
        if (!invitation) {
          return { success: false, error: 'Invitation not found' };
        }

        if (invitation.fromUserId !== user.id) {
          return { success: false, error: 'Only invitation creator can cancel' };
        }

        invitation.status = InvitationStatus.CANCELLED;
        this.pendingInvitations.set(token, invitation);
        return { success: true };
      }

      // Production - send to backend
      const response = await this.makeRequest(`/invitations/${token}/cancel`, {
        method: 'DELETE',
        headers: {
          'X-User-ID': user.id
        }
      });

      return response;

    } catch (error) {
      if (__DEV__) {
        console.error('Error cancelling invitation:', error);
      }
      return { success: false, error: 'Failed to cancel invitation' };
    }
  }

  /**
   * Get pending invitations for a list (owner only)
   */
  async getListInvitations(listId: string): Promise<InvitationResponse> {
    const user = authService.getCurrentUser();
    if (!user) {
      return { success: false, error: 'User not authenticated' };
    }

    try {
      // Development mode - filter local invitations
      if (__DEV__ || this.simulatedMode) {
        const invitations = Array.from(this.pendingInvitations.values())
          .filter(inv => inv.listId === listId && inv.fromUserId === user.id)
          .filter(inv => inv.status === InvitationStatus.PENDING);

        return { success: true, data: invitations };
      }

      // Production - fetch from backend
      const response = await this.makeRequest(`/lists/${listId}/invitations`, {
        method: 'GET',
        headers: {
          'X-User-ID': user.id
        }
      });

      return response;

    } catch (error) {
      if (__DEV__) {
        console.error('Error getting list invitations:', error);
      }
      return { success: false, error: 'Failed to get invitations' };
    }
  }

  /**
   * Share invitation via SMS or generic sharing
   */
  async shareInvitation(inviteLink: InvitationLink, listName: string, inviterName: string): Promise<ShareInvitationResult> {
    try {
      const message = `Join my grocery list "${listName}" on Nibble! ${inviteLink.url}`;

      // Try SMS first if available on mobile platforms
      if (Platform.OS !== 'web') {
        const isSMSAvailable = await SMS.isAvailableAsync();
        if (isSMSAvailable) {
          try {
            const result = await SMS.sendSMSAsync([], message);
            if (result.result === 'sent' || result.result === 'unknown') {
              return {
                success: true,
                method: 'sms'
              };
            }
          } catch (smsError) {
            if (__DEV__) {
              console.log('SMS failed, falling back to generic sharing:', smsError);
            }
          }
        }
      }

      // Use React Native's built-in Share API as primary fallback
      try {
        const shareResult = await Share.share({
          message: Platform.OS === 'ios' ? message : inviteLink.url,
          url: Platform.OS === 'ios' ? inviteLink.url : undefined,
          title: `Join "${listName}" on Nibble`
        });

        if (shareResult.action === Share.sharedAction) {
          return {
            success: true,
            method: 'share'
          };
        } else if (shareResult.action === Share.dismissedAction) {
          return {
            success: false,
            error: 'User cancelled sharing'
          };
        }
        } catch (shareError) {
          if (__DEV__) {
            console.log('Native Share API failed:', shareError);
          }
        }

      // Fallback to Expo sharing for web or if native sharing fails
      const isSharingAvailable = await Sharing.isAvailableAsync();
      if (isSharingAvailable) {
        try {
          // For expo-sharing, we need to create a shareable content
          if (Platform.OS === 'web') {
            // Web Share API
            await Sharing.shareAsync(inviteLink.url, {
              dialogTitle: `Share "${listName}" grocery list`
            });
            return {
              success: true,
              method: 'share'
            };
          }
        } catch (expoShareError) {
          if (__DEV__) {
            console.log('Expo sharing failed:', expoShareError);
          }
        }
      }

      // No sharing method worked
      return {
        success: false,
        error: 'No sharing method available on this device. Please copy the link manually.'
      };

    } catch (error) {
      if (__DEV__) {
        console.error('Error sharing invitation:', error);
      }
      return {
        success: false,
        error: 'Failed to share invitation'
      };
    }
  }

  /**
   * Parse invitation data from deep link URL
   */
  parseInvitationUrl(url: string): { token?: string; fromName?: string; listName?: string; expires?: Date } | null {
    try {
      const parsed = Linking.parse(url);
      
      if (!parsed.path || !parsed.path.startsWith('invite/')) {
        return null;
      }

      const token = parsed.path.replace('invite/', '');
      if (!token || token.length !== 32) {
        return null;
      }

      const fromName = parsed.queryParams?.from as string;
      const listName = parsed.queryParams?.list as string;
      const expiresTimestamp = parsed.queryParams?.expires as string;
      
      let expires: Date | undefined;
      if (expiresTimestamp) {
        expires = new Date(parseInt(expiresTimestamp));
      }

      return {
        token,
        fromName,
        listName,
        expires
      };
    } catch (error) {
      if (__DEV__) {
        console.error('Error parsing invitation URL:', error);
      }
      return null;
    }
  }

  /**
   * Enable simulated mode for development/testing
   */
  enableSimulatedMode() {
    this.simulatedMode = true;
  }

  /**
   * Clear all pending invitations (dev/testing only)
   */
  clearPendingInvitations() {
    if (__DEV__) {
      this.pendingInvitations.clear();
    }
  }

  /**
   * Make HTTP request with error handling
   */
  private async makeRequest(endpoint: string, options: RequestInit = {}): Promise<InvitationResponse> {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      return { success: true, data };

    } catch (error) {
      // Enable simulated mode if backend is unavailable in development
      if (__DEV__) {
        this.simulatedMode = true;
      }

      return {
        success: false,
        error: error instanceof Error ? error.message : 'Request failed'
      };
    }
  }
}

// Export singleton instance
export const invitationService = new InvitationService();