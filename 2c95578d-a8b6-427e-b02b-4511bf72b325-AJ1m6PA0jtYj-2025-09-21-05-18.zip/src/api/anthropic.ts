/*
IMPORTANT NOTICE: DO NOT REMOVE
This is a custom client for the Anthropic API. You may update this service, but you should not need to.

Valid model names: 
claude-sonnet-4-20250514
claude-3-7-sonnet-latest
claude-3-5-haiku-latest
*/
import Anthropic from "@anthropic-ai/sdk";

let clientInstance: Anthropic | null = null;

export const getAnthropicClient = () => {
  // Return cached instance if available
  if (clientInstance) {
    return clientInstance;
  }

  try {
    const apiKey = process.env.EXPO_PUBLIC_VIBECODE_ANTHROPIC_API_KEY;
    if (!apiKey && __DEV__) {
      console.warn("Anthropic API key not found in environment variables");
    }
    
    clientInstance = new Anthropic({
      apiKey: apiKey || "dummy-key-for-development", // Prevent instantiation errors
    });
    
    return clientInstance;
  } catch (error) {
    if (__DEV__) {
      console.error("Failed to initialize Anthropic client:", error);
    }
    // Return a minimal client that will fail gracefully
    return new Anthropic({
      apiKey: "dummy-key-for-development"
    });
  }
};
