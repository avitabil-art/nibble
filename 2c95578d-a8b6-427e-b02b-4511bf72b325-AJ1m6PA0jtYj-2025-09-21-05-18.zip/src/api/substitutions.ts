// Substitution API removed intentionally.
export async function getSubstitutionsForIngredient(): Promise<never> {
  throw new Error("Substitutions are no longer supported");
}
export async function getSubstitutionsForRecipe(): Promise<never> {
  throw new Error("Substitutions are no longer supported");
}
