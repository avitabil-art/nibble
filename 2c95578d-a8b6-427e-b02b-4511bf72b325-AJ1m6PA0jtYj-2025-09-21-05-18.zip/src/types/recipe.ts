export interface Ingredient {
  id: string;
  name: string;
  amount: number;
  unit: string;
  originalText: string;
}

export interface Recipe {
  id: string;
  title: string;
  url?: string;
  servings: number;
  originalServings: number;
  ingredients: Ingredient[];
  // Canonical baseline snapshot used for precise scaling (tsp/g/piece)
  baseIngredients?: Ingredient[];
  instructions: string[];
  createdAt: Date;
  tags?: string[];
}

export interface User {
  id: string;
  name: string;
  deviceId: string;
  createdAt: Date;
}

export interface GroceryList {
  id: string;
  name: string;
  createdAt: Date;
  items: GroceryItem[];
  // Sharing functionality
  isShared: boolean;
  inviteToken?: string; // 32-character secure invitation token
  shareId?: string; // Legacy 6-digit share code (deprecated, for backward compatibility)
  ownerId?: string; // user ID of list creator
  sharedWith: string[]; // array of user IDs with access
  lastModified: Date;
  version: number; // for conflict resolution
}

export interface GroceryItem {
  id: string;
  name: string;
  amount?: number;
  unit?: string;
  notes?: string;
  checked: boolean;
  recipeId?: string;
  ingredientId?: string;
  addedAt: Date;
  listId: string;
  // Collaboration fields
  modifiedBy?: string; // user ID who last modified this item
  modifiedAt: Date; // when item was last modified
  version: number; // for optimistic updates
}

export interface ParsedRecipeData {
  title: string;
  ingredients: string[];
  instructions: string[];
  servings?: number;
}


// Invitation and sync types
export interface ListInvitation {
  inviteToken: string; // 32-character secure token
  listId: string;
  fromUserId: string;
  fromUserName: string;
  status: InvitationStatus;
  createdAt: Date;
  expiresAt: Date;
}

export enum InvitationStatus {
  PENDING = 'pending',
  ACCEPTED = 'accepted', 
  DECLINED = 'declined',
  EXPIRED = 'expired',
  CANCELLED = 'cancelled'
}

export interface InvitationLink {
  url: string; // nibble://invite/{token}?from={name}&list={listName}
  token: string;
  expiresAt: Date;
}

export interface ListChange {
  id: string;
  listId: string;
  type: 'item_added' | 'item_updated' | 'item_deleted' | 'list_updated';
  data: any;
  userId: string;
  timestamp: Date;
  version: number;
}

export interface SyncStatus {
  isOnline: boolean;
  isSyncing: boolean;
  lastSyncAt?: Date;
  pendingChanges: number;
  error?: string;
}

export interface CollaboratorInfo {
  userId: string;
  userName: string;
  joinedAt: Date;
  lastActiveAt: Date;
  isOwner: boolean;
}