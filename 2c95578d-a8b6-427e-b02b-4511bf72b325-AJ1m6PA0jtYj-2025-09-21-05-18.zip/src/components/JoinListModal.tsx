import React, { useState } from "react";
import { View, Text, Modal, TextInput } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRecipeStore } from "../state/recipeStore";
import { typography } from "../utils/fonts";
import { PrimaryButton, GhostButton } from "./EnhancedButton";

interface JoinListModalProps {
  visible: boolean;
  onClose: () => void;
}

export default function JoinListModal({ visible, onClose }: JoinListModalProps) {
  const { currentUser, setBanner, setUserName: updateUserName } = useRecipeStore();
  
  const [userName, setUserName] = useState(currentUser?.name || "");
  const [isLoading, setIsLoading] = useState(false);

  const resetModal = () => {
    setUserName(currentUser?.name || "");
  };

  const handleClose = () => {
    resetModal();
    onClose();
  };

  const handleSetUserName = async () => {
    const trimmedName = userName.trim();
    if (!trimmedName) {
      setBanner("Please enter your name to continue.");
      return;
    }

    setIsLoading(true);
    try {
      await updateUserName(trimmedName);
      setBanner("Name updated! You can now accept invitations.");
      handleClose();
    } catch (error) {
      setBanner("Failed to set your name. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={handleClose}
    >
      <View className="flex-1 bg-offwhite">
        {/* Header */}
        <View className="flex-row items-center justify-between px-5 py-4 bg-white border-b border-neutral-200">
          <Text className="text-charcoal" style={typography.heading}>
            {currentUser ? "Setup Complete" : "Join Shared Lists"}
          </Text>
          <GhostButton
            title=""
            onPress={handleClose}
            icon="chevron-down"
            size="small"
          />
        </View>

        <View className="flex-1 px-5 py-6">
          {!currentUser ? (
            // User needs to set up their name
            <View>
              <View className="bg-fresh/10 p-6 rounded-2xl mb-6">
                <View className="items-center mb-4">
                  <View className="bg-fresh/20 p-4 rounded-full mb-3">
                    <Ionicons name="person-add-outline" size={32} color="#48C78E" />
                  </View>
                  <Text className="text-charcoal text-center" style={typography.subheading}>
                    What should we call you?
                  </Text>
                  <Text className="text-neutral-600 text-center mt-2" style={typography.body}>
                    Your family will see this name when you make changes to shared lists.
                  </Text>
                </View>
              </View>

              <View className="bg-white p-6 rounded-2xl border border-neutral-200 mb-6">
                <Text className="text-charcoal mb-4" style={typography.bodyMedium}>
                  Display Name
                </Text>
                
                <TextInput
                  value={userName}
                  onChangeText={setUserName}
                  placeholder="Enter your name"
                  className="bg-neutral-50 px-4 py-3 rounded-xl text-charcoal"
                  style={typography.body}
                  placeholderTextColor="#A3A3A3"
                  autoFocus
                  returnKeyType="done"
                  onSubmitEditing={handleSetUserName}
                />
              </View>

              <PrimaryButton
                title={isLoading ? "Setting name..." : "Save Name"}
                onPress={handleSetUserName}
                loading={isLoading}
                disabled={!userName.trim()}
                fullWidth
                icon="checkmark"
              />

              <View className="bg-neutral-100 p-4 rounded-xl mt-4">
                <Text className="text-neutral-600 text-sm" style={typography.caption}>
                  Once you set your name, you'll be ready to accept invitations from family members.
                </Text>
              </View>
            </View>
          ) : (
            // User is ready to accept invitations
            <View>
              <View className="bg-fresh/10 p-6 rounded-2xl mb-6">
                <View className="items-center mb-4">
                  <View className="bg-fresh/20 p-4 rounded-full mb-3">
                    <Ionicons name="checkmark-circle" size={32} color="#48C78E" />
                  </View>
                  <Text className="text-charcoal text-center" style={typography.subheading}>
                    Ready to join lists!
                  </Text>
                  <Text className="text-neutral-600 text-center mt-2" style={typography.body}>
                    You're all set up to accept invitations from family members.
                  </Text>
                </View>
              </View>

              <View className="bg-white p-6 rounded-2xl border border-neutral-200 mb-6">
                <Text className="text-charcoal mb-4" style={typography.bodyMedium}>
                  How to join a shared list:
                </Text>
                
                <View className="space-y-3">
                  <View className="flex-row items-start">
                    <View className="bg-fresh/20 p-2 rounded-full mr-3 mt-0.5">
                      <Text className="text-fresh text-xs font-bold" style={typography.caption}>1</Text>
                    </View>
                    <View className="flex-1">
                      <Text className="text-charcoal" style={typography.bodyMedium}>
                        Get an invitation
                      </Text>
                      <Text className="text-neutral-600 text-sm" style={typography.body}>
                        Ask a family member to invite you to their grocery list
                      </Text>
                    </View>
                  </View>
                  
                  <View className="flex-row items-start">
                    <View className="bg-fresh/20 p-2 rounded-full mr-3 mt-0.5">
                      <Text className="text-fresh text-xs font-bold" style={typography.caption}>2</Text>
                    </View>
                    <View className="flex-1">
                      <Text className="text-charcoal" style={typography.bodyMedium}>
                        Tap the link
                      </Text>
                      <Text className="text-neutral-600 text-sm" style={typography.body}>
                        Click the invitation link they send you via text or message
                      </Text>
                    </View>
                  </View>
                  
                  <View className="flex-row items-start">
                    <View className="bg-fresh/20 p-2 rounded-full mr-3 mt-0.5">
                      <Text className="text-fresh text-xs font-bold" style={typography.caption}>3</Text>
                    </View>
                    <View className="flex-1">
                      <Text className="text-charcoal" style={typography.bodyMedium}>
                        Start collaborating
                      </Text>
                      <Text className="text-neutral-600 text-sm" style={typography.body}>
                        Add items and see real-time updates from your family
                      </Text>
                    </View>
                  </View>
                </View>
              </View>

              {/* User info display */}
              <View className="flex-row items-center justify-center p-4 bg-fresh/5 rounded-xl">
                <View className="bg-fresh/20 p-2 rounded-full mr-3">
                  <Ionicons name="person" size={16} color="#48C78E" />
                </View>
                <Text className="text-fresh" style={typography.bodyMedium}>
                  Ready as {currentUser.name}
                </Text>
              </View>
            </View>
          )}
        </View>
      </View>
    </Modal>
  );
}