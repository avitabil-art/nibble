import React from "react";
import { View, Text, Modal } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import { typography } from "../utils/fonts";
import { PrimaryButton, DangerButton, OutlineButton } from "./EnhancedButton";

interface ErrorModalProps {
  visible: boolean;
  title: string;
  message: string;
  onConfirm?: () => void;
  onCancel?: () => void;
  confirmText?: string;
  cancelText?: string;
  type?: 'error' | 'warning' | 'info' | 'success';
}

export default function ErrorModal({
  visible,
  title,
  message,
  onConfirm,
  onCancel,
  confirmText = "OK",
  cancelText = "Cancel",
  type = 'info'
}: ErrorModalProps) {
  
  const getIconAndColor = () => {
    switch (type) {
      case 'error':
        return { icon: 'close-circle', color: '#FF4D6D' };
      case 'warning':
        return { icon: 'warning', color: '#FF8A4C' };
      case 'success':
        return { icon: 'checkmark-circle', color: '#48C78E' };
      default:
        return { icon: 'information-circle', color: '#48C78E' };
    }
  };

  const { icon, color } = getIconAndColor();

  const handleConfirm = () => {
    if (onConfirm) {
      onConfirm();
    }
  };

  const handleCancel = () => {
    if (onCancel) {
      onCancel();
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="fade"
      transparent
      statusBarTranslucent
    >
      <View className="flex-1 bg-black/50 justify-center items-center px-4">
        <SafeAreaView className="w-full max-w-sm">
          <View className="bg-white rounded-3xl p-6 shadow-xl">
            {/* Header */}
            <View className="items-center mb-6">
              <View className="p-4 rounded-full mb-4" style={{ backgroundColor: `${color}15` }}>
                <Ionicons name={icon as any} size={32} color={color} />
              </View>
              <Text className="text-charcoal text-center" style={typography.heading}>
                {title}
              </Text>
              <Text className="text-neutral-600 text-center mt-2" style={typography.body}>
                {message}
              </Text>
            </View>

            {/* Action Buttons */}
            <View className="space-y-3">
              {onConfirm && (
                <>
                  {type === 'error' ? (
                    <DangerButton
                      title={confirmText}
                      onPress={handleConfirm}
                      fullWidth
                    />
                  ) : (
                    <PrimaryButton
                      title={confirmText}
                      onPress={handleConfirm}
                      fullWidth
                    />
                  )}
                </>
              )}
              {onCancel && (
                <OutlineButton
                  title={cancelText}
                  onPress={handleCancel}
                  fullWidth
                />
              )}
            </View>
          </View>
        </SafeAreaView>
      </View>
    </Modal>
  );
}

// Convenience hook for showing error modals
export const useErrorModal = () => {
  const [modalState, setModalState] = React.useState<{
    visible: boolean;
    title: string;
    message: string;
    onConfirm?: () => void;
    onCancel?: () => void;
    confirmText?: string;
    cancelText?: string;
    type?: 'error' | 'warning' | 'info' | 'success';
  }>({
    visible: false,
    title: '',
    message: ''
  });

  const showError = (title: string, message: string, onConfirm?: () => void) => {
    setModalState({
      visible: true,
      title,
      message,
      onConfirm: onConfirm || (() => setModalState(prev => ({ ...prev, visible: false }))),
      type: 'error'
    });
  };

  const showWarning = (title: string, message: string, onConfirm?: () => void, onCancel?: () => void) => {
    setModalState({
      visible: true,
      title,
      message,
      onConfirm: onConfirm || (() => setModalState(prev => ({ ...prev, visible: false }))),
      onCancel: onCancel || (() => setModalState(prev => ({ ...prev, visible: false }))),
      type: 'warning'
    });
  };

  const showInfo = (title: string, message: string, onConfirm?: () => void) => {
    setModalState({
      visible: true,
      title,
      message,
      onConfirm: onConfirm || (() => setModalState(prev => ({ ...prev, visible: false }))),
      type: 'info'
    });
  };

  const hideModal = () => {
    setModalState(prev => ({ ...prev, visible: false }));
  };

  const ErrorModalComponent = () => (
    <ErrorModal
      visible={modalState.visible}
      title={modalState.title}
      message={modalState.message}
      onConfirm={modalState.onConfirm}
      onCancel={modalState.onCancel}
      confirmText={modalState.confirmText}
      cancelText={modalState.cancelText}
      type={modalState.type}
    />
  );

  return {
    showError,
    showWarning,
    showInfo,
    hideModal,
    ErrorModalComponent
  };
};