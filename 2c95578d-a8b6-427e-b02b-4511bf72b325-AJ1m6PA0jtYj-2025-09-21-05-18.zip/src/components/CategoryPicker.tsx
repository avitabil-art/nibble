import React, { useMemo, useState } from "react";
import { View, Text, TextInput, Pressable } from "react-native";
import CategoryChip from "./CategoryChip";
import { useRecipeStore } from "../state/recipeStore";

const SUGGESTED = [
  "Instapot",
  "Dessert",
  "Breakfast",
  "Dinner",
  "Vegan",
  "Vegetarian",
  "Gluten Free",
  "Quick",
  "Budget",
  "Drink",
  "Baking",
];

interface CategoryPickerProps {
  value: string[];
  onChange: (next: string[]) => void;
}

export default function CategoryPicker({ value, onChange }: CategoryPickerProps) {
  const getAllCategories = useRecipeStore((s) => s.getAllCategories);
  const all = getAllCategories();
  const [input, setInput] = useState("");

  const merged = useMemo(() => {
    const set = new Set<string>([...SUGGESTED, ...all]);
    return Array.from(set);
  }, [all]);

  const toggle = (label: string) => {
    if (value.some((v) => v.toLowerCase() === label.toLowerCase())) {
      onChange(value.filter((v) => v.toLowerCase() !== label.toLowerCase()));
    } else {
      onChange([...value, label]);
    }
  };

  const addCustom = () => {
    const trimmed = input.trim();
    if (!trimmed) return;
    setInput("");
    toggle(trimmed);
  };

  return (
    <View>
      <Text className="text-stone-700 font-medium mb-3">Categories</Text>
      <View className="bg-white rounded-xl p-3 border border-stone-200">
        <View className="flex-row flex-wrap">
          {merged.map((label) => (
            <CategoryChip
              key={label}
              label={label}
              selected={value.some((v) => v.toLowerCase() === label.toLowerCase())}
              onPress={() => toggle(label)}
            />
          ))}
        </View>
        <View className="h-[1px] bg-stone-200 my-3" />
        <View className="flex-row items-center">
          <TextInput
            className="flex-1 bg-stone-100 rounded-lg px-3 py-2 text-stone-800"
            placeholder="Add custom category"
            placeholderTextColor="#a8a29e"
            value={input}
            onChangeText={setInput}
            onSubmitEditing={addCustom}
            returnKeyType="done"
          />
          <Pressable
            onPress={addCustom}
            className="ml-2 px-3 py-2 rounded-lg bg-orange-500"
          >
            <Text className="text-white font-medium">Add</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}