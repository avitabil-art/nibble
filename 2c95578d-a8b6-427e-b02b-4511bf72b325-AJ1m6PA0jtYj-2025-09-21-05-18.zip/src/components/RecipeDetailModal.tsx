import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  Modal,
  ScrollView,
  Pressable,
  TextInput,
  Alert,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useRecipeStore } from "../state/recipeStore";
import { Recipe } from "../types/recipe";
import CategoryChip from "./CategoryChip";
import CategoryPicker from "./CategoryPicker";
const AddToListModal = React.lazy(() => import("./AddToListModal"));

interface RecipeDetailModalProps {
  recipe: Recipe;
  visible: boolean;
  onClose: () => void;
}

export default function RecipeDetailModal({ recipe, visible, onClose }: RecipeDetailModalProps) {
  const { addRecipeToGroceryList, setRecipeCategories, refreshRecipe, setBanner } = useRecipeStore();
  const [servings, setServings] = useState(recipe.servings.toString());
  const [refreshing, setRefreshing] = useState(false);
  const [editingCategories, setEditingCategories] = useState(false);
  const [cats, setCats] = useState<string[]>(recipe.tags ?? []);
  const [showAdd, setShowAdd] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    setCats(recipe.tags ?? []);
    setServings(recipe.servings.toString());
    setEditingCategories(false);
  }, [recipe]);

  const handleScaleRecipe = () => {
    const newServings = parseInt(servings) || recipe.originalServings;
    if (newServings !== recipe.servings) {
      useRecipeStore.getState().scaleRecipe(recipe.id, newServings);
    }
  };

  const handleAddToGroceryList = () => {
    addRecipeToGroceryList(recipe.id);
    onClose();
  };

  const handleRefreshRecipe = () => {
    if (!recipe.url) return;

    Alert.alert(
      "Refresh Recipe",
       "This will re-scrape the recipe from its original URL. Any manual ingredient edits will be lost. Continue?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Refresh",
          style: "default",
          onPress: async () => {
            setRefreshing(true);
            try {
              const result = await refreshRecipe(recipe.id);
              if (result.success) {
                setBanner("Recipe refreshed successfully!");
                setTimeout(() => setBanner(""), 3000);
              } else {
                // Show error with retry option for certain errors
                const isNetworkError = result.error?.includes("Network error") || result.error?.includes("fetch");
                const isParsingError = result.error?.includes("extract recipe") || result.error?.includes("incomplete");
                
                if (isNetworkError) {
                  Alert.alert(
                    "Network Error",
                    result.error || "Failed to refresh recipe",
                    [
                      { text: "Cancel", style: "cancel" },
                      { 
                        text: "Retry", 
                        onPress: () => handleRefreshRecipe() 
                      }
                    ]
                  );
                } else if (isParsingError) {
                  Alert.alert(
                    "Parsing Error",
                    `${result.error || "Failed to refresh recipe"}\n\nThe website may have changed its structure. You can try refreshing again or edit the recipe manually.`,
                    [
                      { text: "OK", style: "cancel" },
                      { 
                        text: "Retry Anyway", 
                        onPress: () => handleRefreshRecipe() 
                      }
                    ]
                  );
                } else {
                  Alert.alert("Refresh Failed", result.error || "Failed to refresh recipe");
                }
              }
            } catch (error) {
              Alert.alert(
                "Unexpected Error", 
                "An unexpected error occurred while refreshing the recipe. Please try again.",
                [
                  { text: "Cancel", style: "cancel" },
                  { 
                    text: "Retry", 
                    onPress: () => handleRefreshRecipe() 
                  }
                ]
              );
            } finally {
              setRefreshing(false);
            }
          },
        },
      ]
    );
  };

  const formatAmount = (amount: number) => {
    if (amount % 1 === 0) {
      return amount.toString();
    } else if (amount === 0.5) {
      return "½";
    } else if (amount === 0.25) {
      return "¼";
    } else if (amount === 0.75) {
      return "¾";
    } else if (amount === 0.333 || amount === 1/3) {
      return "⅓";
    } else if (amount === 0.667 || amount === 2/3) {
      return "⅔";
    } else {
      return amount.toFixed(2).replace(/\.?0+$/, "");
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
    >
      <SafeAreaView className="flex-1 bg-stone-50">
        {/* Header */}
        <View className="flex-row items-center justify-between px-4 py-3 bg-white border-b border-stone-200">
          <Pressable 
            onPress={onClose}
            className="p-2 rounded-full bg-neutral-100 border border-neutral-200"
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
          >
            <Ionicons name="chevron-down" size={20} color="#6B7280" />
          </Pressable>
          <Text className="text-lg font-semibold text-stone-800 flex-1 text-center mx-4" numberOfLines={1}>
            {recipe.title}
          </Text>
          <View className="flex-row items-center">
            {recipe.url && (
              <View className="items-center mr-3">
                <Pressable 
                  onPress={handleRefreshRecipe}
                  disabled={refreshing}
                  className="p-2 rounded-full bg-blue-50 border border-blue-200"
                  hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                >
                  <Ionicons 
                    name={refreshing ? "cloud-download" : "cloud-download-outline"} 
                    size={20} 
                    color={refreshing ? "#60A5FA" : "#3B82F6"} 
                  />
                </Pressable>
                <Text className="text-xs text-blue-600 mt-1 font-medium">REFRESH</Text>
              </View>
            )}
            <View className="items-center">
              <Pressable 
                onPress={handleAddToGroceryList}
                className="p-2 rounded-full bg-orange-50 border border-orange-200"
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              >
                <Ionicons name="basket" size={20} color="#F97316" />
              </Pressable>
              <Text className="text-xs text-orange-600 mt-1 font-medium">ADD</Text>
            </View>
          </View>
        </View>

        {/* Loading Overlay */}
        {refreshing && (
          <View className="absolute inset-0 bg-black/20 z-50 flex-1 justify-center items-center">
            <View className="bg-white rounded-2xl p-6 mx-8 items-center shadow-lg">
              <View className="w-12 h-12 bg-orange-100 rounded-full items-center justify-center mb-3">
                <Ionicons name="sync" size={24} color="#f97316" />
              </View>
              <Text className="text-stone-800 font-semibold text-lg">Refreshing Recipe</Text>
              <Text className="text-stone-500 text-sm mt-2 text-center">
                Re-scraping ingredients and instructions from the original website
              </Text>
              <Text className="text-stone-400 text-xs mt-2 text-center">
                This may take a few moments...
              </Text>
            </View>
          </View>
        )}

        <ScrollView className="flex-1">
          {/* Recipe Info */}
          <View className="bg-white mx-4 mt-4 rounded-2xl p-4">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-stone-600 font-medium">Servings</Text>
              <View className="flex-row items-center">
                <Pressable
                  onPress={() => {
                    const newServings = Math.max(1, parseInt(servings) - 1);
                    setServings(newServings.toString());
                    useRecipeStore.getState().scaleRecipe(recipe.id, newServings);
                  }}
                  className="w-9 h-9 bg-red-50 rounded-full items-center justify-center border border-red-200"
                >
                  <Ionicons name="remove-circle" size={18} color="#EF4444" />
                </Pressable>
                <TextInput
                  className="mx-3 text-center text-lg font-semibold text-stone-800 min-w-12"
                  value={servings}
                  onChangeText={setServings}
                  onEndEditing={handleScaleRecipe}
                  keyboardType="numeric"
                />
                <Pressable
                  onPress={() => {
                    const newServings = parseInt(servings) + 1;
                    setServings(newServings.toString());
                    useRecipeStore.getState().scaleRecipe(recipe.id, newServings);
                  }}
                  className="w-9 h-9 bg-green-50 rounded-full items-center justify-center border border-green-200"
                >
                  <Ionicons name="add-circle" size={18} color="#22C55E" />
                </Pressable>
              </View>
            </View>

            <Pressable onPress={() => setShowAdd(true)} className="mt-1 bg-orange-500 rounded-xl py-3 items-center">
              <Text className="text-white font-semibold">Add ingredients to list</Text>
            </Pressable>
            
            {recipe.url ? (
              <View className="mt-3 pt-3 border-t border-stone-100">
                <View className="flex-row items-center mb-2">
                  <Ionicons name="link-outline" size={14} color="#f97316" />
                  <Text className="text-orange-600 text-xs font-medium ml-1">REFRESHABLE RECIPE</Text>
                </View>
                <Text className="text-stone-500 text-sm mb-2" numberOfLines={2}>
                  {recipe.url}
                </Text>
                <View className="flex-row items-center">
                  <Ionicons name="refresh-outline" size={12} color="#78716c" />
                  <Text className="text-stone-400 text-xs ml-1">
                    Tap refresh button above to re-scrape from source
                  </Text>
                </View>
              </View>
            ) : (
              <View className="mt-3 pt-3 border-t border-stone-100">
                <View className="flex-row items-center mb-1">
                  <Ionicons name="create-outline" size={14} color="#78716c" />
                  <Text className="text-stone-500 text-xs font-medium ml-1">MANUAL RECIPE</Text>
                </View>
                <Text className="text-stone-400 text-xs">
                  This recipe was entered manually and cannot be refreshed
                </Text>
              </View>
            )}
          </View>

          {/* Categories */}
          <View className="bg-white mx-4 mt-4 rounded-2xl p-4">
            <View className="flex-row items-center justify-between mb-3">
              <Text className="text-lg font-semibold text-stone-800">Categories</Text>
              {editingCategories ? (
                <Pressable
                  onPress={() => {
                    setRecipeCategories(recipe.id, cats);
                    setEditingCategories(false);
                  }}
                >
                  <Text className="text-orange-600 font-medium">Save</Text>
                </Pressable>
              ) : (
                <Pressable onPress={() => setEditingCategories(true)}>
                  <Text className="text-orange-600 font-medium">Edit</Text>
                </Pressable>
              )}
            </View>

            {!editingCategories ? (
              <View className="flex-row flex-wrap">
                {(recipe.tags ?? []).length === 0 ? (
                  <Text className="text-stone-400">No categories</Text>
                ) : (
                  (recipe.tags ?? []).map((t) => (
                    <CategoryChip key={t} label={t} />
                  ))
                )}
              </View>
            ) : (
              <CategoryPicker value={cats} onChange={setCats} />
            )}
          </View>

          {/* Ingredients */}
          <View className="bg-white mx-4 mt-4 rounded-2xl p-4">
            <Text className="text-lg font-semibold text-stone-800 mb-4">
              Ingredients
            </Text>
            <View className="space-y-3">
              {recipe.ingredients.map((ingredient) => (
                <View key={ingredient.id} className="flex-row items-center">
                  <View className="w-2 h-2 bg-orange-400 rounded-full mr-3" />
                  <Text className="flex-1 text-stone-700 text-base">
                    <Text className="font-medium">
                      {formatAmount(ingredient.amount)} {ingredient.unit}
                    </Text>
                    {" "}
                    {ingredient.name}
                  </Text>

                </View>
              ))}
            </View>
          </View>

          {/* Instructions */}
          <View className="bg-white mx-4 mt-4 rounded-2xl p-4">
            <Text className="text-lg font-semibold text-stone-800 mb-4">
              Instructions
            </Text>
            <View className="space-y-4">
              {recipe.instructions.map((instruction, index) => (
                <View key={index} className="flex-row">
                  <View className="w-6 h-6 bg-orange-500 rounded-full items-center justify-center mr-3 mt-1">
                    <Text className="text-white text-sm font-semibold">
                      {index + 1}
                    </Text>
                  </View>
                  <Text className="flex-1 text-stone-700 text-base leading-6">
                    {instruction}
                  </Text>
                </View>
              ))}
            </View>
          </View>

          {/* Danger Zone */}
          <View className="bg-white mx-4 mt-4 mb-6 rounded-2xl p-4 border border-red-200">
            <Text className="text-red-600 font-semibold mb-3">Danger Zone</Text>
            <Pressable onPress={() => setShowConfirm(true)} className="bg-red-50 border border-red-200 rounded-xl py-3 items-center">
              <Text className="text-red-600 font-semibold">Delete Recipe</Text>
            </Pressable>
          </View>
        </ScrollView>

        <React.Suspense fallback={null}>
          <AddToListModal recipe={recipe} visible={showAdd} onClose={() => setShowAdd(false)} />
        </React.Suspense>
        <ConfirmDeleteModal
          visible={showConfirm}
          onCancel={() => setShowConfirm(false)}
          onDelete={async () => {
            setDeleting(true);
            useRecipeStore.getState().deleteRecipe(recipe.id);
            useRecipeStore.getState().setBanner("Recipe deleted");
            setDeleting(false);
            setShowConfirm(false);
            onClose();
          }}
          title={recipe.title}
          loading={deleting}
        />
      </SafeAreaView>
    </Modal>
  );
}

function ConfirmDeleteModal({ visible, onCancel, onDelete, title, loading }: { visible: boolean; onCancel: () => void; onDelete: () => void | Promise<void>; title: string; loading?: boolean; }) {
  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <SafeAreaView className="flex-1 bg-stone-50">
        <View className="px-4 py-4">
          <Text className="text-xl font-semibold text-stone-800 mb-1">Delete this recipe?</Text>
          <Text className="text-stone-500 mb-4">{title}</Text>
          <View className="bg-red-50 border border-red-200 rounded-xl p-3 mb-6">
            <Text className="text-red-600">This also removes its items from your grocery list.</Text>
          </View>
          <View className="flex-row">
            <Pressable onPress={onCancel} className="flex-1 mr-2 bg-stone-200 rounded-xl py-3 items-center">
              <Text className="text-stone-700 font-medium">Cancel</Text>
            </Pressable>
            <Pressable onPress={onDelete} disabled={loading} className={`flex-1 ml-2 rounded-xl py-3 items-center ${loading ? "bg-red-300" : "bg-red-500"}`}>
              <Text className="text-white font-semibold">{loading ? "Deleting…" : "Delete"}</Text>
            </Pressable>
          </View>
        </View>
      </SafeAreaView>
    </Modal>
  );
}