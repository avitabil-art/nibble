import React, { useState } from "react";
import { View, Text, Pressable } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRecipeStore } from "../state/recipeStore";
import { Recipe } from "../types/recipe";
import RecipeDetailModal from "./RecipeDetailModal";
import { typography } from "../utils/fonts";

interface RecipeCardProps {
  recipe: Recipe;
}

export default function RecipeCard({ recipe }: RecipeCardProps) {
  const { addRecipeToGroceryList } = useRecipeStore();
  const [showDetail, setShowDetail] = useState(false);

  const handleAddToGroceryList = () => {
    addRecipeToGroceryList(recipe.id);
  };

  return (
    <>
      <Pressable
        onPress={() => setShowDetail(true)}
        className="bg-white rounded-3xl p-5 shadow-sm border border-neutral-200 active:scale-98"
        style={{
          shadowColor: "#48C78E",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.08,
          shadowRadius: 8,
          elevation: 3,
        }}
      >
        {/* Header */}
        <View className="flex-row items-start justify-between mb-4">
          <View className="flex-1 mr-4">
            <View className="flex-row items-start mb-2">
              <Text 
                className="text-xl text-charcoal leading-7 flex-1"
                style={typography.heading}
              >
                {recipe.title}
              </Text>
              {recipe.url && (
                <View className="ml-2 mt-1 bg-blue-50 px-2 py-1 rounded-md border border-blue-200">
                  <View className="flex-row items-center">
                    <Ionicons name="cloud-outline" size={14} color="#3B82F6" />
                    <Text className="text-xs text-blue-600 ml-1 font-medium">WEB</Text>
                  </View>
                </View>
              )}
            </View>
            <View className="flex-row items-center">
              <Ionicons name="people" size={16} color="#6B7280" />
              <Text className="text-neutral-600 text-sm ml-1 font-medium" style={typography.body}>
                {recipe.servings} serving{recipe.servings !== 1 ? "s" : ""}
              </Text>
              <View className="w-1 h-1 bg-neutral-300 rounded-full mx-3" />
              <Ionicons name="restaurant" size={16} color="#6B7280" />
              <Text className="text-neutral-600 text-sm ml-1 font-medium" style={typography.body}>
                {recipe.ingredients.length} ingredient{recipe.ingredients.length !== 1 ? "s" : ""}
              </Text>
            </View>
          </View>
          
          {/* Add to List Button - Clear Action */}
          <View className="items-center">
            <Pressable
              onPress={handleAddToGroceryList}
              className="bg-citrus/15 p-3 rounded-2xl border border-citrus/30"
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              style={{
                shadowColor: "#FF8A4C",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.15,
                shadowRadius: 4,
                elevation: 2,
              }}
            >
              <Ionicons name="basket" size={24} color="#FF8A4C" />
            </Pressable>
            <Text 
              className="text-[11px] text-citrus mt-1 tracking-wide font-semibold"
              style={typography.accent}
            >
              ADD TO LIST
            </Text>
          </View>
        </View>

        {/* Fresh Ingredients Preview */}
        <View className="bg-fresh/5 rounded-2xl p-4 border border-fresh/10">
          <View className="flex-row items-center mb-3">
            <Ionicons name="leaf-outline" size={16} color="#48C78E" />
            <Text 
              className="text-fresh ml-2 tracking-wider"
              style={typography.accent}
            >
              INGREDIENTS
            </Text>
          </View>
          <View className="space-y-2">
            {recipe.ingredients.slice(0, 3).map((ingredient) => (
              <View key={ingredient.id} className="flex-row items-center">
                <View className="w-1.5 h-1.5 bg-fresh rounded-full mr-3" />
                <Text className="text-neutral-700 flex-1" style={typography.body}>
                  {ingredient.amount} {ingredient.unit} {ingredient.name}
                </Text>
              </View>
            ))}
            {recipe.ingredients.length > 3 && (
              <View className="flex-row items-center">
                <View className="w-1.5 h-1.5 bg-neutral-300 rounded-full mr-3" />
                <Text className="text-neutral-400 italic" style={typography.caption}>
                  +{recipe.ingredients.length - 3} more ingredient{recipe.ingredients.length - 3 !== 1 ? "s" : ""}
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Nibble Footer */}
        <View className="flex-row items-center justify-between mt-4">
          <Text className="text-neutral-400" style={typography.caption}>
            Added {new Date(recipe.createdAt).toLocaleDateString()}
          </Text>
          <View className="flex-row items-center">
            <Text 
              className="text-fresh mr-2" 
              style={typography.bodyMedium}
            >
              View Recipe
            </Text>
            <Ionicons name="chevron-forward" size={18} color="#48C78E" />
          </View>
        </View>
      </Pressable>

      <RecipeDetailModal
        recipe={recipe}
        visible={showDetail}
        onClose={() => setShowDetail(false)}
      />
    </>
  );
}