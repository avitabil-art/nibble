import React, { useState, useEffect } from "react";
import { View, Text, Modal } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRecipeStore } from "../state/recipeStore";
import { CollaboratorInfo, InvitationLink } from "../types/recipe";
import { typography } from "../utils/fonts";
import { PrimaryButton, SecondaryButton, GhostButton } from "./EnhancedButton";
import { useErrorModal } from "./ErrorModal";

interface ShareListModalProps {
  visible: boolean;
  listId: string | null;
  onClose: () => void;
}

export default function ShareListModal({ visible, listId, onClose }: ShareListModalProps) {
  const { 
    groceryLists, 
    currentUser, 
    createInvitation, 
    shareInvitation,
    getListCollaborators, 
    removeCollaborator,
    setBanner 
  } = useRecipeStore();

  const { showWarning, showError, ErrorModalComponent } = useErrorModal();
  const [isLoading, setIsLoading] = useState(false);
  const [inviteLink, setInviteLink] = useState<InvitationLink | null>(null);
  const [collaborators, setCollaborators] = useState<CollaboratorInfo[]>([]);

  const list = listId ? groceryLists.find(l => l.id === listId) : null;

  useEffect(() => {
    if (visible && listId) {
      setCollaborators(getListCollaborators(listId));
      // Reset invitation link when modal opens
      setInviteLink(null);
    }
  }, [visible, listId, getListCollaborators]);

  const handleCreateInvitation = async () => {
    if (!listId || !list) return;

    setIsLoading(true);
    try {
      const result = await createInvitation(listId);
      if (result.success && result.inviteLink) {
        setInviteLink(result.inviteLink);
        setBanner("Invitation created! Ready to share with your family.");
      } else {
        setBanner(result.error || "Failed to create invitation");
      }
    } catch (error) {
      setBanner("Something went wrong while creating the invitation");
    } finally {
      setIsLoading(false);
    }
  };

  const handleShareInvitation = async () => {
    if (!inviteLink || !list) return;

    setIsLoading(true);
    try {
      const result = await shareInvitation(inviteLink, list.name);
      if (result.success) {
        if (result.method === 'sms') {
          setBanner("Invitation sent via text message!");
        } else {
          setBanner("Invitation shared successfully!");
        }
      } else {
        setBanner(result.error || "Failed to share invitation");
      }
    } catch (error) {
      setBanner("Something went wrong while sharing the invitation");
    } finally {
      setIsLoading(false);
    }
  };

  const handleRemoveCollaborator = (userId: string, userName: string) => {
    if (!listId) return;

    showWarning(
      "Remove Collaborator",
      `Are you sure you want to remove ${userName} from this list? They will no longer be able to access or modify it.`,
      async () => {
        const result = await removeCollaborator(listId, userId);
        if (result.success) {
          setCollaborators(prev => prev.filter(c => c.userId !== userId));
          setBanner(`${userName} removed from the list`);
        } else {
          showError("Error", result.error || "Failed to remove collaborator");
        }
      }
    );
  };

  const isOwner = currentUser && list?.ownerId === currentUser.id;
  const canManageCollaborators = isOwner && list?.isShared;

  if (!list) return null;

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View className="flex-1 bg-offwhite">
        {/* Header */}
        <View className="flex-row items-center justify-between px-5 py-4 bg-white border-b border-neutral-200">
          <View className="flex-1">
            <Text className="text-charcoal" style={typography.heading}>
              Share List
            </Text>
            <Text className="text-neutral-500 mt-1" style={typography.caption}>
              {list.name}
            </Text>
          </View>
          <GhostButton
            title=""
            onPress={onClose}
            icon="chevron-down"
            size="small"
          />
        </View>

        <View className="flex-1 px-5 py-6">
          {!list.isShared || !inviteLink ? (
            // Not shared yet or no invitation created - show option to create invitation
            <View>
              <View className="bg-fresh/10 p-6 rounded-2xl mb-6">
                <View className="items-center mb-4">
                  <View className="bg-fresh/20 p-4 rounded-full mb-3">
                    <Ionicons name="people-outline" size={32} color="#48C78E" />
                  </View>
                  <Text className="text-charcoal text-center" style={typography.subheading}>
                    Invite family members
                  </Text>
                  <Text className="text-neutral-600 text-center mt-2" style={typography.body}>
                    Create an invitation link to share this list with your family. They'll be able to add items and see real-time updates.
                  </Text>
                </View>
                
                <PrimaryButton
                  title={isLoading ? "Creating invitation..." : "Create Invitation"}
                  onPress={handleCreateInvitation}
                  loading={isLoading}
                  fullWidth
                  icon="person-add"
                />
              </View>

              <View className="bg-neutral-100 p-4 rounded-xl">
                <Text className="text-neutral-600 text-sm" style={typography.caption}>
                  When you create an invitation, you'll get a secure link that opens in your messaging app. Send it to family members so they can join your grocery list.
                </Text>
              </View>
            </View>
          ) : (
            // Invitation created - show sharing options
            <View>
              {/* Invitation Section */}
              <View className="bg-white p-6 rounded-2xl border border-neutral-200 mb-6">
                <Text className="text-charcoal mb-4" style={typography.subheading}>
                  Invitation Ready
                </Text>
                
                <View className="bg-fresh/5 p-4 rounded-xl mb-4">
                  <View className="flex-row items-center mb-2">
                    <Ionicons name="link" size={20} color="#48C78E" />
                    <Text className="text-fresh ml-2 font-medium" style={typography.bodyMedium}>
                      Secure invitation link created
                    </Text>
                  </View>
                  <Text className="text-neutral-600" style={typography.caption}>
                    This link will expire on {inviteLink.expiresAt.toLocaleDateString()}
                  </Text>
                </View>

                <View className="space-y-3">
                  <PrimaryButton
                    title="Send Text Message"
                    onPress={handleShareInvitation}
                    loading={isLoading}
                    fullWidth
                    icon="chatbubble"
                  />
                  
                  <SecondaryButton
                    title="Share Another Way"
                    onPress={handleShareInvitation}
                    disabled={isLoading}
                    fullWidth
                    icon="share"
                  />
                </View>
              </View>

              {/* Collaborators Section */}
              <View className="bg-white p-6 rounded-2xl border border-neutral-200">
                <Text className="text-charcoal mb-4" style={typography.subheading}>
                  Collaborators ({collaborators.length})
                </Text>

                {collaborators.length === 0 ? (
                  <View className="items-center py-6">
                    <Ionicons name="person-add-outline" size={32} color="#A3A3A3" />
                    <Text className="text-neutral-500 mt-2 text-center" style={typography.body}>
                      No collaborators yet
                    </Text>
                    <Text className="text-neutral-400 text-center mt-1" style={typography.caption}>
                      Share the code above to invite family members
                    </Text>
                  </View>
                ) : (
                  <View>
                    {collaborators.map((collaborator) => (
                      <View
                        key={collaborator.userId}
                        className="flex-row items-center justify-between py-3 border-b border-neutral-100 last:border-b-0"
                      >
                        <View className="flex-row items-center flex-1">
                          <View className="bg-fresh/10 p-2 rounded-full mr-3">
                            <Ionicons name="person" size={16} color="#48C78E" />
                          </View>
                          <View className="flex-1">
                            <Text className="text-charcoal" style={typography.bodyMedium}>
                              {collaborator.userName}
                            </Text>
                            <Text className="text-neutral-500" style={typography.caption}>
                              {collaborator.isOwner ? "Owner" : "Collaborator"} • 
                              Joined {collaborator.joinedAt.toLocaleDateString()}
                            </Text>
                          </View>
                        </View>

                        {canManageCollaborators && !collaborator.isOwner && (
                          <GhostButton
                            title=""
                            onPress={() => handleRemoveCollaborator(collaborator.userId, collaborator.userName)}
                            icon="remove-circle-outline"
                            size="small"
                          />
                        )}
                      </View>
                    ))}
                  </View>
                )}
              </View>

              {isOwner && (
                <View className="bg-neutral-100 p-4 rounded-xl mt-4">
                  <Text className="text-neutral-600 text-sm" style={typography.caption}>
                    As the list owner, you can remove collaborators and manage sharing settings. 
                    Changes sync in real-time across all devices.
                  </Text>
                </View>
              )}
            </View>
          )}
        </View>
      </View>
      
      {/* Error Modal */}
      <ErrorModalComponent />
    </Modal>
  );
}