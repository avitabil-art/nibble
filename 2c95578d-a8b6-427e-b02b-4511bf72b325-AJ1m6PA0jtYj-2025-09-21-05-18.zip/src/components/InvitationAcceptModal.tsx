import React, { useState } from "react";
import { View, Text, Modal } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import { typography } from "../utils/fonts";
import { PrimaryButton, OutlineButton } from "./EnhancedButton";

interface InvitationAcceptModalProps {
  visible: boolean;
  invitation: {
    token: string;
    fromName?: string;
    listName?: string;
    expires?: Date;
  };
  onAccept: () => Promise<void>;
  onDecline: () => void;
}

export default function InvitationAcceptModal({
  visible,
  invitation,
  onAccept,
  onDecline
}: InvitationAcceptModalProps) {
  const [isAccepting, setIsAccepting] = useState(false);

  const handleAccept = async () => {
    setIsAccepting(true);
    try {
      await onAccept();
    } finally {
      setIsAccepting(false);
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="fade"
      transparent
      statusBarTranslucent
    >
      <View className="flex-1 bg-black/50 justify-center items-center px-4">
        <SafeAreaView className="w-full max-w-sm">
          <View className="bg-white rounded-3xl p-6 shadow-xl">
            {/* Header */}
            <View className="items-center mb-6">
              <View className="bg-fresh/10 p-4 rounded-full mb-4">
                <Ionicons name="people" size={32} color="#48C78E" />
              </View>
              <Text className="text-charcoal text-center" style={typography.heading}>
                You're Invited!
              </Text>
              <Text className="text-neutral-600 text-center mt-2" style={typography.body}>
                {invitation.fromName 
                  ? `${invitation.fromName} invited you to join their grocery list`
                  : "You've been invited to join a grocery list"
                }
              </Text>
            </View>

            {/* List Information */}
            <View className="bg-fresh/5 rounded-xl p-4 mb-6">
              <View className="flex-row items-center">
                <View className="bg-fresh/20 p-2 rounded-lg mr-3">
                  <Ionicons name="basket" size={20} color="#48C78E" />
                </View>
                <View className="flex-1">
                  <Text className="text-charcoal font-semibold" style={typography.bodyMedium}>
                    {invitation.listName || "Grocery List"}
                  </Text>
                  <Text className="text-neutral-500 text-sm" style={typography.caption}>
                    Collaborative shopping list
                  </Text>
                </View>
              </View>
            </View>

            {/* Expiration Notice */}
            {invitation.expires && (
              <View className="flex-row items-center bg-citrus/10 rounded-xl p-3 mb-6">
                <Ionicons name="time-outline" size={16} color="#FF8A4C" />
                <Text className="text-citrus ml-2 text-sm" style={typography.caption}>
                  Expires {invitation.expires.toLocaleDateString()}
                </Text>
              </View>
            )}

            {/* Benefits List */}
            <View className="mb-6">
              <Text className="text-neutral-700 mb-3" style={typography.bodyMedium}>
                What you'll get:
              </Text>
              <View className="space-y-2">
                <View className="flex-row items-center">
                  <View className="w-1.5 h-1.5 bg-fresh rounded-full mr-3" />
                  <Text className="text-neutral-600 text-sm" style={typography.body}>
                    Real-time list updates
                  </Text>
                </View>
                <View className="flex-row items-center">
                  <View className="w-1.5 h-1.5 bg-fresh rounded-full mr-3" />
                  <Text className="text-neutral-600 text-sm" style={typography.body}>
                    Collaborate on grocery shopping
                  </Text>
                </View>
                <View className="flex-row items-center">
                  <View className="w-1.5 h-1.5 bg-fresh rounded-full mr-3" />
                  <Text className="text-neutral-600 text-sm" style={typography.body}>
                    Never miss an item again
                  </Text>
                </View>
              </View>
            </View>

            {/* Action Buttons */}
            <View className="space-y-3">
              <PrimaryButton
                title={isAccepting ? "Joining..." : "Accept Invitation"}
                onPress={handleAccept}
                loading={isAccepting}
                fullWidth
                icon="checkmark-circle"
              />
              <OutlineButton
                title="Maybe Later"
                onPress={onDecline}
                disabled={isAccepting}
                fullWidth
              />
            </View>

            {/* Fine Print */}
            <Text className="text-neutral-400 text-xs text-center mt-4" style={typography.caption}>
              By accepting, you'll be able to view and edit this shared grocery list
            </Text>
          </View>
        </SafeAreaView>
      </View>
    </Modal>
  );
}