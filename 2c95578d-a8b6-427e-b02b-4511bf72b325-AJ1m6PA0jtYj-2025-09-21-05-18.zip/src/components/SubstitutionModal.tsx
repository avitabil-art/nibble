// Substitution feature removed intentionally.
// Keeping a no-op component to avoid import breakage during rollout if referenced.
import React from "react";
import { Modal } from "react-native";

export default function SubstitutionModal({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  return (
    <Modal visible={false} onRequestClose={onClose} />
  );
}
