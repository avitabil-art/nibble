import React, { useMemo, useState, useEffect } from "react";
import { Modal, View, Text, ScrollView, Pressable } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { Recipe } from "../types/recipe";
import { useRecipeStore } from "../state/recipeStore";

interface AddToListModalProps {
  recipe: Recipe;
  visible: boolean;
  onClose: () => void;
}

export default function AddToListModal({ recipe, visible, onClose }: AddToListModalProps) {
  const { addSelectedIngredientsToGroceryList, groceryLists, activeListId } = useRecipeStore();
  const [selected, setSelected] = useState<Record<string, boolean>>({});
  const [combine, setCombine] = useState(true);
  const [targetListId, setTargetListId] = useState(activeListId || "");
  const [banner, setBanner] = useState<string>("");

  const allChecked = useMemo(() => Object.values(selected).every(Boolean), [selected]);

  // Reset state when modal opens or recipe changes
  useEffect(() => {
    if (visible) {
      // Reset selected ingredients to all checked
      const map: Record<string, boolean> = {};
      for (const ing of recipe.ingredients) map[ing.id] = true;
      setSelected(map);
      
      // Reset target list to active list
      if (activeListId) {
        setTargetListId(activeListId);
      }
      
      // Clear any existing banner
      setBanner("");
    }
  }, [visible, recipe.id, activeListId]);

  // Clear banner when modal closes
  useEffect(() => {
    if (!visible) {
      setBanner("");
    }
  }, [visible]);

  const toggleAll = () => {
    const next: Record<string, boolean> = {};
    for (const ing of recipe.ingredients) next[ing.id] = !allChecked;
    setSelected(next);
  };

  const onToggle = (id: string) => setSelected((s) => ({ ...s, [id]: !s[id] }));

  const onAdd = () => {
    const ids = Object.entries(selected).filter(([, v]) => v).map(([k]) => k);
    const res = addSelectedIngredientsToGroceryList(recipe.id, ids, { 
      combine, 
      targetListId 
    }) as { added: number; combined: number; updated?: number; duplicates?: number } | void;
    
    if (res) {
      const targetList = groceryLists.find(list => list.id === targetListId);
      const listName = targetList?.name || "list";
      
      // Build comprehensive feedback message
      let message = "";
      const parts: string[] = [];
      
      if (res.added > 0) {
        parts.push(`${res.added} new item${res.added !== 1 ? "s" : ""} added`);
      }
      
      if (res.updated && res.updated > 0) {
        parts.push(`${res.updated} item${res.updated !== 1 ? "s" : ""} updated`);
      }
      
      if (res.combined > 0) {
        parts.push(`${res.combined} combined`);
      }
      
      if (res.duplicates && res.duplicates > 0) {
        parts.push(`${res.duplicates} already in list`);
      }
      
      if (parts.length > 0) {
        message = `${parts.join(", ")} to ${listName}—easy as pie!`;
      } else {
        message = `All items already in ${listName}—ready to nibble!`;
      }
      
      setBanner(message);
      setTimeout(() => {
        setBanner("");
        onClose();
      }, 1200);
    } else {
      onClose();
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <SafeAreaView className="flex-1 bg-stone-50">
        <View className="flex-row items-center justify-between px-4 py-3 bg-white border-b border-stone-200">
          <Pressable onPress={onClose}>
            <Text className="text-orange-600 font-medium">Cancel</Text>
          </Pressable>
          <Text className="text-lg font-semibold text-stone-800">Add to Grocery List</Text>
          <Pressable onPress={onAdd}>
            <Text className="text-orange-600 font-medium">Add</Text>
          </Pressable>
        </View>

        {banner ? (
          <View className={`mx-4 mt-3 rounded-xl px-3 py-2 ${
            banner.includes("already in list") || banner.includes("All selected items")
              ? "bg-yellow-50 border border-yellow-200"
              : "bg-green-50 border border-green-200"
          }`}>
            <Text className={`text-sm ${
              banner.includes("already in list") || banner.includes("All selected items")
                ? "text-yellow-700"
                : "text-green-700"
            }`}>
              {banner}
            </Text>
          </View>
        ) : null}

        {/* Target List Selector */}
        <View className="mx-4 mt-4 bg-white rounded-2xl p-4 border border-stone-200">
          <Text className="text-stone-700 font-medium mb-3">Add to List</Text>
          <View className="space-y-2">
            {groceryLists.map((list) => (
              <Pressable
                key={list.id}
                onPress={() => setTargetListId(list.id)}
                className="flex-row items-center py-2"
              >
                <View className={`w-5 h-5 rounded-full border-2 items-center justify-center mr-3 ${
                  list.id === targetListId 
                    ? "bg-orange-500 border-orange-500" 
                    : "border-stone-300"
                }`}>
                  {list.id === targetListId && (
                    <Ionicons name="checkmark" size={16} color="white" />
                  )}
                </View>
                <Text className={`text-base ${
                  list.id === targetListId ? "font-semibold text-stone-800" : "text-stone-600"
                }`}>
                  {list.name}
                </Text>
                <Text className="ml-2 text-sm text-stone-400">
                  ({list.items.length} items)
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        <ScrollView className="flex-1 px-4 py-4">
          <View className="bg-white rounded-2xl p-4 border border-stone-200">
            <View className="flex-row items-center justify-between mb-2">
              <Text className="text-stone-700 font-medium">Ingredients</Text>
              <Pressable onPress={toggleAll}>
                <Text className="text-orange-600 font-medium">{allChecked ? "Unselect all" : "Select all"}</Text>
              </Pressable>
            </View>
            {recipe.ingredients.map((ing) => (
              <Pressable key={ing.id} onPress={() => onToggle(ing.id)} className="flex-row items-center py-3">
                <View className={`w-6 h-6 rounded-full border-2 items-center justify-center ${selected[ing.id] ? "bg-orange-500 border-orange-500" : "border-stone-300"}`}>
                  {selected[ing.id] && <Ionicons name="checkmark" size={16} color="white" />}
                </View>
                <Text className="ml-3 text-stone-700">
                  {ing.amount} {ing.unit} {ing.name}
                </Text>
              </Pressable>
            ))}
            <View className="h-[1px] bg-stone-200 my-2" />
            <Pressable onPress={() => setCombine((c) => !c)} className="flex-row items-center py-2">
              <View className={`w-5 h-5 rounded border items-center justify-center ${combine ? "bg-orange-500 border-orange-500" : "border-stone-300"}`}>
                {combine && <Ionicons name="checkmark" size={16} color="white" />}
              </View>
              <Text className="ml-2 text-stone-700">Combine duplicates by name and unit</Text>
            </Pressable>
          </View>
        </ScrollView>

        <View className="px-4 pb-6">
          <Pressable onPress={onAdd} className="bg-orange-500 rounded-2xl py-4 items-center">
            <Text className="text-white font-semibold">Add ingredients to list</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    </Modal>
  );
}