import React from "react";
import { View, Text, Pressable } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { typography } from "../utils/fonts";

export default function AiSetupHint({ onPress }: { onPress: () => void }) {
  return (
    <View className="px-5 pb-2 bg-offwhite">
      <Pressable onPress={onPress} className="flex-row items-center bg-amber-50 border border-amber-200 rounded-2xl px-4 py-3">
        <Ionicons name="warning-outline" size={18} color="#F59E0B" />
        <Text className="ml-2 text-amber-700" style={typography.body}>AI not configured. Tap to add your API key.</Text>
      </Pressable>
    </View>
  );
}
