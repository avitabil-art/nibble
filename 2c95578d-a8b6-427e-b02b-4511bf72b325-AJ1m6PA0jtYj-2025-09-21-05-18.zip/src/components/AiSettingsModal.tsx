import React, { useEffect, useState } from "react";
import { Modal, View, Text, TextInput, Pressable } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { typography } from "../utils/fonts";
import { getProviderKey, setProviderKey, clearProviderKey, Provider } from "../utils/env";

export default function AiSettingsModal({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const [provider, setProvider] = useState<Provider>("openai");
  const [value, setValue] = useState("");
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    let mounted = true;
    async function load() {
      setLoading(true);
      try {
        const v = await getProviderKey(provider);
        if (mounted) setValue(v ? "••••••••" : "");
        setSaved(false);
      } finally {
        if (mounted) setLoading(false);
      }
    }
    if (visible) load();
    return () => { mounted = false; };
  }, [visible, provider]);

  const onSave = async () => {
    setLoading(true);
    try {
      await setProviderKey(provider, value);
      setSaved(true);
    } finally {
      setLoading(false);
    }
  };

  const onClear = async () => {
    setLoading(true);
    try {
      await clearProviderKey(provider);
      setValue("");
      setSaved(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <SafeAreaView className="flex-1 bg-offwhite">
        <View className="flex-row items-center justify-between px-4 py-3 bg-white border-b border-neutral-200">
          <Pressable onPress={onClose} className="px-2 py-1 rounded-lg bg-neutral-100 border border-neutral-200"><Text className="text-neutral-700">Close</Text></Pressable>
          <Text className="text-lg font-semibold text-charcoal">AI Settings</Text>
          <View style={{ width: 60 }} />
        </View>

        <View className="px-5 py-4">
          <Text className="text-neutral-600 mb-2" style={typography.body}>Provider</Text>
          <View className="flex-row mb-4">
            {["openai","anthropic","grok"].map(p => (
              <Pressable key={p} onPress={() => setProvider(p as Provider)} className={`px-3 py-2 mr-2 rounded-xl border ${provider===p ? "bg-fresh/10 border-fresh" : "bg-white border-neutral-200"}`}>
                <Text className={provider===p ? "text-fresh" : "text-neutral-700"} style={typography.body}>{p.toUpperCase()}</Text>
              </Pressable>
            ))}
          </View>

          <Text className="text-neutral-600 mb-2" style={typography.body}>API Key</Text>
          <TextInput
            className="bg-white border border-neutral-200 rounded-2xl px-4 py-3 text-charcoal"
            value={value}
            onChangeText={(t) => { setValue(t); setSaved(false); }}
            placeholder={`Enter ${provider.toUpperCase()} key (kept on device)`}
            placeholderTextColor="#9CA3AF"
            autoCapitalize="none"
            autoCorrect={false}
            secureTextEntry
          />

          {saved ? (
            <View className="mt-3 bg-fresh/10 border border-fresh/20 rounded-2xl px-3 py-2">
              <Text className="text-fresh" style={typography.body}>Saved. AI features are enabled for {provider.toUpperCase()}.</Text>
            </View>
          ) : null}

          <View className="flex-row mt-4">
            <Pressable onPress={onSave} disabled={loading} className={`flex-1 mr-2 items-center justify-center rounded-2xl py-3 ${loading?"bg-citrus/60":"bg-citrus"}`}>
              <Text className="text-white font-semibold">Save</Text>
            </Pressable>
            <Pressable onPress={onClear} disabled={loading} className={`flex-1 ml-2 items-center justify-center rounded-2xl py-3 ${loading?"bg-red-400":"bg-red-500"}`}>
              <Text className="text-white font-semibold">Clear</Text>
            </Pressable>
          </View>

          <View className="mt-5">
            <View className="flex-row items-center mb-1">
              <Ionicons name="shield-checkmark" size={16} color="#48C78E" />
              <Text className="text-neutral-600 ml-2" style={typography.caption}>Keys are stored securely on this device.</Text>
            </View>
            <Text className="text-neutral-400" style={typography.caption}>For production, set EAS Secrets for EXPO_PUBLIC_ variables to avoid per-device entry.</Text>
          </View>
        </View>
      </SafeAreaView>
    </Modal>
  );
}
