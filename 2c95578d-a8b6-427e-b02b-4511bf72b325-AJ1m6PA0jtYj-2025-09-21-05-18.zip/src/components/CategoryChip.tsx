import React from "react";
import { Pressable, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { typography } from "../utils/fonts";

interface CategoryChipProps {
  label: string;
  selected?: boolean;
  onPress?: () => void;
  onRemove?: () => void;
}

export default function CategoryChip({ label, selected, onPress, onRemove }: CategoryChipProps) {
  return (
    <View className="mr-3 mb-2">
      <Pressable
        onPress={onPress}
        className={`flex-row items-center px-4 py-2 rounded-2xl border ${
          selected ? "bg-fresh/15 border-fresh/30" : "bg-white border-neutral-200"
        }`}
        style={{
          shadowColor: selected ? "#48C78E" : "#000000",
          shadowOffset: { width: 0, height: 1 },
          shadowOpacity: selected ? 0.1 : 0.05,
          shadowRadius: 2,
          elevation: 1,
        }}
      >
        <Text 
          className={selected ? "text-fresh" : "text-neutral-600"}
          style={{...typography.accent, fontSize: 11}}
        >
          {label}
        </Text>
        {onRemove && (
          <Pressable onPress={onRemove} className="ml-2 p-1 rounded-full bg-neutral-100">
            <Ionicons name="close" size={12} color="#6B7280" />
          </Pressable>
        )}
      </Pressable>
    </View>
  );
}