import React, { useState } from "react";
import {
  View,
  Text,
  Modal,
  ScrollView,
  Pressable,
  TextInput,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRecipeStore } from "../state/recipeStore";
import { parseRecipeFromUrl, parseManualRecipe, parseIngredientsFromText } from "../utils/recipeParser";
import CategoryPicker from "./CategoryPicker";

interface AddRecipeModalProps {
  visible: boolean;
  onClose: () => void;
}

export default function AddRecipeModal({ visible, onClose }: AddRecipeModalProps) {
  const { addRecipe } = useRecipeStore();
  const [mode, setMode] = useState<"url" | "manual">("url");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>("");
  
  // URL mode
  const [url, setUrl] = useState("");
  
  // Manual mode
  const [title, setTitle] = useState("");
  const [ingredients, setIngredients] = useState("");
  const [instructions, setInstructions] = useState("");
  const [servings, setServings] = useState("4");

  // Categories
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);

  const resetForm = () => {
    setUrl("");
    setTitle("");
    setIngredients("");
    setInstructions("");
    setServings("4");
    setSelectedCategories([]);
    setError("");
    setMode("url");
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const handleUrlSubmit = async () => {
    if (!url.trim()) {
      setError("Please enter a recipe URL");
      return;
    }

    setLoading(true);
    setError("");
    try {
      const parsedData = await parseRecipeFromUrl(url.trim());
      const parsedIngredients = parseIngredientsFromText(parsedData.ingredients);
      
      addRecipe({
        title: parsedData.title,
        url: url.trim(),
        servings: parsedData.servings || 4,
        originalServings: parsedData.servings || 4,
        ingredients: parsedIngredients,
        instructions: parsedData.instructions,
        tags: selectedCategories,
      });
      
      handleClose();
    } catch (e) {
      setError("Failed to parse recipe from URL. You can still add it manually.");
    } finally {
      setLoading(false);
    }
  };

  const handleManualSubmit = () => {
    if (!title.trim() || !ingredients.trim() || !instructions.trim()) {
      setError("Please fill in title, ingredients, and instructions");
      return;
    }

    const servingsNum = parseInt(servings) || 4;
    const parsedData = parseManualRecipe(title, ingredients, instructions, servingsNum);
    const parsedIngredients = parseIngredientsFromText(parsedData.ingredients);
    
    addRecipe({
      title: parsedData.title,
      servings: servingsNum,
      originalServings: servingsNum,
      ingredients: parsedIngredients,
      instructions: parsedData.instructions,
      tags: selectedCategories,
    });
    
    handleClose();
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
    >
      <SafeAreaView className="flex-1 bg-stone-50">
        {/* Header */}
        <View className="flex-row items-center justify-between px-4 py-3 bg-white border-b border-stone-200">
          <Pressable onPress={handleClose}>
            <Text className="text-orange-600 text-base font-medium">Cancel</Text>
          </Pressable>
          <Text className="text-lg font-semibold text-stone-800">Add Recipe</Text>
          <Pressable
            onPress={mode === "url" ? handleUrlSubmit : handleManualSubmit}
            disabled={loading}
          >
            <Text className={`text-base font-medium ${
              loading ? "text-stone-400" : "text-orange-600"
            }`}>
              {loading ? "Adding..." : "Add"}
            </Text>
          </Pressable>
        </View>

        {error ? (
          <View className="mx-4 mt-3 bg-red-50 border border-red-200 rounded-xl px-3 py-2">
            <Text className="text-red-600 text-sm">{error}</Text>
          </View>
        ) : null}

        {/* Mode Selector */}
        <View className="flex-row bg-white mx-4 mt-4 rounded-xl p-1">
          <Pressable
            onPress={() => setMode("url")}
            className={`flex-1 py-3 rounded-lg items-center ${
              mode === "url" ? "bg-orange-500" : "bg-transparent"
            }`}
          >
            <Text className={`font-medium ${
              mode === "url" ? "text-white" : "text-stone-600"
            }`}>
              From URL
            </Text>
          </Pressable>
          <Pressable
            onPress={() => setMode("manual")}
            className={`flex-1 py-3 rounded-lg items-center ${
              mode === "manual" ? "bg-orange-500" : "bg-transparent"
            }`}
          >
            <Text className={`font-medium ${
              mode === "manual" ? "text-white" : "text-stone-600"
            }`}>
              Manual Entry
            </Text>
          </Pressable>
        </View>

        <ScrollView className="flex-1 px-4 py-4">
          {mode === "url" ? (
            <View className="space-y-6">
              <View>
                <Text className="text-stone-700 font-medium mb-3">Recipe URL</Text>
                <TextInput
                  className="bg-white rounded-xl px-4 py-4 text-base text-stone-800 border border-stone-200"
                  placeholder="https://example.com/recipe"
                  placeholderTextColor="#a8a29e"
                  value={url}
                  onChangeText={setUrl}
                  autoCapitalize="none"
                  keyboardType="url"
                  multiline
                />
                <Text className="text-stone-500 text-sm mt-2">
                  Paste a recipe URL and we will extract the ingredients and instructions automatically.
                </Text>
              </View>

              {/* Categories */}
              <CategoryPicker value={selectedCategories} onChange={setSelectedCategories} />
            </View>
          ) : (
            <View className="space-y-6">
              {/* Title */}
              <View>
                <Text className="text-stone-700 font-medium mb-3">Recipe Title</Text>
                <TextInput
                  className="bg-white rounded-xl px-4 py-4 text-base text-stone-800 border border-stone-200"
                  placeholder="Enter recipe title"
                  placeholderTextColor="#a8a29e"
                  value={title}
                  onChangeText={setTitle}
                />
              </View>

              {/* Servings */}
              <View>
                <Text className="text-stone-700 font-medium mb-3">Servings</Text>
                <TextInput
                  className="bg-white rounded-xl px-4 py-4 text-base text-stone-800 border border-stone-200"
                  placeholder="4"
                  placeholderTextColor="#a8a29e"
                  value={servings}
                  onChangeText={setServings}
                  keyboardType="numeric"
                />
              </View>

              {/* Categories */}
              <CategoryPicker value={selectedCategories} onChange={setSelectedCategories} />

              {/* Ingredients */}
              <View>
                <Text className="text-stone-700 font-medium mb-3">Ingredients</Text>
                <TextInput
                  className="bg-white rounded-xl px-4 py-4 text-base text-stone-800 border border-stone-200 min-h-32"
                  placeholder="1 cup flour&#10;2 eggs&#10;1/2 cup milk"
                  placeholderTextColor="#a8a29e"
                  value={ingredients}
                  onChangeText={setIngredients}
                  multiline
                  textAlignVertical="top"
                />
                <Text className="text-stone-500 text-sm mt-2">
                  Enter each ingredient on a new line
                </Text>
              </View>

              {/* Instructions */}
              <View>
                <Text className="text-stone-700 font-medium mb-3">Instructions</Text>
                <TextInput
                  className="bg-white rounded-xl px-4 py-4 text-base text-stone-800 border border-stone-200 min-h-32"
                  placeholder="1. Mix dry ingredients&#10;2. Add wet ingredients&#10;3. Bake at 350°F"
                  placeholderTextColor="#a8a29e"
                  value={instructions}
                  onChangeText={setInstructions}
                  multiline
                  textAlignVertical="top"
                />
                <Text className="text-stone-500 text-sm mt-2">
                  Enter each step on a new line
                </Text>
              </View>
            </View>
          )}
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
}