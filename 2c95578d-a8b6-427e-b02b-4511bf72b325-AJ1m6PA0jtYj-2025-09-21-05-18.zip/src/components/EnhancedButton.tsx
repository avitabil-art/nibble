import React from "react";
import { Pressable, Text, ActivityIndicator, ViewStyle, TextStyle } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { cn } from "../utils/cn";
import { typography } from "../utils/fonts";

export type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'ghost' | 'outline';
export type ButtonSize = 'small' | 'medium' | 'large';

interface EnhancedButtonProps {
  title: string;
  onPress: () => void;
  variant?: ButtonVariant;
  size?: ButtonSize;
  disabled?: boolean;
  loading?: boolean;
  icon?: keyof typeof Ionicons.glyphMap;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
  className?: string;
  textClassName?: string;
  style?: ViewStyle;
  testID?: string;
}

const getVariantStyles = (variant: ButtonVariant, disabled: boolean, loading: boolean) => {
  const isDisabled = disabled || loading;
  
  switch (variant) {
    case 'primary':
      return {
        container: cn(
          "bg-fresh rounded-xl border border-fresh shadow-sm",
          isDisabled && "bg-fresh/50 border-fresh/50"
        ),
        text: cn("text-white font-semibold", isDisabled && "text-white/70"),
        pressedStyle: { backgroundColor: '#3BA76B', transform: [{ scale: 0.98 }] } // Darker fresh
      };
    
    case 'secondary':
      return {
        container: cn(
          "bg-citrus rounded-xl border border-citrus shadow-sm",
          isDisabled && "bg-citrus/50 border-citrus/50"
        ),
        text: cn("text-white font-semibold", isDisabled && "text-white/70"),
        pressedStyle: { backgroundColor: '#E6783D', transform: [{ scale: 0.98 }] } // Darker citrus
      };
    
    case 'danger':
      return {
        container: cn(
          "bg-berry rounded-xl border border-berry shadow-sm",
          isDisabled && "bg-berry/50 border-berry/50"
        ),
        text: cn("text-white font-semibold", isDisabled && "text-white/70"),
        pressedStyle: { backgroundColor: '#E6435A', transform: [{ scale: 0.98 }] } // Darker berry
      };
    
    case 'ghost':
      return {
        container: cn(
          "bg-transparent rounded-xl",
          isDisabled && "opacity-50"
        ),
        text: cn("text-charcoal font-medium", isDisabled && "text-charcoal/50"),
        pressedStyle: { backgroundColor: '#F5F5F5', transform: [{ scale: 0.98 }] }
      };
    
    case 'outline':
      return {
        container: cn(
          "bg-white rounded-xl border border-neutral-300 shadow-sm",
          isDisabled && "border-neutral-200 bg-neutral-50"
        ),
        text: cn("text-charcoal font-medium", isDisabled && "text-charcoal/50"),
        pressedStyle: { backgroundColor: '#F8F9FA', borderColor: '#6B7280', transform: [{ scale: 0.98 }] }
      };
    
    default:
      return {
        container: "bg-fresh rounded-xl border border-fresh shadow-sm",
        text: "text-white font-semibold",
        pressedStyle: { backgroundColor: '#3BA76B', transform: [{ scale: 0.98 }] }
      };
  }
};

const getSizeStyles = (size: ButtonSize) => {
  switch (size) {
    case 'small':
      return {
        container: "px-3 py-2",
        text: "text-sm",
        iconSize: 16 as const
      };
    case 'large':
      return {
        container: "px-6 py-4",
        text: "text-lg",
        iconSize: 24 as const
      };
    case 'medium':
    default:
      return {
        container: "px-4 py-3",
        text: "text-base",
        iconSize: 20 as const
      };
  }
};

export default function EnhancedButton({
  title,
  onPress,
  variant = 'primary',
  size = 'medium',
  disabled = false,
  loading = false,
  icon,
  iconPosition = 'left',
  fullWidth = false,
  className,
  textClassName,
  style,
  testID
}: EnhancedButtonProps) {
  const variantStyles = getVariantStyles(variant, disabled, loading);
  const sizeStyles = getSizeStyles(size);
  
  const isDisabled = disabled || loading;
  
  const renderContent = () => {
    if (loading) {
      return (
        <>
          <ActivityIndicator 
            size="small" 
            color={variant === 'ghost' || variant === 'outline' ? '#374151' : '#FFFFFF'} 
          />
          <Text 
            className={cn(variantStyles.text, sizeStyles.text, "ml-2", textClassName)}
            style={typography.bodyMedium}
          >
            {title}
          </Text>
        </>
      );
    }

    if (icon && iconPosition === 'left') {
      return (
        <>
          <Ionicons 
            name={icon} 
            size={sizeStyles.iconSize} 
            color={variant === 'ghost' || variant === 'outline' ? '#374151' : '#FFFFFF'} 
          />
          <Text 
            className={cn(variantStyles.text, sizeStyles.text, "ml-2", textClassName)}
            style={typography.bodyMedium}
          >
            {title}
          </Text>
        </>
      );
    }

    if (icon && iconPosition === 'right') {
      return (
        <>
          <Text 
            className={cn(variantStyles.text, sizeStyles.text, "mr-2", textClassName)}
            style={typography.bodyMedium}
          >
            {title}
          </Text>
          <Ionicons 
            name={icon} 
            size={sizeStyles.iconSize} 
            color={variant === 'ghost' || variant === 'outline' ? '#374151' : '#FFFFFF'} 
          />
        </>
      );
    }

    return (
      <Text 
        className={cn(variantStyles.text, sizeStyles.text, textClassName)}
        style={typography.bodyMedium}
      >
        {title}
      </Text>
    );
  };

  return (
    <Pressable
      onPress={isDisabled ? undefined : onPress}
      disabled={isDisabled}
      className={cn(
        "flex-row items-center justify-center",
        variantStyles.container,
        sizeStyles.container,
        fullWidth && "w-full",
        className
      )}
      style={({ pressed }) => [
        style,
        pressed && !isDisabled ? variantStyles.pressedStyle : {}
      ]}
      testID={testID}
      accessibilityRole="button"
      accessibilityState={{ disabled: isDisabled }}
      accessibilityLabel={title}
    >
      {renderContent()}
    </Pressable>
  );
}

// Convenience components for common button types
export const PrimaryButton = (props: Omit<EnhancedButtonProps, 'variant'>) => (
  <EnhancedButton {...props} variant="primary" />
);

export const SecondaryButton = (props: Omit<EnhancedButtonProps, 'variant'>) => (
  <EnhancedButton {...props} variant="secondary" />
);

export const DangerButton = (props: Omit<EnhancedButtonProps, 'variant'>) => (
  <EnhancedButton {...props} variant="danger" />
);

export const GhostButton = (props: Omit<EnhancedButtonProps, 'variant'>) => (
  <EnhancedButton {...props} variant="ghost" />
);

export const OutlineButton = (props: Omit<EnhancedButtonProps, 'variant'>) => (
  <EnhancedButton {...props} variant="outline" />
);