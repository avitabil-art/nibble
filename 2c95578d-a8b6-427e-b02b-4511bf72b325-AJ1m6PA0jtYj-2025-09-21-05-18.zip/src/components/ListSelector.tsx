import React, { useState } from "react";
import { View, Text, Pressable, Modal, TextInput } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRecipeStore } from "../state/recipeStore";
import { typography } from "../utils/fonts";
import ShareListModal from "./ShareListModal";
import JoinListModal from "./JoinListModal";
import { useErrorModal } from "./ErrorModal";

export default function ListSelector() {
  const { 
    groceryLists, 
    activeListId, 
    setActiveList, 
    createGroceryList, 
    deleteGroceryList, 
    renameGroceryList,
    leaveSharedList,
    currentUser,
    syncStatus 
  } = useRecipeStore();
  
  const { showWarning, showError, ErrorModalComponent } = useErrorModal();
  
  const [showDropdown, setShowDropdown] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [shareListId, setShareListId] = useState<string | null>(null);
  const [newListName, setNewListName] = useState("");
  const [editingListId, setEditingListId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState("");

  const activeList = groceryLists.find((list) => list.id === activeListId);

  const handleCreateList = () => {
    if (newListName.trim()) {
      // Check for duplicate names
      const exists = groceryLists.some((list) => 
        list.name.toLowerCase() === newListName.trim().toLowerCase()
      );
      if (exists) {
        showError("Duplicate Name", "A list with this name already exists.");
        return;
      }
      createGroceryList(newListName.trim());
      setNewListName("");
      setShowCreateModal(false);
    }
  };

  const handleDeleteList = (listId: string) => {
    const list = groceryLists.find((l) => l.id === listId);
    if (!list) return;

    if (list.isShared) {
      // For shared lists, offer to leave instead of delete
      const isOwner = currentUser && list.ownerId === currentUser.id;
      showWarning(
        isOwner ? "Delete Shared List" : "Leave Shared List",
        isOwner 
          ? `Are you sure you want to delete "${list.name}"? This will remove it for all collaborators and cannot be undone.`
          : `Are you sure you want to leave "${list.name}"? You'll no longer have access to this shared list.`,
        async () => {
          if (isOwner) {
            // Owner deletes the list locally (we'd need a server endpoint to fully delete)
            deleteGroceryList(listId);
          } else {
            // Non-owner leaves the shared list
            const result = await leaveSharedList(listId);
            if (!result.success) {
              showError("Error", result.error || "Failed to leave shared list");
            }
          }
        }
      );
    } else {
      // Regular delete for non-shared lists
      showWarning(
        "Delete List",
        `Are you sure you want to delete "${list.name}"? This will permanently remove all items in this list.`,
        () => deleteGroceryList(listId)
      );
    }
  };

  const handleRenameList = (listId: string) => {
    if (editingName.trim()) {
      // Check for duplicate names (excluding current list)
      const exists = groceryLists.some((list) => 
        list.id !== listId && list.name.toLowerCase() === editingName.trim().toLowerCase()
      );
      if (exists) {
        showError("Duplicate Name", "A list with this name already exists.");
        return;
      }
      renameGroceryList(listId, editingName.trim());
      setEditingListId(null);
      setEditingName("");
    }
  };

  const startEditing = (listId: string, currentName: string) => {
    setEditingListId(listId);
    setEditingName(currentName);
  };

  const handleInviteToList = (listId: string) => {
    setShareListId(listId);
    setShowShareModal(true);
    setShowDropdown(false);
  };

  const handleJoinList = () => {
    setShowJoinModal(true);
    setShowDropdown(false);
  };

  return (
    <View className="relative">
      {/* Main Selector Button - Nibble Style */}
      <Pressable
        onPress={() => setShowDropdown(!showDropdown)}
        className="flex-row items-center justify-between bg-offwhite px-5 py-4"
      >
        <View className="flex-row items-center flex-1">
          <View className="bg-fresh/10 p-2 rounded-xl mr-3">
            <Ionicons name="basket" size={18} color="#48C78E" />
          </View>
          <View className="flex-1">
            <View className="flex-row items-center">
              <Text 
                className="text-charcoal flex-1"
                style={typography.heading}
              >
                {activeList?.name || "Select List"}
              </Text>
              {activeList?.isShared && (
                <View className="bg-fresh/10 px-2 py-1 rounded-md ml-2 flex-row items-center">
                  <Ionicons name="people" size={16} color="#48C78E" />
                  <Text className="text-fresh text-xs ml-1 font-medium">SHARED</Text>
                </View>
              )}
              {syncStatus.isSyncing && (
                <View className="ml-2">
                  <Ionicons name="sync" size={16} color="#FF8A4C" />
                </View>
              )}
            </View>
            {activeList && (
              <Text 
                className="text-neutral-500 mt-1"
                style={typography.caption}
              >
                {activeList.items.length} item{activeList.items.length !== 1 ? "s" : ""} • 
                {activeList.isShared ? " Shared" : " Personal"} • Ready to nibble
              </Text>
            )}
          </View>
        </View>
        <View className="bg-neutral-100 p-2 rounded-xl">
          <Ionicons 
            name={showDropdown ? "chevron-up" : "chevron-down"} 
            size={18} 
            color="#737373" 
          />
        </View>
      </Pressable>

      {/* Dropdown Menu */}
      {showDropdown && (
        <View className="absolute top-full left-0 right-0 bg-white border border-stone-200 rounded-b-xl shadow-lg z-50">
          {groceryLists.map((list) => (
            <View key={list.id}>
              {editingListId === list.id ? (
                <View className="flex-row items-center px-4 py-3 border-b border-stone-100">
                  <TextInput
                    value={editingName}
                    onChangeText={setEditingName}
                    className="flex-1 text-base text-stone-800 bg-stone-50 px-3 py-2 rounded-lg mr-2"
                    placeholder="List name"
                    autoFocus
                    onSubmitEditing={() => handleRenameList(list.id)}
                  />
                  <Pressable
                    onPress={() => handleRenameList(list.id)}
                    className="p-2"
                  >
                    <Ionicons name="checkmark" size={20} color="#22c55e" />
                  </Pressable>
                  <Pressable
                    onPress={() => {
                      setEditingListId(null);
                      setEditingName("");
                    }}
                    className="p-2"
                  >
                    <Ionicons name="close" size={20} color="#ef4444" />
                  </Pressable>
                </View>
              ) : (
                <View className="flex-row items-center">
                  <Pressable
                    onPress={() => {
                      setActiveList(list.id);
                      setShowDropdown(false);
                    }}
                    className="flex-1 flex-row items-center justify-between px-4 py-3 border-b border-stone-100"
                  >
                    <View className="flex-row items-center flex-1">
                      <View className={`w-3 h-3 rounded-full mr-3 ${
                        list.id === activeListId ? "bg-citrus" : "bg-neutral-300"
                      }`} />
                      <View className="flex-1">
                        <View className="flex-row items-center">
                          <Text className={`text-base ${
                            list.id === activeListId ? "font-semibold text-charcoal" : "text-neutral-600"
                          }`}>
                            {list.name}
                          </Text>
                          {list.isShared && (
                            <View className="bg-fresh/10 px-2 py-1 rounded ml-2 flex-row items-center">
                              <Ionicons name="people" size={14} color="#48C78E" />
                            </View>
                          )}
                        </View>
                        <Text className="text-sm text-neutral-400">
                          {list.items.length} item{list.items.length !== 1 ? "s" : ""}
                          {list.isShared && " • Shared"}
                        </Text>
                      </View>
                    </View>
                  </Pressable>
                  <Pressable
                    onPress={() => handleInviteToList(list.id)}
                    className="p-3"
                    hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                  >
                    <Ionicons 
                      name={list.isShared ? "people" : "person-add-outline"} 
                      size={16} 
                      color={list.isShared ? "#48C78E" : "#6b7280"} 
                    />
                  </Pressable>
                  <Pressable
                    onPress={() => startEditing(list.id, list.name)}
                    className="p-2 rounded-full bg-neutral-100"
                    hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  >
                    <Ionicons name="create-outline" size={18} color="#6B7280" />
                  </Pressable>
                  {groceryLists.length > 1 && (
                    <Pressable
                      onPress={() => handleDeleteList(list.id)}
                      className="p-3"
                      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                    >
                      <Ionicons 
                        name={list.isShared ? "exit-outline" : "trash-outline"} 
                        size={16} 
                        color="#ef4444" 
                      />
                    </Pressable>
                  )}
                </View>
              )}
            </View>
          ))}
          
          {/* Create New List Button */}
          <Pressable
            onPress={() => {
              setShowCreateModal(true);
              setShowDropdown(false);
            }}
            className="flex-row items-center px-4 py-3 border-b border-neutral-100"
          >
            <Ionicons name="document-outline" size={20} color="#FF8A4C" />
            <Text className="ml-2 text-base font-medium text-citrus">
              Create New List
            </Text>
          </Pressable>

          {/* Join Shared List Button */}
          <Pressable
            onPress={handleJoinList}
            className="flex-row items-center px-4 py-3"
          >
            <Ionicons name="people-outline" size={20} color="#48C78E" />
            <Text className="ml-2 text-base font-medium text-fresh">
              Join Shared List
            </Text>
          </Pressable>
        </View>
      )}

      {/* Create List Modal */}
      <Modal
        visible={showCreateModal}
        animationType="fade"
        transparent
        onRequestClose={() => setShowCreateModal(false)}
      >
        <View className="flex-1 bg-black/50 justify-center items-center px-4">
          <View className="bg-white rounded-2xl p-6 w-full max-w-sm">
            <Text className="text-xl font-semibold text-stone-800 mb-4">
              Create New List
            </Text>
            <TextInput
              value={newListName}
              onChangeText={setNewListName}
              placeholder="Enter list name"
              className="bg-stone-50 px-4 py-3 rounded-xl text-base text-stone-800 mb-4"
              autoFocus
              onSubmitEditing={handleCreateList}
            />
            <View className="flex-row justify-end space-x-3">
              <Pressable
                onPress={() => {
                  setShowCreateModal(false);
                  setNewListName("");
                }}
                className="px-4 py-2"
              >
                <Text className="text-stone-600 font-medium">Cancel</Text>
              </Pressable>
              <Pressable
                onPress={handleCreateList}
                className="bg-orange-500 px-6 py-2 rounded-xl"
                disabled={!newListName.trim()}
              >
                <Text className="text-white font-semibold">Create</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      {/* Share List Modal */}
      <ShareListModal
        visible={showShareModal}
        listId={shareListId}
        onClose={() => {
          setShowShareModal(false);
          setShareListId(null);
        }}
      />

      {/* Join Shared List Modal */}
      <JoinListModal
        visible={showJoinModal}
        onClose={() => setShowJoinModal(false)}
      />
      
      {/* Error Modal */}
      <ErrorModalComponent />
    </View>
  );
}