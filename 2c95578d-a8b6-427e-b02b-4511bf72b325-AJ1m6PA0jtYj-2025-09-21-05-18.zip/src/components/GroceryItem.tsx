import React from "react";
import { View, Text, Pressable } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRecipeStore } from "../state/recipeStore";
import { GroceryItem as GroceryItemType } from "../types/recipe";

import ItemEditSheet from "./ItemEditSheet";
import { typography } from "../utils/fonts";

interface GroceryItemProps {
  item: GroceryItemType;
}

export default function GroceryItem({ item }: GroceryItemProps) {
  const { 
    toggleGroceryItem, 
    removeGroceryItem, 
    updateGroceryItem, 
    getActiveList,
    getListCollaborators,
    currentUser 
  } = useRecipeStore();

  const [editOpen, setEditOpen] = React.useState(false);

  const activeList = getActiveList();
  const collaborators = activeList ? getListCollaborators(activeList.id) : [];
  const modifiedByUser = collaborators.find(c => c.userId === item.modifiedBy);
  const isModifiedByCurrentUser = currentUser && item.modifiedBy === currentUser.id;

  const formatAmount = () => {
    if (!item.amount || !item.unit) return "";
    
    // Format decimal amounts nicely
    const amount = item.amount;
    let formattedAmount: string;
    
    if (amount % 1 === 0) {
      formattedAmount = amount.toString();
    } else if (amount === 0.5) {
      formattedAmount = "½";
    } else if (amount === 0.25) {
      formattedAmount = "¼";
    } else if (amount === 0.75) {
      formattedAmount = "¾";
    } else if (amount === 0.333 || amount === 1/3) {
      formattedAmount = "⅓";
    } else if (amount === 0.667 || amount === 2/3) {
      formattedAmount = "⅔";
    } else {
      formattedAmount = amount.toFixed(2).replace(/\.?0+$/, "");
    }
    
    return `${formattedAmount} ${item.unit}`;
  };

  return (
    <View 
      className={`flex-row items-center py-4 px-5 bg-white rounded-2xl mb-3 border ${
        item.checked ? "border-fresh/20" : "border-neutral-200"
      }`}
      style={{
        shadowColor: item.checked ? "#48C78E" : "#000000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: item.checked ? 0.1 : 0.05,
        shadowRadius: 4,
        elevation: 2,
      }}
    >
      {/* Nibble Checkbox - Satisfying Interaction */}
      <Pressable
        onPress={() => toggleGroceryItem(item.id)}
        className="mr-4"
        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
      >
        <View className={`w-7 h-7 rounded-2xl border-2 items-center justify-center transition-all duration-200 ${
          item.checked 
            ? "bg-fresh border-fresh scale-105" 
            : "border-neutral-300 bg-white"
        }`}>
          {item.checked && (
            <Ionicons name="checkmark" size={18} color="white" />
          )}
        </View>
      </Pressable>

      {/* Item Content - Nibble Style */}
      <View className="flex-1">
        <Text 
          className={item.checked ? "text-neutral-400 line-through" : "text-charcoal"}
          style={{
            ...typography.bodyMedium,
            fontSize: 16,
            textDecorationLine: item.checked ? 'line-through' : 'none'
          }}
        >
          {item.name}
        </Text>
        {formatAmount() && (
          <Text 
            className={item.checked ? "text-neutral-300" : "text-neutral-500"}
            style={{...typography.body, marginTop: 2}}
          >
            {formatAmount()}
          </Text>
        )}
        {item.notes ? (
          <Text 
            className="text-neutral-400 italic mt-1" 
            numberOfLines={1}
            style={typography.caption}
          >
            {item.notes}
          </Text>
        ) : null}
        
        {/* Show who modified this item in shared lists */}
        {activeList?.isShared && modifiedByUser && !isModifiedByCurrentUser && (
          <Text 
            className="text-neutral-400 mt-1" 
            style={typography.caption}
          >
            Added by {modifiedByUser.userName}
          </Text>
        )}
      </View>

      {/* Actions - Clear and Intuitive */}
      <View className="flex-row items-center ml-3">
        <Pressable
          onPress={() => setEditOpen(true)}
          className="bg-neutral-50 p-2 rounded-xl mr-2"
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        >
          <Ionicons name="create-outline" size={18} color="#6B7280" />
        </Pressable>

        <Pressable
          onPress={() => removeGroceryItem(item.id)}
          className="bg-red-50 p-2 rounded-xl"
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        >
          <Ionicons name="trash-outline" size={18} color="#EF4444" />
        </Pressable>
      </View>

      <ItemEditSheet
        visible={editOpen}
        item={item}
        onClose={() => setEditOpen(false)}
        onSave={(u) => updateGroceryItem(item.id, u)}
        onDelete={() => removeGroceryItem(item.id)}
      />
    </View>
  );
}