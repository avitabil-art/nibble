import React, { useMemo, useState } from "react";
import { Modal, View, Text, TextInput, Pressable, ScrollView } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { GroceryItem } from "../types/recipe";

const PIECES = ["piece", "slice", "clove", "egg"] as const;
const VOL_US = ["tsp", "tbsp", "cup"] as const;
const VOL_METRIC = ["mL", "L"] as const;
const WEIGHT_METRIC = ["g", "kg"] as const;
const WEIGHT_US = ["oz", "lb"] as const;

function roundByUnit(unit: string, value: number) {
  const u = (unit || "piece").toLowerCase();
  const step = u === "tsp" ? 0.25
    : u === "tbsp" ? 0.5
    : u === "cup" ? 0.125
    : u === "oz" ? 0.25
    : u === "lb" ? 0.125
    : u === "kg" ? 0.05
    : u === "g" ? (value >= 100 ? 5 : 1)
    : 0.5; // pieces
  return Math.max(0, Math.round(value / step) * step);
}

function sameFamily(a: string, b: string) {
  const U = (x: string) => x.toLowerCase();
  const A = U(a), B = U(b);
  const inArr = (arr: readonly string[]) => (x: string) => arr.map(U).includes(x);
  return (
    inArr(PIECES as any)(A) && inArr(PIECES as any)(B)
  ) || (
    inArr(VOL_US as any)(A) && inArr(VOL_US as any)(B)
  ) || (
    inArr(VOL_METRIC as any)(A) && inArr(VOL_METRIC as any)(B)
  ) || (
    inArr(WEIGHT_US as any)(A) && inArr(WEIGHT_US as any)(B)
  ) || (
    inArr(WEIGHT_METRIC as any)(A) && inArr(WEIGHT_METRIC as any)(B)
  );
}

function convertAmount(value: number, from: string, to: string) {
  const f = from.toLowerCase();
  const t = to.toLowerCase();
  if (f === t) return value;
  // Volume US: tsp <-> tbsp <-> cup
  if (["tsp","tbsp","cup"].includes(f) && ["tsp","tbsp","cup"].includes(t)) {
    const toTsp = f === "tsp" ? value : f === "tbsp" ? value * 3 : value * 48;
    return t === "tsp" ? toTsp : t === "tbsp" ? toTsp / 3 : toTsp / 48;
  }
  // Metric volume: mL <-> L
  if (["ml","l"].includes(f) && ["ml","l"].includes(t)) {
    const toMl = f === "ml" ? value : value * 1000;
    return t === "ml" ? toMl : toMl / 1000;
  }
  // Weight US: oz <-> lb
  if (["oz","lb"].includes(f) && ["oz","lb"].includes(t)) {
    const toOz = f === "oz" ? value : value * 16;
    return t === "oz" ? toOz : toOz / 16;
  }
  // Weight metric: g <-> kg
  if (["g","kg"].includes(f) && ["g","kg"].includes(t)) {
    const toG = f === "g" ? value : value * 1000;
    return t === "g" ? toG : toG / 1000;
  }
  // Different families -> no conversion
  return value;
}

interface ItemEditSheetProps {
  visible: boolean;
  item: GroceryItem;
  onClose: () => void;
  onSave: (update: Partial<GroceryItem>) => void;
  onDelete?: () => void;
}

export default function ItemEditSheet({ visible, item, onClose, onSave, onDelete }: ItemEditSheetProps) {
  const [name, setName] = useState(item.name);
  const [amountText, setAmountText] = useState(String(item.amount ?? 1));
  const [unit, setUnit] = useState(item.unit || "piece");
  const [notes, setNotes] = useState(item.notes || "");

  const amount = useMemo(() => {
    const n = parseFloat(amountText.replace(",", "."));
    return isNaN(n) ? 0 : n;
  }, [amountText]);

  const families = [
    { title: "Pieces", units: PIECES },
    { title: "Volume", units: VOL_US },
    { title: "Volume (Metric)", units: VOL_METRIC },
    { title: "Weight", units: WEIGHT_US },
    { title: "Weight (Metric)", units: WEIGHT_METRIC },
  ];

  const changeUnit = (next: string) => {
    const a = amount || 0;
    const converted = sameFamily(unit, next) ? convertAmount(a, unit, next) : a;
    const rounded = roundByUnit(next, converted);
    setUnit(next);
    setAmountText(String(rounded));
  };

  const step = useMemo(() => {
    const u = (unit || "piece").toLowerCase();
    return u === "tsp" ? 0.25 : u === "tbsp" ? 0.5 : u === "cup" ? 0.125
      : u === "oz" ? 0.25 : u === "lb" ? 0.125
      : u === "kg" ? 0.05 : u === "g" ? 1 : 0.5;
  }, [unit]);

  const inc = (dir: 1 | -1) => {
    const a = amount || 0;
    const next = Math.max(0, a + dir * step);
    setAmountText(String(roundByUnit(unit, next)));
  };

  const handleSave = () => {
    const rounded = roundByUnit(unit, amount || 0);
    const min = unit.toLowerCase() === "tsp" ? 0.25 : unit.toLowerCase() === "tbsp" ? 0.5 : unit.toLowerCase() === "cup" ? 0.125 : 0.5;
    const finalAmount = rounded === 0 ? min : rounded;
    onSave({ name: name.trim() || item.name, amount: finalAmount, unit, notes });
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <SafeAreaView className="flex-1 bg-stone-50">
        <View className="flex-row items-center justify-between px-4 py-3 bg-white border-b border-stone-200">
          <Pressable onPress={onClose}><Text className="text-orange-600 font-medium">Cancel</Text></Pressable>
          <Text className="text-lg font-semibold text-stone-800">Edit Item</Text>
          <Pressable onPress={handleSave}><Text className="text-orange-600 font-medium">Save</Text></Pressable>
        </View>

        <ScrollView className="flex-1 px-4 py-4" keyboardShouldPersistTaps="handled">
          {/* Name */}
          <View className="mb-4">
            <Text className="text-stone-700 font-medium mb-2">Name</Text>
            <TextInput
              className="bg-white rounded-xl px-4 py-3 text-base text-stone-800 border border-stone-200"
              value={name}
              onChangeText={setName}
            />
          </View>

          {/* Quantity and Unit */}
          <View className="mb-4">
            <Text className="text-stone-700 font-medium mb-2">Quantity</Text>
            <View className="flex-row items-center">
              <Pressable onPress={() => inc(-1)} className="w-10 h-10 bg-stone-200 rounded-full items-center justify-center"><Text className="text-stone-700 text-lg">-</Text></Pressable>
              <TextInput
                className="flex-1 mx-3 bg-white rounded-xl px-4 py-3 text-base text-stone-800 border border-stone-200"
                value={amountText}
                onChangeText={setAmountText}
                keyboardType="decimal-pad"
              />
              <Pressable onPress={() => inc(1)} className="w-10 h-10 bg-stone-200 rounded-full items-center justify-center"><Text className="text-stone-700 text-lg">+</Text></Pressable>
            </View>
          </View>

          <View className="mb-4">
            <Text className="text-stone-700 font-medium mb-2">Unit</Text>
            {families.map((g) => (
              <View key={g.title} className="mb-2">
                <Text className="text-stone-500 text-xs mb-1">{g.title}</Text>
                <View className="flex-row flex-wrap">
                  {g.units.map((u) => (
                    <Pressable key={u} onPress={() => changeUnit(u)} className={`mr-2 mb-2 px-3 py-1.5 rounded-full border ${unit.toLowerCase() === String(u).toLowerCase() ? "bg-orange-100 border-orange-300" : "bg-white border-stone-200"}`}>
                      <Text className={`${unit.toLowerCase() === String(u).toLowerCase() ? "text-orange-700" : "text-stone-700"}`}>{u}</Text>
                    </Pressable>
                  ))}
                </View>
              </View>
            ))}
          </View>

          {/* Notes */}
          <View className="mb-8">
            <Text className="text-stone-700 font-medium mb-2">Notes</Text>
            <TextInput
              className="bg-white rounded-xl px-4 py-3 text-base text-stone-800 border border-stone-200 min-h-20"
              value={notes}
              onChangeText={setNotes}
              placeholder="Add any notes (brand, ripeness, etc.)"
              placeholderTextColor="#a8a29e"
              multiline
              textAlignVertical="top"
            />
          </View>

          {onDelete ? (
            <Pressable onPress={onDelete} className="bg-red-50 border border-red-200 rounded-xl py-3 items-center mb-6">
              <Text className="text-red-600 font-semibold">Delete Item</Text>
            </Pressable>
          ) : null}

        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
}