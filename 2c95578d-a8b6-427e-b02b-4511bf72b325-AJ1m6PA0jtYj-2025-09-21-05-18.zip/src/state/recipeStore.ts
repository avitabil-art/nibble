import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Recipe, GroceryItem, GroceryList, User, SyncStatus, ListChange, CollaboratorInfo, ListInvitation, InvitationLink } from "../types/recipe";
import { buildBaseIngredients, scaleFromBase } from "../utils/scaling";
import { parseRecipeFromUrl, parseIngredientsFromText } from "../utils/recipeParser";
import { authService } from "../api/auth-service";
import { syncService } from "../api/sync-service";
import { invitationService } from "../api/invitation-service";
import { logger } from "../utils/logger";
import { generateId } from "../utils/memoryEfficientId";
import { memoryManager } from "../utils/memoryManager";

interface RecipeStore {
  recipes: Recipe[];
  groceryLists: GroceryList[];
  activeListId: string;
  uiBanner: string;
  
  // User and sharing state
  currentUser: User | null;
  syncStatus: SyncStatus;
  collaborators: Record<string, CollaboratorInfo[]>; // listId -> collaborators (changed from Map for memory efficiency)
  
  // Recipe actions
  addRecipe: (recipe: Omit<Recipe, "id" | "createdAt">) => void;
  updateRecipe: (id: string, updates: Partial<Recipe>) => void;
  deleteRecipe: (id: string) => void;
  scaleRecipe: (id: string, newServings: number) => void;
  refreshRecipe: (id: string) => Promise<{ success: boolean; error?: string }>;
  
  // Category actions
  setRecipeCategories: (id: string, categories: string[]) => void;
  addCategoryToRecipe: (id: string, category: string) => void;
  removeCategoryFromRecipe: (id: string, category: string) => void;
  getAllCategories: () => string[];
  
  // Grocery list management actions
  createGroceryList: (name: string) => string;
  deleteGroceryList: (id: string) => void;
  renameGroceryList: (id: string, name: string) => void;
  setActiveList: (id: string) => void;
  getActiveList: () => GroceryList | undefined;
  
  // Grocery item actions (work with active list)
  addGroceryItem: (item: Omit<GroceryItem, "id" | "addedAt" | "listId">) => void;
  toggleGroceryItem: (id: string) => void;
  removeGroceryItem: (id: string) => void;
  clearCheckedItems: () => void;
  addRecipeToGroceryList: (recipeId: string, targetListId?: string) => void;
  addSelectedIngredientsToGroceryList: (
    recipeId: string,
    ingredientIds?: string[],
    options?: { combine?: boolean; targetListId?: string }
  ) => { added: number; combined: number } | void;
  updateGroceryItem: (id: string, update: Partial<GroceryItem>) => void;
  
  // Recipe ingredient edits
  replaceIngredient: (
    recipeId: string,
    ingredientId: string,
    next: Partial<Pick<import("../types/recipe").Ingredient, "name" | "amount" | "unit">>
  ) => void;
  
  // UI helpers (not persisted)
  setBanner: (msg: string) => void;
  clearBanner: () => void;
  
  // User management
  initializeUser: () => Promise<void>;
  setUserName: (name: string) => Promise<void>;
  
  // Invitation and sharing actions
  createInvitation: (listId: string) => Promise<{ success: boolean; inviteLink?: InvitationLink; error?: string }>;
  acceptInvitation: (token: string) => Promise<{ success: boolean; error?: string }>;
  shareInvitation: (inviteLink: InvitationLink, listName: string) => Promise<{ success: boolean; method?: string; error?: string }>;
  leaveSharedList: (listId: string) => Promise<{ success: boolean; error?: string }>;
  getListCollaborators: (listId: string) => CollaboratorInfo[];
  removeCollaborator: (listId: string, userId: string) => Promise<{ success: boolean; error?: string }>;
  
  // Sync management
  startSync: () => void;
  stopSync: () => void;
  syncNow: () => Promise<void>;
  setSyncStatus: (status: Partial<SyncStatus>) => void;
  
  // Utility actions
  clearAll: () => void;
}

// Use memory-efficient ID generation
// const generateId imported from memoryEfficientId utility

const titleCase = (s: string) =>
  s
    .toLowerCase()
    .split(" ")
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");

const normalizeCategories = (categories: string[]) => {
  const seen = new Set<string>();
  const result: string[] = [];
  for (const raw of categories) {
    const trimmed = raw.trim();
    if (!trimmed) continue;
    const key = trimmed.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      result.push(titleCase(trimmed));
    }
  }
  return result;
};

export const useRecipeStore = create<RecipeStore>()(
  persist(
    (set, get) => ({
      recipes: [],
      groceryLists: [],
      activeListId: "",
      uiBanner: "",
      
      // User and sharing state (not persisted)
      currentUser: null,
      syncStatus: {
        isOnline: true,
        isSyncing: false,
        pendingChanges: 0,
      },
      collaborators: {}, // Changed from Map to plain object for memory efficiency

      addRecipe: (recipeData) => {
        const baseIngredients = buildBaseIngredients(recipeData.ingredients);
        const recipe: Recipe = {
          ...recipeData,
          id: generateId('recipe'),
          createdAt: new Date(),
          tags: normalizeCategories(recipeData.tags ?? []),
          baseIngredients,
        };
        set((state) => ({
          recipes: [recipe, ...state.recipes],
        }));
      },

      updateRecipe: (id, updates) => {
        set((state) => ({
          recipes: state.recipes.map((recipe) =>
            recipe.id === id ? { ...recipe, ...updates } : recipe
          ),
        }));
      },

      deleteRecipe: (id) => {
        set((state) => ({
          recipes: state.recipes.filter((recipe) => recipe.id !== id),
          groceryLists: state.groceryLists.map((list) => ({
            ...list,
            items: list.items.filter((item) => item.recipeId !== id),
          })),
        }));
      },

      scaleRecipe: (id, newServings) => {
        set((state) => ({
          recipes: state.recipes.map((recipe) => {
            if (recipe.id !== id) return recipe;
            const clamped = Math.max(1, Math.min(20, Math.round(newServings)));
            const factor = clamped / recipe.originalServings;
            const base = recipe.baseIngredients && recipe.baseIngredients.length > 0
              ? recipe.baseIngredients
              : buildBaseIngredients(recipe.ingredients);
            const newIngredients = scaleFromBase(base, factor, recipe.ingredients);
            return {
              ...recipe,
              servings: clamped,
              baseIngredients: base,
              ingredients: newIngredients,
            };
          }),
        }));
      },

      // Category methods
      setRecipeCategories: (id, categories) => {
        const normalized = normalizeCategories(categories);
        set((state) => ({
          recipes: state.recipes.map((r) =>
            r.id === id ? { ...r, tags: normalized } : r
          ),
        }));
      },

      addCategoryToRecipe: (id, category) => {
        const cat = normalizeCategories([category]);
        set((state) => ({
          recipes: state.recipes.map((r) => {
            if (r.id !== id) return r;
            const existing = normalizeCategories(r.tags ?? []);
            const combined = normalizeCategories([...existing, ...cat]);
            return { ...r, tags: combined };
          }),
        }));
      },

      removeCategoryFromRecipe: (id, category) => {
        const key = category.trim().toLowerCase();
        set((state) => ({
          recipes: state.recipes.map((r) => {
            if (r.id !== id) return r;
            const filtered = (r.tags ?? []).filter((t) => t.toLowerCase() !== key);
            return { ...r, tags: filtered };
          }),
        }));
      },

      getAllCategories: () => {
        const seen = new Set<string>();
        const out: string[] = [];
        const { recipes } = get();
        for (const r of recipes) {
          for (const t of r.tags ?? []) {
            const k = t.trim().toLowerCase();
            if (!seen.has(k)) {
              seen.add(k);
              out.push(titleCase(t));
            }
          }
        }
        return out.sort();
      },

      // Grocery list management
      createGroceryList: (name) => {
        const id = generateId('list');
        const newList: GroceryList = {
          id,
          name: name.trim(),
          createdAt: new Date(),
          items: [],
          // Sharing fields
          isShared: false,
          sharedWith: [],
          lastModified: new Date(),
          version: 1,
        };
        set((state) => ({
          groceryLists: [...state.groceryLists, newList],
          activeListId: state.activeListId || id, // Set as active if no active list
        }));
        return id;
      },

      deleteGroceryList: (id) => {
        set((state) => {
          const filteredLists = state.groceryLists.filter((list) => list.id !== id);
          const newActiveId = state.activeListId === id 
            ? (filteredLists.length > 0 ? filteredLists[0].id : "")
            : state.activeListId;
          return {
            groceryLists: filteredLists,
            activeListId: newActiveId,
          };
        });
      },

      renameGroceryList: (id, name) => {
        const { currentUser } = get();
        const now = new Date();
        set((state) => ({
          groceryLists: state.groceryLists.map((list) => {
            if (list.id !== id) return list;
            const updated = { ...list, name: name.trim(), lastModified: now, version: list.version + 1 };
            if (updated.isShared && currentUser) {
              const change: ListChange = {
                id: generateId('sync'),
                listId: updated.id,
                type: 'list_updated',
                data: { id: updated.id, name: updated.name, version: updated.version },
                userId: currentUser.id,
                timestamp: now,
                version: updated.version,
              };
              syncService.queueChange(updated.id, change);
            }
            return updated;
          }),
        }));
      },

      setActiveList: (id) => {
        set({ activeListId: id });
      },

      getActiveList: () => {
        const { groceryLists, activeListId } = get();
        return groceryLists.find((list) => list.id === activeListId);
      },

      // Grocery item actions
      addGroceryItem: (itemData) => {
        const { activeListId, currentUser } = get();
        if (!activeListId) return;

        const now = new Date();
        const item: GroceryItem = {
          ...itemData,
          id: generateId('item'),
          amount: itemData.amount ?? 1,
          unit: itemData.unit ?? "piece",
          notes: itemData.notes ?? "",
          addedAt: now,
          modifiedAt: now,
          listId: activeListId,
          modifiedBy: currentUser?.id,
          version: 1,
        };

        set((state) => {
          const updatedLists = state.groceryLists.map((list) => {
            if (list.id === activeListId) {
              const updatedList = {
                ...list,
                items: [...list.items, item],
                lastModified: now,
                version: list.version + 1,
              };

                // Queue change for shared lists
                if (list.isShared && currentUser) {
                  const change: ListChange = {
                    id: generateId('sync'),
                    listId: list.id,
                    type: 'item_added' as const,
                    data: item,
                    userId: currentUser.id,
                    timestamp: now,
                    version: item.version,
                  };
                  syncService.queueChange(list.id, change);
                }

              return updatedList;
            }
            return list;
          });

          return { groceryLists: updatedLists };
        });
      },

      toggleGroceryItem: (id) => {
        const { currentUser } = get();
        const now = new Date();
        set((state) => ({
          groceryLists: state.groceryLists.map((list) => {
            const updatedItems = list.items.map((item) => {
              if (item.id !== id) return item;
              const next = { ...item, checked: !item.checked, modifiedAt: now, version: (item.version || 1) + 1, modifiedBy: currentUser?.id };
              // Queue change if shared
              if (list.isShared && currentUser) {
                const change: ListChange = {
                  id: generateId('sync'),
                  listId: list.id,
                  type: 'item_updated',
                  data: next,
                  userId: currentUser.id,
                  timestamp: now,
                  version: next.version,
                };
                syncService.queueChange(list.id, change);
              }
              return next;
            });
            return { ...list, items: updatedItems, lastModified: now, version: list.version + 1 };
          }),
        }));
      },

      updateGroceryItem: (id, update) => {
        const { currentUser } = get();
        const now = new Date();
        set((state) => ({
          groceryLists: state.groceryLists.map((list) => {
            let changed: GroceryItem | null = null;
            const updatedItems = list.items.map((item) => {
              if (item.id !== id) return item;
              const next = { ...item, ...update, modifiedAt: now, version: (item.version || 1) + 1, modifiedBy: currentUser?.id } as GroceryItem;
              changed = next;
              return next;
            });
            if (changed && list.isShared && currentUser) {
              const change: ListChange = {
                id: generateId('sync'),
                listId: list.id,
                type: 'item_updated',
                data: changed,
                userId: currentUser.id,
                timestamp: now,
                version: changed.version,
              };
              syncService.queueChange(list.id, change);
            }
            return { ...list, items: updatedItems, lastModified: now, version: list.version + 1 };
          }),
        }));
      },

      removeGroceryItem: (id) => {
        const { currentUser } = get();
        const now = new Date();
        set((state) => ({
          groceryLists: state.groceryLists.map((list) => {
            const removed = list.items.find((i) => i.id === id);
            const nextItems = list.items.filter((item) => item.id !== id);
            if (removed && list.isShared && currentUser) {
              const change: ListChange = {
                id: generateId('sync'),
                listId: list.id,
                type: 'item_deleted',
                data: { id, recipeId: removed.recipeId, ingredientId: removed.ingredientId },
                userId: currentUser.id,
                timestamp: now,
                version: (removed.version || 1) + 1,
              };
              syncService.queueChange(list.id, change);
            }
            return { ...list, items: nextItems, lastModified: now, version: list.version + 1 };
          }),
        }));
      },

      clearCheckedItems: () => {
        const { activeListId, currentUser } = get();
        if (!activeListId) return;
        const now = new Date();

        set((state) => ({
          groceryLists: state.groceryLists.map((list) => {
            if (list.id !== activeListId) return list;
            const remaining = list.items.filter((item) => !item.checked);
            if (list.isShared && currentUser) {
              // queue deletes for checked items
              list.items.filter(i => i.checked).forEach((removed) => {
                const change: ListChange = {
                  id: generateId('sync'),
                  listId: list.id,
                  type: 'item_deleted',
                  data: { id: removed.id, recipeId: removed.recipeId, ingredientId: removed.ingredientId },
                  userId: currentUser.id,
                  timestamp: now,
                  version: (removed.version || 1) + 1,
                };
                syncService.queueChange(list.id, change);
              });
            }
            return { ...list, items: remaining, lastModified: now, version: list.version + 1 };
          }),
        }));
      },

      replaceIngredient: (recipeId, ingredientId, next) => {
        set((state) => ({
          recipes: state.recipes.map((r) => {
            if (r.id !== recipeId) return r;
            return {
              ...r,
              ingredients: r.ingredients.map((ing) =>
                ing.id === ingredientId ? { ...ing, ...next } : ing
              ),
            };
          }),
        }));
      },

      addSelectedIngredientsToGroceryList: (recipeId, ingredientIds, options) => {
        const { recipes, groceryLists } = get();
        const targetListId = options?.targetListId || get().activeListId;
        if (!targetListId) return;

        const recipe = recipes.find((r) => r.id === recipeId);
        if (!recipe) return;

        const targetList = groceryLists.find((list) => list.id === targetListId);
        if (!targetList) return;

        // Filter selected ingredients and check for duplicates
        const selected = (ingredientIds && ingredientIds.length > 0)
          ? recipe.ingredients.filter((ing) => ingredientIds.includes(ing.id))
          : recipe.ingredients;

        // Remove ingredients that already exist in the target list
        const newIngredients = selected.filter((ingredient) => {
          return !targetList.items.some(
            (item) => item.ingredientId === ingredient.id && item.recipeId === recipeId
          );
        });

        if (newIngredients.length === 0) {
          return { added: 0, combined: 0, duplicates: selected.length };
        }

        const combine = options?.combine === true;
        const keyOf = (name: string, unit?: string) => `${name.trim().toLowerCase()}|${(unit || "").toLowerCase()}`;
        
        // First, check for existing items in the list that could be combined
        const existingItemsMap = new Map<string, GroceryItem>();
        if (combine) {
          targetList.items.forEach((item) => {
            const key = keyOf(item.name, item.unit);
            existingItemsMap.set(key, item);
          });
        }

        const map = new Map<string, { name: string; unit?: string; amount?: number; ingredientId?: string; existingItemId?: string }>();
        let combined = 0;
        let updated = 0;

        for (const ing of newIngredients) {
          const k = keyOf(ing.name, ing.unit);
          
          // Check if we can combine with existing item
          if (combine && existingItemsMap.has(k)) {
            const existingItem = existingItemsMap.get(k)!;
            if (typeof existingItem.amount === "number" && typeof ing.amount === "number") {
              // We'll update the existing item instead of adding a new one
              map.set(k, {
                name: ing.name,
                unit: ing.unit,
                amount: (existingItem.amount || 0) + (ing.amount || 0),
                existingItemId: existingItem.id,
              });
              updated++;
              continue;
            }
          }
          
          // Check if we can combine with other new ingredients
          if (combine && map.has(k)) {
            const cur = map.get(k)!;
            if (typeof cur.amount === "number" && typeof ing.amount === "number") {
              cur.amount = (cur.amount || 0) + (ing.amount || 0);
              combined++;
            }
          } else {
            map.set(k, { 
              name: ing.name, 
              unit: ing.unit, 
              amount: ing.amount,
              ingredientId: ing.id,
            });
          }
        }

        const toAdd = Array.from(map.values());

        const now = new Date();
        let createdItems: GroceryItem[] = [];
        let updatedItems: GroceryItem[] = [];

        set((state) => ({
          groceryLists: state.groceryLists.map((list) =>
            list.id === targetListId
              ? {
                  ...list,
                  items: list.items.map((item) => {
                    // Update existing items that were combined
                    const updateData = toAdd.find(x => x.existingItemId === item.id);
                    if (updateData) {
                      const next = { ...item, amount: updateData.amount, modifiedAt: now, version: (item.version || 1) + 1 } as GroceryItem;
                      updatedItems.push(next);
                      return next;
                    }
                    return item;
                  }).concat(
                    // Add new items
                    toAdd
                      .filter(x => !x.existingItemId)
                      .map((x) => {
                        const created: GroceryItem = {
                          id: generateId(),
                          name: x.name,
                          amount: x.amount,
                          unit: x.unit,
                          checked: false,
                          recipeId,
                          ingredientId: x.ingredientId,
                          addedAt: now,
                          modifiedAt: now,
                          version: 1,
                          listId: targetListId,
                          modifiedBy: get().currentUser?.id,
                        };
                        createdItems.push(created);
                        return created;
                      })
                  ),
                  lastModified: now,
                  version: list.version + 1,
                }
              : list
          ),
        }));

        // Queue sync changes for shared lists
        const tList = get().groceryLists.find(l => l.id === targetListId);
        const currentUser = get().currentUser;
        if (tList?.isShared && currentUser) {
          createdItems.forEach((item) => {
            const change: ListChange = {
              id: generateId('sync'),
              listId: targetListId,
              type: 'item_added',
              data: item,
              userId: currentUser.id,
              timestamp: now,
              version: item.version,
            };
            syncService.queueChange(targetListId, change);
          });
          updatedItems.forEach((item) => {
            const change: ListChange = {
              id: generateId('sync'),
              listId: targetListId,
              type: 'item_updated',
              data: item,
              userId: currentUser.id,
              timestamp: now,
              version: item.version,
            };
            syncService.queueChange(targetListId, change);
          });
        }

        const newItemsAdded = toAdd.filter(x => !x.existingItemId).length;
        const duplicates = selected.length - newIngredients.length;
        
        return { 
          added: newItemsAdded, 
          combined, 
          updated,
          duplicates: duplicates > 0 ? duplicates : undefined 
        };
      },

      addRecipeToGroceryList: (recipeId, targetListId) => {
        const { recipes, activeListId, currentUser, groceryLists } = get();
        const listId = targetListId || activeListId;
        if (!listId) return;

        const recipe = recipes.find((r) => r.id === recipeId);
        if (!recipe) return;
        const targetList = groceryLists.find((l) => l.id === listId);
        if (!targetList) return;

        const now = new Date();
        const newItems: GroceryItem[] = recipe.ingredients
          .filter((ingredient) => {
            return !targetList.items.some(
              (item) => item.ingredientId === ingredient.id && item.recipeId === recipeId
            );
          })
          .map((ingredient) => ({
            id: generateId(),
            name: ingredient.name,
            amount: ingredient.amount,
            unit: ingredient.unit,
            checked: false,
            recipeId: recipe.id,
            ingredientId: ingredient.id,
            addedAt: now,
            modifiedAt: now,
            version: 1,
            listId,
            modifiedBy: currentUser?.id,
          }));

        set((state) => ({
          groceryLists: state.groceryLists.map((list) =>
            list.id === listId
              ? { ...list, items: [...list.items, ...newItems], lastModified: now, version: list.version + 1 }
              : list
          ),
        }));

        if (targetList.isShared && currentUser) {
          newItems.forEach((item) => {
            const change: ListChange = {
              id: generateId('sync'),
              listId: listId,
              type: 'item_added',
              data: item,
              userId: currentUser.id,
              timestamp: now,
              version: item.version,
            };
            syncService.queueChange(listId, change);
          });
        }
      },

      setBanner: (msg) => {
        set({ uiBanner: msg });
      },

      clearBanner: () => {
        set({ uiBanner: "" });
      },

      // User management
      initializeUser: async () => {
        const user = await authService.initialize();
        set({ currentUser: user });
      },

      setUserName: async (name) => {
        try {
          let user = get().currentUser;
          if (!user) {
            user = await authService.createUser(name);
          } else {
            user = await authService.updateUserName(name);
          }
          set({ currentUser: user });
        } catch (error) {
          logger.error('Error setting user name:', error);
          throw error;
        }
      },

      // Sharing actions
      createInvitation: async (listId) => {
        const { groceryLists, currentUser } = get();
        if (!currentUser) {
          return { success: false, error: 'User not authenticated' };
        }

        const list = groceryLists.find(l => l.id === listId);
        if (!list) {
          return { success: false, error: 'List not found' };
        }

        try {
          // Create invitation via invitation service
          const result = await invitationService.createInvitation(listId, list);
          
          if (result.success && result.invitation && result.inviteLink) {
            // Make list shared if not already
            if (!list.isShared) {
              const sharedList: GroceryList = {
                ...list,
                isShared: true,
                inviteToken: result.invitation.inviteToken,
                ownerId: currentUser.id,
                sharedWith: [currentUser.id],
                lastModified: new Date(),
                version: list.version + 1,
              };

              // Create on server
              const response = await syncService.createSharedList(sharedList, result.invitation.inviteToken);
              
              if (response.success) {
                // Update local state
                set((state) => ({
                  groceryLists: state.groceryLists.map(l => 
                    l.id === listId ? sharedList : l
                  ),
                }));

                // Show development mode notice if applicable
                if (__DEV__ && response.data?.listId?.startsWith('dev-')) {
                  set({ uiBanner: "Development Mode: Invitation created locally" });
                }
              } else {
                return { success: false, error: response.error || 'Failed to create shared list' };
              }
            }

            return { success: true, inviteLink: result.inviteLink };
          } else {
            return { success: false, error: result.error || 'Failed to create invitation' };
          }
        } catch (error) {
          logger.error('Error creating invitation:', error);
          return { success: false, error: 'Failed to create invitation' };
        }
      },

      acceptInvitation: async (token) => {
        const { currentUser } = get();
        if (!currentUser) {
          return { success: false, error: 'User not authenticated' };
        }

        try {
          const response = await syncService.joinSharedList(token);
          
          if (response.success && response.data.list) {
            // Add the shared list to local state
            const sharedList = response.data.list;
            
            // Check if list already exists (avoid duplicates)
            const { groceryLists } = get();
            const existingList = groceryLists.find(l => l.id === sharedList.id);
            
            if (!existingList) {
              set((state) => ({
                groceryLists: [...state.groceryLists, sharedList],
                activeListId: state.activeListId || sharedList.id,
              }));
            }

            // Show development mode notice if applicable
            if (__DEV__ && sharedList.id?.startsWith('dev-')) {
              set({ uiBanner: "Development Mode: Joined demo shared list" });
            }

            return { success: true };
          } else {
            return { success: false, error: response.error || 'Failed to accept invitation' };
          }
        } catch (error) {
          logger.error('Error accepting invitation:', error);
          return { success: false, error: 'Failed to accept invitation' };
        }
      },

      shareInvitation: async (inviteLink, listName) => {
        const { currentUser } = get();
        if (!currentUser) {
          return { success: false, error: 'User not authenticated' };
        }

        try {
          const result = await invitationService.shareInvitation(inviteLink, listName, currentUser.name);
          return result;
        } catch (error) {
          logger.error('Error sharing invitation:', error);
          return { success: false, error: 'Failed to share invitation' };
        }
      },

      leaveSharedList: async (listId) => {
        const { groceryLists, currentUser } = get();
        if (!currentUser) {
          return { success: false, error: 'User not authenticated' };
        }

        const list = groceryLists.find(l => l.id === listId);
        if (!list || !list.isShared || !list.inviteToken) {
          return { success: false, error: 'List not found or not shared' };
        }

        try {
          const response = await syncService.leaveSharedList(list.inviteToken);
          
          if (response.success) {
            // Remove list from local state
            set((state) => {
              const filteredLists = state.groceryLists.filter(l => l.id !== listId);
              const newActiveId = state.activeListId === listId 
                ? (filteredLists.length > 0 ? filteredLists[0].id : "")
                : state.activeListId;

              return {
                groceryLists: filteredLists,
                activeListId: newActiveId,
              };
            });

            return { success: true };
          } else {
            return { success: false, error: response.error || 'Failed to leave shared list' };
          }
        } catch (error) {
          logger.error('Error leaving shared list:', error);
          return { success: false, error: 'Failed to leave shared list' };
        }
      },

      getListCollaborators: (listId) => {
        const { collaborators } = get();
        return collaborators[listId] || [];
      },

      removeCollaborator: async (listId, userId) => {
        const { groceryLists, currentUser } = get();
        if (!currentUser) {
          return { success: false, error: 'User not authenticated' };
        }

        const list = groceryLists.find(l => l.id === listId);
        if (!list || !list.isShared || !list.inviteToken) {
          return { success: false, error: 'List not found or not shared' };
        }

        if (list.ownerId !== currentUser.id) {
          return { success: false, error: 'Only list owner can remove collaborators' };
        }

        try {
          const response = await syncService.removeCollaborator(list.inviteToken, userId);
          
          if (response.success) {
            // Update local collaborators
            set((state) => {
              const newCollaborators = { ...state.collaborators };
              const listCollaborators = newCollaborators[listId] || [];
              newCollaborators[listId] = listCollaborators.filter(c => c.userId !== userId);
              return { collaborators: newCollaborators };
            });

            return { success: true };
          } else {
            return { success: false, error: response.error || 'Failed to remove collaborator' };
          }
        } catch (error) {
          logger.error('Error removing collaborator:', error);
          return { success: false, error: 'Failed to remove collaborator' };
        }
      },

      // Sync management
      startSync: () => {
        // Wire sync resolvers so the service can access current lists and update state
        syncService.setResolvers({
          getSharedLists: () => {
            const { groceryLists } = get();
            return groceryLists
              .filter(l => l.isShared && !!l.inviteToken)
              .map(l => ({ id: l.id, inviteToken: l.inviteToken! }));
          },
          applyRemoteList: (remoteList, collaborators) => {
            set((state) => {
              const next: any = {
                groceryLists: state.groceryLists.map(l => l.id === remoteList.id ? { ...remoteList } : l),
              };
              if (collaborators) {
                next.collaborators = { ...state.collaborators, [remoteList.id]: collaborators };
              }
              return next;
            });
          },
        });

        syncService.addStatusListener((status) => {
          set({ syncStatus: status });
        });
        syncService.startSync();
      },

      stopSync: () => {
        syncService.stopSync();
      },

      syncNow: async () => {
        // Force immediate sync - this will be called by sync service
        const { groceryLists } = get();
        const sharedLists = groceryLists.filter(list => list.isShared);
        
        for (const list of sharedLists) {
          if (list.inviteToken) {
            const response = await syncService.getSharedList(list.inviteToken);
            if (response.success && response.data) {
              // Update local list with remote data
              set((state) => ({
                groceryLists: state.groceryLists.map(l => 
                  l.id === list.id ? { ...response.data.list } : l
                ),
              }));

              // Update collaborators
              if (response.data.collaborators) {
                set((state) => {
                  const newCollaborators = { ...state.collaborators };
                  newCollaborators[list.id] = response.data.collaborators;
                  return { collaborators: newCollaborators };
                });
              }
            }
          }
        }
      },

      setSyncStatus: (status) => {
        set((state) => ({
          syncStatus: { ...state.syncStatus, ...status }
        }));
      },

      refreshRecipe: async (id) => {
        const { recipes } = get();
        const recipe = recipes.find((r) => r.id === id);
        
        if (!recipe) {
          return { success: false, error: "Recipe not found" };
        }
        
        if (!recipe.url) {
          return { success: false, error: "Recipe has no URL to refresh from" };
        }

        try {
          const parsedData = await parseRecipeFromUrl(recipe.url);
          
          // Validate parsed data
          if (!parsedData.title || !parsedData.ingredients?.length) {
            return { 
              success: false, 
              error: "Recipe data appears incomplete. The website may have changed its structure." 
            };
          }

          const parsedIngredients = parseIngredientsFromText(parsedData.ingredients);
          
          // Ensure we have valid ingredients
          if (!parsedIngredients.length) {
            return { 
              success: false, 
              error: "No ingredients could be parsed from the recipe." 
            };
          }

          const newBaseIngredients = buildBaseIngredients(parsedIngredients);
          
          // Scale to current serving size if different from original
          const currentServings = recipe.servings;
          const newOriginalServings = parsedData.servings || 4;
          let finalIngredients = parsedIngredients;
          
          if (currentServings !== newOriginalServings) {
            const scaleFactor = currentServings / newOriginalServings;
            finalIngredients = scaleFromBase(newBaseIngredients, scaleFactor, parsedIngredients);
          }

          set((state) => ({
            recipes: state.recipes.map((r) =>
              r.id === id
                ? {
                    ...r,
                    title: parsedData.title,
                    ingredients: finalIngredients,
                    instructions: parsedData.instructions || ["No instructions available"],
                    originalServings: newOriginalServings,
                    baseIngredients: newBaseIngredients,
                  }
                : r
            ),
          }));

          return { success: true };
        } catch (error) {
          // Handle specific error types
          if (error instanceof TypeError && error.message.includes("fetch")) {
            return { 
              success: false, 
              error: "Network error. Please check your internet connection and try again." 
            };
          }
          
          if (error instanceof Error && error.message.includes("Could not extract recipe")) {
            return { 
              success: false, 
              error: "Unable to extract recipe data. The website may have changed or blocked access." 
            };
          }

          return { 
            success: false, 
            error: error instanceof Error ? error.message : "Failed to refresh recipe. Please try again later." 
          };
        }
      },

      clearAll: () => {
        // Register memory cleanup before clearing
        const state = get();
        memoryManager.recordStats(
          state.recipes.length + state.groceryLists.reduce((acc, list) => acc + list.items.length, 0),
          {
            recipes: state.recipes.length,
            groceryLists: state.groceryLists.length,
            totalItems: state.groceryLists.reduce((acc, list) => acc + list.items.length, 0)
          }
        );
        
        set({ recipes: [], groceryLists: [], activeListId: "" });
      },
    }),
    {
      name: "recipe-storage",
      storage: createJSONStorage(() => ({
        getItem: async (name) => {
          try {
            const startTime = Date.now();
            const data = await AsyncStorage.getItem(name);
            const loadTime = Date.now() - startTime;
            
            // Log slow storage operations
            if (loadTime > 100) {
              logger.warn(`[AsyncStorage] Slow getItem for ${name}: ${loadTime}ms`);
            }
            
            return data;
          } catch (error) {
            logger.error('[AsyncStorage] Failed to get item:', name, error);
            return null;
          }
        },
        setItem: async (name, value) => {
          try {
            const startTime = Date.now();
            
            // Check data size before storing
            const dataSize = new Blob([value]).size;
            if (dataSize > 1024 * 1024) { // 1MB threshold
              logger.warn(`[AsyncStorage] Large data being stored for ${name}: ${Math.round(dataSize / 1024)}KB`);
            }
            
            await AsyncStorage.setItem(name, value);
            
            const storeTime = Date.now() - startTime;
            if (storeTime > 200) {
              logger.warn(`[AsyncStorage] Slow setItem for ${name}: ${storeTime}ms`);
            }
          } catch (error) {
            logger.error('[AsyncStorage] Failed to set item:', name, error);
            // Try to clear some space by removing old data if storage is full
            if (error.message?.includes('quota') || error.message?.includes('space')) {
              logger.warn('[AsyncStorage] Storage quota exceeded, attempting cleanup');
              try {
                // Emergency cleanup - remove oldest data
                await AsyncStorage.removeItem(name + '_backup');
              } catch (cleanupError) {
                logger.error('[AsyncStorage] Emergency cleanup failed:', cleanupError);
              }
            }
          }
        },
        removeItem: async (name) => {
          try {
            await AsyncStorage.removeItem(name);
          } catch (error) {
            logger.error('[AsyncStorage] Failed to remove item:', name, error);
            // Ignore storage errors in production
          }
        },
      })),
      partialize: (state) => ({
        recipes: state.recipes,
        groceryLists: state.groceryLists,
        activeListId: state.activeListId,
        // Don't persist: currentUser, syncStatus, collaborators (runtime state)
      }),
      onRehydrateStorage: () => (state) => {
        try {
          if (!state) {
            logger.log('[RecipeStore] No state to rehydrate, using defaults');
            return;
          }

          // Initialize basic structure if missing
          if (!state.recipes) state.recipes = [];
          if (!state.groceryLists) state.groceryLists = [];
          if (!state.activeListId) state.activeListId = "";

          // Migration logic: convert old single groceryList to new structure
          try {
            if ((state as any).groceryList && Array.isArray((state as any).groceryList) && !state.groceryLists.length) {
              const oldItems = (state as any).groceryList as GroceryItem[];
              if (oldItems.length > 0) {
                const defaultListId = generateId();
                const now = new Date();
                const migratedItems = oldItems.map((item) => ({
                  ...item,
                  listId: defaultListId,
                  modifiedAt: item.addedAt || now,
                  version: 1,
                }));
                state.groceryLists = [{
                  id: defaultListId,
                  name: "Shopping List",
                  createdAt: now,
                  items: migratedItems,
                  isShared: false,
                  sharedWith: [],
                  lastModified: now,
                  version: 1,
                }];
                state.activeListId = defaultListId;
                delete (state as any).groceryList;
              }
            }
          } catch (migrationError) {
            logger.error('[RecipeStore] Migration failed:', migrationError);
            // Continue with empty state
          }

          // Migration: add new sharing fields to existing lists
          try {
            if (state.groceryLists && Array.isArray(state.groceryLists) && state.groceryLists.length > 0) {
              state.groceryLists = state.groceryLists.map((list) => {
                const now = new Date();
                return {
                  ...list,
                  isShared: list.isShared ?? false,
                  sharedWith: list.sharedWith ?? [],
                  lastModified: list.lastModified ?? list.createdAt ?? now,
                  version: list.version ?? 1,
                  items: Array.isArray(list.items) ? list.items.map((item) => ({
                    ...item,
                    modifiedAt: item.modifiedAt ?? item.addedAt ?? now,
                    version: item.version ?? 1,
                  })) : [],
                };
              });
            }
          } catch (sharingMigrationError) {
            logger.error('[RecipeStore] Sharing migration failed:', sharingMigrationError);
            // Continue with existing state
          }
          
          // Ensure we have at least one list and an active list
          if (!Array.isArray(state.groceryLists) || state.groceryLists.length === 0) {
            const defaultListId = generateId();
            const now = new Date();
            state.groceryLists = [{
              id: defaultListId,
              name: "Shopping List",
              createdAt: now,
              items: [],
              isShared: false,
              sharedWith: [],
              lastModified: now,
              version: 1,
            }];
            state.activeListId = defaultListId;
          } else if (!state.activeListId && state.groceryLists.length > 0) {
            state.activeListId = state.groceryLists[0].id;
          }

          // Initialize runtime state
          state.currentUser = null;
          state.syncStatus = {
            isOnline: true,
            isSyncing: false,
            pendingChanges: 0,
          };
          state.collaborators = {};

        } catch (rehydrationError) {
          logger.error('[RecipeStore] Critical rehydration error:', rehydrationError);
          
          // Reset to safe defaults on critical error
          if (state) {
            state.recipes = [];
            state.groceryLists = [{
              id: generateId(),
              name: "Shopping List",
              createdAt: new Date(),
              items: [],
              isShared: false,
              sharedWith: [],
              lastModified: new Date(),
              version: 1,
            }];
            state.activeListId = state.groceryLists[0].id;
            state.currentUser = null;
            state.syncStatus = {
              isOnline: true,
              isSyncing: false,
              pendingChanges: 0,
            };
            state.collaborators = {};
          }
        }
      },
    }
  )
);